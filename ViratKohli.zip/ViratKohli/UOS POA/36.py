
# 36. Write a python function for merge/quick sort for integer list as parameter to it.
# Merge Sort:
def merge_sort(arr):
        if len(arr) > 1:
            mid = len(arr) // 2
            left_half = arr[:mid]
            right_half = arr[mid:]


            merge_sort(left_half)
            merge_sort(right_half)


            i = j = k = 0


            while i < len(left_half) and j < len(right_half):
                if left_half[i] < right_half[j]:
                    arr[k] = left_half[i]
                    i += 1
                else:
                    arr[k] = right_half[j]
                    j += 1
                k += 1


            while i < len(left_half):
                arr[k] = left_half[i]
                i += 1
                k += 1


            while j < len(right_half):
                arr[k] = right_half[j]
                j += 1
                k += 1


def merge_sort_test():
        arr = [12, 11, 13, 5, 6, 7]
        merge_sort(arr)
        print("Merge Sorted array is:", arr)


merge_sort_test()
# Quick Sort:
# def quick_sort(arr):
#         if len(arr) <= 1:
#             return arr
#         pivot = arr[len(arr) // 2]
#         left = [x for x in arr if x < pivot]
#         middle = [x for x in arr if x == pivot]
#         right = [x for x in arr if x > pivot]
#         return quick_sort(left) + middle + quick_sort(right)


# def quick_sort_test():
#         arr = [12, 11, 13, 5, 6, 7]
#         sorted_arr = quick_sort(arr)
#         print("Quick Sorted array is:", sorted_arr)


# quick_sort_test()

"""
### 🔍 **Code Explanation**

This Python implementation of merge sort organizes an unsorted list of integers by recursively dividing the list, sorting sublists, and merging them back together. Here's a breakdown of the code and related concepts:

---

### **1. Merge Sort Function: `merge_sort(arr)`**
```python
def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr) // 2
        left_half = arr[:mid]
        right_half = arr[mid:]
```
- **Base Case**: If the array length is `1` or less, the recursion stops since the array is already sorted.
- **Divide Step**:
  - Splits the array into two halves:
    - `left_half`: Contains the first half of the array (`arr[:mid]`).
    - `right_half`: Contains the second half (`arr[mid:]`).

---

#### Recursive Sorting of Halves
```python
        merge_sort(left_half)
        merge_sort(right_half)
```
- Recursively calls `merge_sort` on `left_half` and `right_half` until arrays with single elements are obtained.

---

#### Merging the Sorted Halves
```python
        i = j = k = 0
        while i < len(left_half) and j < len(right_half):
            if left_half[i] < right_half[j]:
                arr[k] = left_half[i]
                i += 1
            else:
                arr[k] = right_half[j]
                j += 1
            k += 1
```
- **Merge Logic**:
  - Compares the elements of the two sorted halves (`left_half` and `right_half`) and places the smaller element into the original array (`arr`).
  - Uses three pointers:
    - `i`: Tracks the current index in `left_half`.
    - `j`: Tracks the current index in `right_half`.
    - `k`: Tracks the insertion index in the original array.

---

#### Handling Remaining Elements
```python
        while i < len(left_half):
            arr[k] = left_half[i]
            i += 1
            k += 1

        while j < len(right_half):
            arr[k] = right_half[j]
            j += 1
            k += 1
```
- If elements remain in `left_half` or `right_half`, they are copied directly into the original array (`arr`).

---

### **2. Test Function: `merge_sort_test()`**
```python
def merge_sort_test():
    arr = [12, 11, 13, 5, 6, 7]
    merge_sort(arr)
    print("Merge Sorted array is:", arr)
```
- **Input**: An unsorted array `[12, 11, 13, 5, 6, 7]`.
- **Output**: Prints the sorted array.

---

### 📚 **Merge Sort Theory**

#### **Overview**
- **Divide and Conquer Algorithm**:
  - Splits the array into two halves recursively.
  - Merges the sorted halves to produce the final sorted array.
- **Time Complexity**:
  - **Best/Average/Worst Case**: \(O(n \log n)\), where \(n\) is the number of elements in the array.
- **Space Complexity**: \(O(n)\), as it requires temporary arrays for merging.

#### **Merge Sort Workflow**
1. **Splitting**:
   - Recursively divides the array until each sub-array has one element.
   - Example for `[12, 11, 13, 5, 6, 7]`:
     - Split into `[12, 11, 13]` and `[5, 6, 7]`.
     - Further split into `[12]`, `[11, 13]`, `[5]`, `[6, 7]`.
     - Continue until single-element arrays remain.
2. **Sorting and Merging**:
   - Compare and merge elements, maintaining sorted order.
   - Example:
     - `[12]` and `[11]` → `[11, 12]`.
     - `[11, 12]` and `[13]` → `[11, 12, 13]`.
     - Repeat for other halves and merge them into `[5, 6, 7, 11, 12, 13]`.

---

### Example Execution

#### Input:
```python
arr = [12, 11, 13, 5, 6, 7]
```

#### Output:
```
Merge Sorted array is: [5, 6, 7, 11, 12, 13]
```

---

This implementation is efficient and easy to understand. Let me know if you'd like to incorporate additional sorting algorithms like quick sort or visualize the merging process! 😊

"""




