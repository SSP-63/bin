// Process2:
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>


// Define message structure
struct message {
        long mtype;
        char mtext[100];
};


int main() {
        key_t key = ftok(".", 'A'); // Generate the same key for the message queue


        // Get the message queue ID
        int msqid = msgget(key, 0666);
        if (msqid == -1) {
            perror("msgget");
            exit(1);
        }


        // Receive message
        struct message msg_recv;
        if (msgrcv(msqid, &msg_recv, sizeof(msg_recv.mtext), 1, 0) == -1) {
            perror("msgrcv");
            exit(1);
        }
        printf("Process 2: Received message - %s\n", msg_recv.mtext);


        // Reply
        struct message msg_reply;
        msg_reply.mtype = 2; // Message type
        strcpy(msg_reply.mtext, "Loud and Clear");
        if (msgsnd(msqid, &msg_reply, sizeof(msg_reply.mtext), 0) == -1) {
            perror("msgsnd");
            exit(1);
        }
        printf("Process 2: Replied - %s\n", msg_reply.mtext);


        return 0;
}




// Make sure to compile each program separately:
// gcc -o process1 process1.c -lrt
// gcc -o process2 process2.c -lrt
// Then run them in separate terminals:
// ./process1
// ./process2


// omkar@omkar:~/Desktop/UOS POA$ gcc -o FirstProcess50 FirstProcess50.c -lrt
// omkar@omkar:~/Desktop/UOS POA$ gcc -o SecondProcess50 SecondProcess50.c -lrt

/* This **Process 2** code works in tandem with **Process 1** to demonstrate inter-process communication (IPC) using **System V message queues**. Here's a breakdown of what this program achieves and how to use it:

---

### **Process 2 Overview**
This program:
1. **Accesses the same message queue** created by Process 1 using a unique key.
2. **Receives the initial message** sent by Process 1.
3. **Replies with a message** back to Process 1.

---

### **Code Walkthrough**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
```
- **`stdio.h`**: For input/output operations.
- **`stdlib.h`**: Contains utility functions like `exit`.
- **`sys/ipc.h`** and **`sys/msg.h`**: Provide IPC functions and data structures needed for message queues.
- **`string.h`**: Handles string manipulation (e.g., `strcpy`, `strlen`).

---

#### **2. Define the Message Structure**
```c
struct message {
    long mtype;
    char mtext[100];
};
```
- **`mtype`**:
  - Message type (used for filtering messages in the queue).
- **`mtext`**:
  - Contains the text of the message.

---

#### **3. Generate the Key**
```c
key_t key = ftok(".", 'A');
```
- **`ftok`**:
  - Generates a unique key for the message queue based on the specified file path (`.`) and project ID (`'A'`).
- **Consistency**:
  - Must use the **same key** as Process 1 to ensure both processes refer to the same message queue.

---

#### **4. Access the Message Queue**
```c
int msqid = msgget(key, 0666);
```
- **`msgget`**:
  - Retrieves the message queue identifier (ID) using the key.
  - **`0666`**:
    - Grants read/write permissions to all users.
- **Error Handling**:
  - Prints an error using `perror` if the queue cannot be accessed and exits.

---

#### **5. Receive Message from Process 1**
```c
if (msgrcv(msqid, &msg_recv, sizeof(msg_recv.mtext), 1, 0) == -1) {
    perror("msgrcv");
    exit(1);
}
```
- **`msgrcv`**:
  - Receives a message from the queue with the specified message type (`1` in this case).
  - Parameters:
    - `msqid`: Message queue ID.
    - `&msg_recv`: Pointer to the message structure.
    - `sizeof(msg_recv.mtext)`: Size of the message text.
    - `1`: Specifies the message type to read (message sent by Process 1).
    - `0`: Blocks until a message of the specified type is available.
- **Error Handling**:
  - If no message is received, prints an error and exits.

---

#### **6. Send Reply to Process 1**
```c
msg_reply.mtype = 2;
strcpy(msg_reply.mtext, "Loud and Clear");
if (msgsnd(msqid, &msg_reply, sizeof(msg_reply.mtext), 0) == -1) {
    perror("msgsnd");
    exit(1);
}
```
- **`msgsnd`**:
  - Sends a reply message back to the queue.
  - Parameters:
    - `msqid`: Message queue ID.
    - `&msg_reply`: Pointer to the reply message structure.
    - `sizeof(msg_reply.mtext)`: Size of the reply message text.
    - `0`: Performs the operation without any special flags.
- **Message Content**:
  - Sets the reply message type to `2` and the content to `"Loud and Clear"`.
- **Error Handling**:
  - Prints an error and exits if the message cannot be sent.

---

### **Compiling and Running the Programs**

#### **1. Compile the Programs**
```bash
gcc -o process1 process1.c -lrt
gcc -o process2 process2.c -lrt
```

#### **2. Run the Programs in Separate Terminals**
1. Start **Process 1** in Terminal 1:
   ```bash
   ./process1
   ```
2. Start **Process 2** in Terminal 2:
   ```bash
   ./process2
   ```

---

### **Expected Output**

#### **Terminal 1 (Process 1)**:
```
Process 1: Sent message - Are you hearing me?
Process 1: Received reply - Loud and Clear
Process 1: Sent acknowledgment - I can hear you too
```

#### **Terminal 2 (Process 2)**:
```
Process 2: Received message - Are you hearing me?
Process 2: Replied - Loud and Clear
```

---

### **IPC Using System V Message Queues**

#### **How It Works**
1. **Message Queue**:
   - Acts as a bridge between the two processes.
   - Stores messages of different types.
2. **Message Exchange**:
   - Process 1 sends a message with type `1` to the queue.
   - Process 2 reads this message and responds with a message of type `2`.

#### **Advantages**
- **Asynchronous Communication**:
  - Processes can exchange messages without being directly connected.
- **Message Prioritization**:
  - Messages can be filtered based on their `mtype`.

#### **Limitations**
- **Size Limitation**:
  - Messages have a size limit determined by the system (`msgmax`).
- **Manual Cleanup**:
  - Message queues must be explicitly removed using `msgctl`.

Let me know if you'd like additional examples or enhancements, such as adding error recovery or logging! 😊*/
