
// 63. Write a program to demonstrate the flock system call for locking.
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/file.h>


int main() {
        int fd;
        char *filename = "example.txt";
        char data[] = "This is a test message.\n";


        // Open or create the file
        fd = open(filename, O_WRONLY | O_CREAT, 0644);
        if (fd == -1) {
            perror("open");
            exit(EXIT_FAILURE);
        }


        // Lock a portion of the file
        printf("Locking file...\n");
        if (flock(fd, LOCK_EX) == -1) {
            perror("flock");
            exit(EXIT_FAILURE);
        }


        // Write to the file
        printf("Writing to locked file...\n");
        if (write(fd, data, sizeof(data)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }


        // Release the lock
        printf("Releasing lock...\n");
        if (flock(fd, LOCK_UN) == -1) {
            perror("flock");
            exit(EXIT_FAILURE);
        }


        // Close the file
        printf("Closing file...\n");
        if (close(fd) == -1) {
            perror("close");
            exit(EXIT_FAILURE);
        }


        printf("Program completed successfully.\n");


        return 0;
}
/* ### **Program Explanation: Using the `flock` System Call for File Locking**

This program illustrates the use of the **`flock` system call**, which locks and unlocks files to control concurrent access. Below is a detailed explanation of the code and concepts related to file locking with `flock`.

---

### **What is `flock`?**

The **`flock` system call** provides advisory locking for files, ensuring that multiple processes do not modify a file simultaneously. 

#### **Types of Locks**
1. **Exclusive Lock (`LOCK_EX`)**:
   - Allows only one process to access the file.
   - Blocks other processes attempting to acquire a lock on the same file.
2. **Shared Lock (`LOCK_SH`)**:
   - Allows multiple processes to read the file concurrently.
   - Blocks processes that request exclusive locks.
3. **Unlock (`LOCK_UN`)**:
   - Releases the lock so other processes can access the file.

---

### **Detailed Code Explanation**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/file.h>
```
- **`stdio.h`**: Includes standard input/output functions like `printf` and `perror`.
- **`fcntl.h`**: Provides definitions for file access modes (`O_WRONLY`, `O_CREAT`).
- **`unistd.h`**: Includes file descriptor-related functions like `open` and `close`.
- **`sys/file.h`**: Contains the `flock` system call and its associated constants (`LOCK_EX`, `LOCK_SH`, `LOCK_UN`).

---

#### **2. Declare and Open File**
```c
int fd;
char *filename = "example.txt";
fd = open(filename, O_WRONLY | O_CREAT, 0644);
```
- **Steps**:
  1. **File Name**:
     - Declares the filename to be `example.txt`.
  2. **File Descriptor**:
     - Opens the file for writing (`O_WRONLY`).
     - Creates the file if it doesn’t exist (`O_CREAT`).
     - **Permissions**:
       - Sets file permissions (`0644`), allowing read/write access to the owner and read-only access for others.
  3. **Error Handling**:
     - If the file cannot be opened, prints an error using `perror` and terminates the program.

---

#### **3. Lock File**
```c
if (flock(fd, LOCK_EX) == -1) {
    perror("flock");
    exit(EXIT_FAILURE);
}
```
- **`flock(fd, LOCK_EX)`**:
  - Applies an exclusive lock on the file to prevent other processes from accessing it.
  - Blocks until the lock is acquired.
- **Error Handling**:
  - If locking fails, prints an error and terminates the program.

---

#### **4. Write Data to Locked File**
```c
char data[] = "This is a test message.\n";
write(fd, data, sizeof(data));
```
- **Steps**:
  1. **Prepare Data**:
     - Declares the data to be written to the file.
  2. **Write Data**:
     - Writes the message to the file using `write(fd, data, sizeof(data))`.
     - **Error Handling**:
       - If writing fails, prints an error and terminates the program.

---

#### **5. Unlock File**
```c
if (flock(fd, LOCK_UN) == -1) {
    perror("flock");
    exit(EXIT_FAILURE);
}
```
- **`flock(fd, LOCK_UN)`**:
  - Releases the lock on the file, allowing other processes to access it.
- **Error Handling**:
  - If unlocking fails, prints an error and terminates the program.

---

#### **6. Close File**
```c
if (close(fd) == -1) {
    perror("close");
    exit(EXIT_FAILURE);
}
```
- **Steps**:
  1. **Close File Descriptor**:
     - Closes the file descriptor, freeing system resources.
  2. **Error Handling**:
     - Prints an error if closing fails.

---

### **Execution Workflow**

1. **File Creation/Open**:
   - Opens or creates the file `example.txt`.
2. **Apply Lock**:
   - Acquires an exclusive lock on the file.
3. **Write Data**:
   - Writes the message `"This is a test message.\n"` to the file.
4. **Release Lock**:
   - Unlocks the file to allow other processes to access it.
5. **Close File**:
   - Closes the file descriptor.

---

### **Compiling and Running the Program**

#### **1. Compile**
```bash
gcc flock_demo.c -o flock_demo
```

#### **2. Run**
```bash
./flock_demo
```

---

### **Sample Output**
**Terminal Output**:
```
Locking file...
Writing to locked file...
Releasing lock...
Closing file...
Program completed successfully.
```

**Contents of `example.txt`**:
```
This is a test message.
```

---

### **Theory Behind `flock`**

#### **Why Use File Locking?**
1. **Prevent Race Conditions**:
   - Ensures that multiple processes do not simultaneously modify the same file.
2. **Data Integrity**:
   - Guarantees that all file modifications are safe and consistent.

#### **Advantages**
1. **Advisory Locking**:
   - Flexible; processes can choose to ignore the lock (useful for cooperative programs).
2. **Ease of Use**:
   - Simple API for locking and unlocking files.

#### **Limitations**
1. **Scope**:
   - Locks apply only to processes running on the same machine (not across networks).
2. **Advisory Nature**:
   - Non-cooperative processes can ignore the lock.

---

### **Applications**
1. **Log Files**:
   - Ensure exclusive access to logs to avoid interleaved entries.
2. **Databases**:
   - Prevent simultaneous writes to shared data records.
3. **Critical File Operations**:
   - Synchronize access to configuration or shared files.

This program demonstrates file locking using `flock` effectively. Let me know if you'd like to explore advanced locking scenarios or compare alternative locking mechanisms! 😊*/
