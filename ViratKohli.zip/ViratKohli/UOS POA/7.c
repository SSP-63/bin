


// 7.Write a program to demonstrate the exit system call use with wait & fork sysem call.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main() {
    pid_t pid;
    int status;


    printf("Parent: Before forking\n");


    pid = fork(); // Creating a child process using fork


    if (pid == -1) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        // Child process
        printf("Child: I am the child process (PID: %d)\n", getpid());
        printf("Child: Exiting with status 42\n");
        exit(42); // Child process exits with status 42
    } else {
        // Parent process
        printf("Parent: I am the parent process (PID: %d)\n", getpid());
        printf("Parent: Waiting for child to finish...\n");
        wait(&status); // Parent waits for the child process to finish
        if (WIFEXITED(status)) {
            printf("Parent: Child process exited with status: %d\n", WEXITSTATUS(status));
        } else {
            printf("Parent: Child process exited abnormally\n");
        }
    }


    return 0;
}

// #include <stdio.h>          // Standard input-output functions like printf(), perror()
// #include <stdlib.h>         // Standard library functions like exit()
// #include <unistd.h>         // Unix standard functions like fork(), getpid()
// #include <sys/types.h>      // Defines pid_t and other process-related types
// #include <sys/wait.h>       // Functions for process control like wait()

// int main() {
//     pid_t pid;             // Variable to store the process ID returned by fork()
//     int status;            // Variable to store the exit status of the child process

//     printf("Parent: Before forking\n");  // Print message before forking

//     pid = fork();          // Creating a child process using fork()

//     if (pid == -1) {       // If fork() fails, the process cannot continue
//         perror("fork failed");   // Print error message
//         exit(EXIT_FAILURE);      // Exit the program with failure status
//     } else if (pid == 0) { // If this is the child process (pid == 0)
//         printf("Child: I am the child process (PID: %d)\n", getpid());
//         // getpid() returns the process ID of the calling process (child in this case)
//         printf("Child: Exiting with status 42\n");
//         exit(42); // Child process exits with status 42
//     } else {               // If this is the parent process (pid > 0)
//         printf("Parent: I am the parent process (PID: %d)\n", getpid());
//         // getpid() returns the process ID of the calling process (parent in this case)
//         printf("Parent: Waiting for child to finish...\n");
//         wait(&status);      // Parent waits for the child process to finish

//         if (WIFEXITED(status)) {   // Check if the child process exited normally
//             printf("Parent: Child process exited with status: %d\n", WEXITSTATUS(status));
//             // WEXITSTATUS(status) retrieves the exit status of the child process
//         } else {                   // If the child process exited abnormally
//             printf("Parent: Child process exited abnormally\n");
//         }
//     }
//     return 0; // End of program
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// fork():
// - fork() creates a new process by duplicating the parent process.
// - It returns 0 in the child process and the child's process ID in the parent process.
// - If fork() fails, it returns -1.

// exit():
// - exit() terminates the current process and optionally returns a status code to the parent process.

// wait():
// - wait() makes the parent process wait until the child process finishes execution.
// - It allows the parent to check the exit status of the child process.

// WIFEXITED():
// - WIFEXITED(status) is a macro that checks if the child process terminated normally (by calling exit()).
// - It returns a non-zero value if the child process exited normally, 0 if it was terminated abnormally.

// WEXITSTATUS():
// - WEXITSTATUS(status) is a macro used to retrieve the exit status of a child process that terminated normally.
// - It is used after WIFEXITED(status) returns true to extract the exit status code.

