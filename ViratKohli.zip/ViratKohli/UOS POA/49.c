
// 49. Implement the program for IPC using MPI library (“Hello world” program).
#include <stdio.h>
#include <mpi.h>


int main(int argc, char **argv) {
        int rank, size;


        // Initialize MPI environment
        MPI_Init(&argc, &argv);


        // Get the rank of the current process
        MPI_Comm_rank(MPI_COMM_WORLD, &rank);


        // Get the total number of processes
        MPI_Comm_size(MPI_COMM_WORLD, &size);


        // Print "Hello world" message from each process
        printf("Hello world from process %d of %d\n", rank, size);


        // Finalize MPI environment
        MPI_Finalize();


        return 0;
}


// sudo apt install openmpi-bin libopenmpi-dev
//  mpicc --version


// mpicc -o 49th 49.c


/* ### **Explanation of the MPI-Based "Hello World" Program**

This program uses the **Message Passing Interface (MPI)** library to demonstrate interprocess communication (IPC). Each process prints a "Hello world" message, including its rank and the total number of processes involved.

---

### **1. Key Concepts in MPI**

#### **What is MPI?**
- **Message Passing Interface (MPI)** is a standardized and portable library for parallel programming.
- It allows multiple processes to communicate via **message passing** in distributed memory systems (e.g., clusters).

#### **Key Features**
1. **Rank**:
   - Each process in an MPI program has a unique identifier called a "rank."
   - Example: Process `0` is often the master process, while others are workers.
2. **Communicator**:
   - Defines the group of processes that can communicate.
   - Example: `MPI_COMM_WORLD` includes all processes.
3. **Portability**:
   - Works on clusters, supercomputers, and even local machines.

---

### **2. Line-by-Line Code Explanation**

#### **Initializing MPI**
```c
MPI_Init(&argc, &argv);
```
- **Purpose**:
  - Initializes the MPI environment.
  - Must be called before any MPI function.
- **Parameters**:
  - `argc` and `argv` allow command-line arguments to be passed to all processes.

---

#### **Getting Process Rank**
```c
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
```
- **Purpose**:
  - Retrieves the rank (ID) of the calling process within the communicator `MPI_COMM_WORLD`.
- **Returns**:
  - A unique integer value (`rank`), starting from `0`.

---

#### **Getting Total Number of Processes**
```c
MPI_Comm_size(MPI_COMM_WORLD, &size);
```
- **Purpose**:
  - Determines the total number of processes in the communicator.
- **Returns**:
  - The total process count (`size`).

---

#### **Printing "Hello World"**
```c
printf("Hello world from process %d of %d\n", rank, size);
```
- Each process prints its rank and the total number of processes.

---

#### **Finalizing MPI**
```c
MPI_Finalize();
```
- **Purpose**:
  - Cleans up the MPI environment and terminates MPI execution.
  - No MPI functions can be called after this.

---

### **Workflow**

1. **Initialize MPI**:
   - All processes are started and the MPI environment is set up.
2. **Query Process Information**:
   - Each process retrieves its rank and the total number of processes.
3. **Print Messages**:
   - All processes independently print their messages, displaying their rank and the total number of processes.
4. **Finalize MPI**:
   - MPI environment is cleaned up after all processes finish execution.

---

### **Compiling and Running the Program**

#### **1. Install MPI Library**
- Install OpenMPI (if not already installed):
  ```bash
  sudo apt install openmpi-bin libopenmpi-dev
  ```

#### **2. Verify Installation**
- Check if the `mpicc` compiler is available:
  ```bash
  mpicc --version
  ```

#### **3. Compile the Program**
- Use the MPI C compiler (`mpicc`) to compile the program:
  ```bash
  mpicc -o 49th 49.c
  ```

#### **4. Run the Program**
- Execute the program using `mpiexec` or `mpirun`:
  ```bash
  mpiexec -n 2 ./49th
  ```
- **`-n 2`**: Specifies the number of processes to launch.

---

### **Sample Output**
For `mpiexec -n 2 ./49th`, you might see:
```
Hello world from process 0 of 2
Hello world from process 1 of 2
```

For `mpiexec -n 4 ./49th`, you might see:
```
Hello world from process 0 of 4
Hello world from process 1 of 4
Hello world from process 2 of 4
Hello world from process 3 of 4
```
Note that the order of output may vary due to parallel execution.

---

### **Theory Behind Message Passing**

#### **Why Use MPI?**
- **Distributed Systems**:
  - MPI is essential for running programs on distributed memory systems like clusters.
- **Parallelism**:
  - Helps divide large tasks across multiple processes for faster execution.
- **Scalability**:
  - Can efficiently handle hundreds or thousands of processes.

#### **Message Passing Model**
- Processes operate independently and exchange data using explicit communication calls (e.g., send/receive operations).
- There is no shared memory; data must be passed between processes.

#### **Advantages**
1. **High Performance**:
   - Optimized for distributed systems and large-scale computations.
2. **Portability**:
   - Runs on various architectures without modification.
3. **Flexibility**:
   - Supports a range of parallel programming patterns, from point-to-point communication to collective operations.

---

### **Applications**
1. **Scientific Simulations**:
   - MPI is widely used in physics, chemistry, and other domains requiring high-performance computing.
2. **Big Data Processing**:
   - Handles parallel data analysis on distributed systems.
3. **Machine Learning**:
   - Facilitates distributed training of models across clusters.

This example demonstrates a fundamental "Hello World" program using MPI. Let me know if you'd like to explore more advanced MPI concepts, such as point-to-point communication or collective operations! 😊*/


// mpiexec -n 2 ./49th
