// 2. Write a program to use vfork system call(login name by child and password by parent)

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pwd.h>


int main() {
        pid_t pid;
        int status;


        pid = vfork(); // Creating a child process using vfork


        if (pid == -1) {
            perror("vfork failed");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            // Child process
            struct passwd *pw;
            pw = getpwuid(getuid());
            if (pw == NULL) {
                perror("getpwuid failed");
                exit(EXIT_FAILURE);
            }
            printf("Child: Login name: %s\n", pw->pw_name);
            exit(EXIT_SUCCESS);
        } else {
            // Parent process
            wait(&status); // Wait for the child to finish
            printf("Parent: Please enter your password: ");
            char password[100];
            scanf("%s", password);
            printf("Parent: Password entered: %s\n", password);
        }


        return 0;
}
// gcc -o vfork_program vfork_program.c
// ./vfork_program

// #include <stdio.h>          // Standard input-output functions like printf(), scanf()
// #include <stdlib.h>         // Standard library functions like exit(), EXIT_SUCCESS, EXIT_FAILURE
// #include <unistd.h>         // Unix standard functions like vfork(), getuid()
// #include <sys/types.h>      // Definitions for data types like pid_t
// #include <sys/wait.h>       // wait() function to synchronize with child processes
// #include <pwd.h>            // Provides getpwuid() to fetch user information

// int main() {
//         pid_t pid;           // Variable to store process ID
//         int status;          // Variable to store child's exit status

//         pid = vfork();       // vfork() creates a child process but shares the address space with the parent temporarily
//         // vfork() is used when the child immediately calls exec() or exit()
//         // Parent is suspended until the child calls exec() or exit()

//         if (pid == -1) {
//             perror("vfork failed");
//             // If vfork() fails, print error and exit
//             exit(EXIT_FAILURE);
//         } else if (pid == 0) {
//             // This block is executed by the child process

//             struct passwd *pw;          // Declare a pointer to struct passwd
//             pw = getpwuid(getuid());     // getpwuid() gets the password file entry for the current user
//             // getuid() returns the real user ID of the calling process

//             if (pw == NULL) {
//                 perror("getpwuid failed");
//                 // If fetching user information fails, print error and exit
//                 exit(EXIT_FAILURE);
//             }

//             printf("Child: Login name: %s\n", pw->pw_name);
//             // Print the login (username) of the current user

//             exit(EXIT_SUCCESS);  // Child exits successfully
//         } else {
//             // This block is executed by the parent process

//             wait(&status);
//             // Parent waits for the child to terminate
//             // The child's termination status is stored in 'status'

//             printf("Parent: Please enter your password: ");
//             // Prompt the user to enter a password

//             char password[100];   // Declare a character array to store the password
//             scanf("%s", password);
//             // Read the entered password (Warning: scanf("%s") without length specifier can cause buffer overflow)

//             printf("Parent: Password entered: %s\n", password);
//             // Print the entered password (Note: insecure in real applications)
//         }

//         return 0; // Program exits successfully
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// vfork():
// - vfork() creates a new process without copying the parent's address space.
// - The child runs first and parent is suspended until child either calls exec() or exit().
// - Faster than fork() but dangerous if child modifies variables before exec/exit.

// getuid():
// - getuid() returns the real user ID of the calling process (who started the process).

// getpwuid(uid):
// - getpwuid() retrieves the password file entry for a given user ID.
// - It returns a pointer to struct passwd containing fields like username, home directory, etc.

// wait():
// - wait() makes the parent process pause until a child process terminates.
// - Helps in proper process synchronization to avoid zombie processes.

// Process Concept:
// - After vfork(), child must not return from function or modify variables (unsafe).
// - Processes in Unix have a parent-child relationship.
// - Proper process control (fork/vfork + wait) is important for resource management.

