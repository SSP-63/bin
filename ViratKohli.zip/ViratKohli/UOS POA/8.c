// 8. Write a program to demonstrate the kill system call to send signals between unrelated processes
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>


void signal_handler(int signum) {
        printf("Signal %d received\n", signum);
}


int main() {
        pid_t pid;


        pid = fork(); // Creating a child process using fork


        if (pid == -1) {
            perror("fork failed");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            // Child process
            printf("Child: I am the child process (PID: %d)\n", getpid());
            // Register signal handler for SIGUSR1
            signal(SIGUSR1, signal_handler);
            printf("Child: Waiting for signal from parent...\n");
            while(1); // Child process waits indefinitely
        } else {
            // Parent process
            printf("Parent: I am the parent process (PID: %d)\n", getpid());
            sleep(1); // Parent process sleeps for a second to ensure child process starts
            printf("Parent: Sending signal to child...\n");
            // Send SIGUSR1 signal to the child process
            kill(pid, SIGUSR1);
        }


        return 0;
}

// #include <stdio.h>          // Standard input-output functions like printf()
// #include <stdlib.h>         // Standard library functions like exit()
// #include <unistd.h>         // Unix standard functions like fork(), getpid(), sleep()
// #include <signal.h>         // Functions for signal handling like signal(), kill()

// void signal_handler(int signum) {
//     // Signal handler function that prints a message when a signal is received
//     printf("Signal %d received\n", signum);
// }

// int main() {
//     pid_t pid;             // Variable to store the process ID returned by fork()

//     pid = fork();          // Creating a child process using fork()

//     if (pid == -1) {       // If fork() fails, the process cannot continue
//         perror("fork failed");   // Print error message
//         exit(EXIT_FAILURE);      // Exit the program with failure status
//     } else if (pid == 0) { // If this is the child process (pid == 0)
//         printf("Child: I am the child process (PID: %d)\n", getpid());
//         // getpid() returns the process ID of the calling process (child in this case)

//         signal(SIGUSR1, signal_handler); // Register signal handler for SIGUSR1
//         printf("Child: Waiting for signal from parent...\n");
//         while(1); // Child process waits indefinitely for a signal
//     } else {               // If this is the parent process (pid > 0)
//         printf("Parent: I am the parent process (PID: %d)\n", getpid());
//         sleep(1);          // Parent process sleeps for 1 second to ensure child starts first
//         printf("Parent: Sending signal to child...\n");
//         kill(pid, SIGUSR1); // Send SIGUSR1 signal to the child process
//         // kill() sends a signal to the process with the specified PID (in this case, the child)
//     }

//     return 0; // End of program
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// fork():
// - fork() creates a new process by duplicating the parent process.
// - It returns 0 in the child process and the child's process ID in the parent process.
// - If fork() fails, it returns -1.

// signal():
// - signal() is used to set up a signal handler function for a specific signal.
// - The signal handler is executed when the specified signal (e.g., SIGUSR1) is received.
// - In this case, SIGUSR1 is used to send a custom signal from the parent to the child process.

// kill():
// - kill() sends a signal to a process with a specific PID.
// - It can be used to send various signals, such as SIGKILL, SIGTERM, or custom signals (e.g., SIGUSR1).

// SIGUSR1:
// - SIGUSR1 is a user-defined signal that can be used for custom purposes.
// - In this program, SIGUSR1 is sent from the parent process to the child process to trigger the signal handler.

// sleep():
// - sleep() suspends the execution of the current process for a specified number of seconds.
// - In this case, the parent process waits for 1 second before sending the signal to the child.

