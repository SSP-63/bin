
// 40. Write a program for chatting between two/three users to demonstrate IPC using message passing (msgget, msgsnd, msgrcv ).
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <signal.h>


#define MAX_MSG_SIZE 256
#define MSG_KEY 1234


struct message {
        long mtype;
        char mtext[MAX_MSG_SIZE];
};


int main() {
        int msgid;
        struct message msg;
        key_t key;


        // Create a message queue
        key = ftok("/tmp", MSG_KEY);
        if ((msgid = msgget(key, IPC_CREAT | 0666)) == -1) {
            perror("msgget");
            exit(1);
        }


        // Fork a child process for receiving messages
        pid_t pid = fork();


        if (pid == -1) {
            perror("fork");
            exit(1);
        } else if (pid == 0) { // Child process - Receiving messages
            while (1) {
                if (msgrcv(msgid, &msg, MAX_MSG_SIZE, 1, 0) == -1) {
                    perror("msgrcv");
                    exit(1);
                }
                printf("User 1: %s\n", msg.mtext);
                printf("Enter your message (User 2): ");
                fgets(msg.mtext, MAX_MSG_SIZE, stdin);
                msg.mtype = 1;
                // Remove the newline character from the message
                msg.mtext[strcspn(msg.mtext, "\n")] = 0;
                // Send the message
                if (msgsnd(msgid, &msg, strlen(msg.mtext) + 1, 0) == -1) {
                    perror("msgsnd");
                    exit(1);
                }
            }
        } else { // Parent process - Sending messages
            while (1) {
                printf("Enter your message (User 1): ");
                fgets(msg.mtext, MAX_MSG_SIZE, stdin);
                msg.mtype = 1;
                // Remove the newline character from the message
                msg.mtext[strcspn(msg.mtext, "\n")] = 0;
                // Send the message
                if (msgsnd(msgid, &msg, strlen(msg.mtext) + 1, 0) == -1) {
                    perror("msgsnd");
                    exit(1);
                }
                if (msgrcv(msgid, &msg, MAX_MSG_SIZE, 1, 0) == -1) {
                    perror("msgrcv");
                    exit(1);
                }
                printf("User 2: %s\n", msg.mtext);
            }
        }


        // Clean up: Remove the message queue
        if (msgctl(msgid, IPC_RMID, NULL) == -1) {
            perror("msgctl");
            exit(1);
        }


        return 0;
}

/*  ### **Interprocess Communication (IPC) Through Message Passing**

This program demonstrates IPC between two users using System V message queues (`msgget`, `msgsnd`, `msgrcv`) in a C-based implementation. Below is a detailed breakdown and theoretical insights:

---

### **Key Components in the Code**

#### **1. Message Queue**
```c
#define MSG_KEY 1234
struct message {
    long mtype;       // Message type
    char mtext[MAX_MSG_SIZE]; // Message text
};
```
- **Message Queue**:
  - **`ftok`**: Generates a unique key to identify the queue.
  - **`msgget`**: Creates or retrieves a message queue using the key.
- **Structure**:
  - **`mtype`**: Identifies the message type (used to filter messages in `msgrcv`).
  - **`mtext`**: Stores the actual message text.
  - **Limit**: The message text size is capped by `MAX_MSG_SIZE`.

---

#### **2. Processes for Chat Simulation**
- **Parent Process**:
  - Sends messages (User 1).
- **Child Process**:
  - Receives messages and responds (User 2).

---

#### **3. Key IPC Functions**

##### **Message Queue Creation (`msgget`)**
```c
msgid = msgget(key, IPC_CREAT | 0666);
```
- **Purpose**:
  - Creates a message queue if it doesn’t exist (`IPC_CREAT`).
  - Sets permissions (`0666`) to allow read/write access for all users.
- **Returns**:
  - An identifier for the message queue.

---

##### **Sending a Message (`msgsnd`)**
```c
msgsnd(msgid, &msg, strlen(msg.mtext) + 1, 0);
```
- **Parameters**:
  - **`msgid`**: Identifier of the message queue.
  - **`&msg`**: Pointer to the message structure.
  - **`strlen(msg.mtext) + 1`**: Specifies the length of the message (including the null terminator).
  - **`0`**: Flags; `0` means blocking mode.
- **Operation**:
  - Sends the message to the queue.

---

##### **Receiving a Message (`msgrcv`)**
```c
msgrcv(msgid, &msg, MAX_MSG_SIZE, 1, 0);
```
- **Parameters**:
  - **`msgid`**: Identifier of the message queue.
  - **`&msg`**: Pointer to the message structure.
  - **`MAX_MSG_SIZE`**: Maximum size of the message text.
  - **`1`**: Specifies the message type to receive.
  - **`0`**: Flags; `0` means blocking mode.
- **Operation**:
  - Retrieves a message of type `1` from the queue.

---

##### **Removing the Queue (`msgctl`)**
```c
msgctl(msgid, IPC_RMID, NULL);
```
- **Purpose**:
  - Removes the message queue and releases resources.

---

### **Workflow**

1. **Initialization**:
   - Creates the message queue using `msgget`.
   - Forks a child process for concurrent communication.

2. **Communication**:
   - User 1 (parent process): Sends a message using `msgsnd`.
   - User 2 (child process): Reads the message using `msgrcv`, responds, and sends a reply back.
   - The parent process reads the reply, and the cycle repeats.

3. **Termination**:
   - The program can be terminated manually (`Ctrl+C`).
   - Before exiting, the queue is removed using `msgctl`.

---

### **Theory Behind Message Passing**

#### **1. Interprocess Communication (IPC)**
IPC allows processes to communicate and synchronize their actions. It’s essential for multitasking operating systems.

#### **2. System V Message Queues**
- **Message Queue**:
  - A kernel-managed data structure used for IPC.
  - Allows asynchronous communication via messages.
- **Advantages**:
  - Enables communication across processes, even if unrelated.
  - Persistent until removed explicitly.

#### **3. Key Functions**
- **`ftok`**:
  - Generates a unique key based on a pathname and identifier.
- **`msgget`**:
  - Creates or retrieves a message queue.
- **`msgsnd` and `msgrcv`**:
  - Send and receive messages to/from the queue.
- **`msgctl`**:
  - Controls the message queue (e.g., removal or modification).

#### **4. Synchronization**
Message queues inherently provide synchronization:
- Processes wait for messages (`msgrcv`) if the queue is empty.
- Prevents race conditions and ensures message delivery order.

---

### Example Execution

#### Compile and Run:
```bash
gcc ipc_chat.c -o ipc_chat
./ipc_chat
```

#### Output (Sample Interaction):
```
Enter your message (User 1): Hello User 2
User 1: Hello User 2
Enter your message (User 2): Hi User 1
User 2: Hi User 1
...
```

---

### **Applications**
- **Multi-User Chat Systems**:
  - This simple example can be extended for multi-user communication.
- **Distributed Systems**:
  - Message queues are widely used for task queues or inter-service communication.
- **Networking**:
  - IPC techniques like message queues are foundational for socket-based communication.

This program effectively showcases how IPC can be used to simulate real-time communication. Let me know if you'd like to explore advanced extensions, like multi-user support or shared memory-based chat systems! 😊*/
