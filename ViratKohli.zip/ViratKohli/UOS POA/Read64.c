
// READ
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
 
int main()
{
        int fd1;
 
        // FIFO file path
        char * myfifo = "/tmp/myfifo";
 
        // Creating the named file(FIFO)
        // mkfifo(<pathname>,<permission>)
        mkfifo(myfifo, 0666);
 
        char str1[80], str2[80];
        while (1)
        {
            // First open in read only and read
            fd1 = open(myfifo,O_RDONLY);
            read(fd1, str1, 80);
 
            // Print the read string and close
            printf("User1: %s\n", str1);
            close(fd1);
 
            // Now open in write mode and write
            // string taken from user.
            fd1 = open(myfifo,O_WRONLY);
            fgets(str2, 80, stdin);
            write(fd1, str2, strlen(str2)+1);
            close(fd1);
        }
        return 0;
} 
/* ### **Explanation: FIFO Communication Using a "Read" Program**

This program demonstrates **Interprocess Communication (IPC)** using **named pipes (FIFOs)**, enabling bidirectional message exchange between two processes. Below is a detailed breakdown of the code.

---

### **Step-by-Step Code Breakdown**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
```
- **`stdio.h`**: Provides input/output functions like `printf` and `fgets`.
- **`string.h`**: Allows for string manipulation like `strlen`.
- **`fcntl.h`**: Includes file descriptor control options like `O_RDONLY` and `O_WRONLY`.
- **`sys/stat.h`**: Provides constants for file permissions when creating FIFOs (`mkfifo`).
- **`unistd.h`**: Includes system calls like `read`, `write`, and `close`.

---

#### **2. Define FIFO File Path**
```c
char * myfifo = "/tmp/myfifo";
```
- **Purpose**: Specifies the location of the named pipe in the `/tmp` directory.
- **`myfifo`**: Represents the FIFO file used for message communication.

---

#### **3. Create FIFO**
```c
mkfifo(myfifo, 0666);
```
- **`mkfifo`**:
  - Creates the FIFO if it doesn’t already exist.
  - **Permissions**:
    - `0666` grants read/write access to all users.

---

#### **4. Open FIFO for Reading and Writing**
- **Open for Reading**:
  ```c
  fd1 = open(myfifo, O_RDONLY);
  read(fd1, str1, 80);
  ```
  - Opens the FIFO in read mode (`O_RDONLY`) and reads data into `str1`.

- **Open for Writing**:
  ```c
  fd1 = open(myfifo, O_WRONLY);
  fgets(str2, 80, stdin);
  write(fd1, str2, strlen(str2)+1);
  ```
  - Opens the FIFO in write mode (`O_WRONLY`) and sends user input from `str2`.

---

#### **5. Infinite Loop**
```c
while (1) { ... }
```
- Keeps the program running indefinitely for continuous message exchange.
- **Steps**:
  - Reads a message from the FIFO.
  - Displays the message on the screen.
  - Writes a user-specified response back to the FIFO.

---

#### **6. Clean Up**
- **Close the FIFO**:
  ```c
  close(fd1);
  ```
  - Closes the file descriptor after reading or writing.

---

### **Usage Instructions**

#### **Step 1: Compile and Execute the Programs**
1. **Compile Write Program**:
   ```bash
   cc -o 64write 64write.c
   ```
2. **Compile Read Program**:
   ```bash
   cc -o 64read 64read.c
   ```

#### **Step 2: Run the Programs in Two Terminals**
1. **Terminal 1** (Write Program):
   ```bash
   ./64write
   ```
2. **Terminal 2** (Read Program):
   ```bash
   ./64read
   ```

---

### **Example Interaction**

**Terminal 1 (Write Program)**:
```
User2: Hello!
User2: How are you?
```

**Terminal 2 (Read Program)**:
```
User1: Hello!
User1: How are you?
```

---

### **Theory: FIFO in IPC**

#### **What Is FIFO?**
- **First-In, First-Out** (FIFO) pipes are used for unidirectional communication between processes.
- Unlike unnamed pipes, FIFOs are persistent files stored in the filesystem.

#### **Advantages**
1. **Named Pipe**:
   - Allows communication between unrelated processes.
2. **Unidirectional Communication**:
   - Facilitates sequential message passing.

#### **Limitations**
1. **Blocking Behavior**:
   - Processes block until a corresponding read/write operation occurs.
2. **Manual Cleanup**:
   - FIFOs persist in the filesystem and must be deleted explicitly.

---

### **Applications**
1. **Message Passing**:
   - Exchange data between processes in a controlled way.
2. **Logger Systems**:
   - FIFO can collect logs from multiple sources in real-time.
3. **Producer-Consumer Models**:
   - Efficiently manage communication between producers and consumers.

Let me know if you'd like further assistance or enhancements to the program! 😊*/


// snehal@snehal-HP-Notebook:~/UOS$ cc -o 64write 64write.c
// snehal@snehal-HP-Notebook:~/UOS$ ./64write


// nehal@snehal-HP-Notebook:~/UOS$ cc -o 64read 64read.c
// snehal@snehal-HP-Notebook:~/UOS$ ./64read
