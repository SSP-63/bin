import java.io.*;
import java.net.*;

public class Client14 {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) {
        try (
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in))
        ) {
            System.out.println("Connected to the chat server.");
            System.out.println(in.readLine()); // Display server's welcome message

            // Start a new thread to listen for incoming messages
            Thread receiveThread = new Thread(() -> {
                try {
                    String message;
                    while ((message = in.readLine()) != null) {
                        System.out.println(message); // Print received message
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            receiveThread.start();

            // Send messages to the server
            String input;
            while ((input = stdin.readLine()) != null) {
                out.println(input); // Send message to server
                if (input.equalsIgnoreCase("/quit")) {
                    break; // Exit if /quit is typed
                }
            }

            receiveThread.join(); // Wait for receive thread to finish
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
//Run multiple client programs on multiple times to chat
/* Let's delve deeper into both the theory and code behind this chat application built using **Java socket programming**.

---

## **Theory Behind the Chat Application**

### **Concepts of Networking**

#### **Sockets**
1. **Definition**:
   - A socket acts as an endpoint for communication between two machines over a network. It's the core of TCP/IP communication.
2. **Types**:
   - **`ServerSocket`**:
     - Listens for incoming connection requests from clients.
   - **`Socket`**:
     - Represents an established connection between the server and the client.
3. **Communication Model**:
   - One side writes data to the socket (sending) while the other side reads data from the socket (receiving).

---

#### **TCP/IP Communication**
1. **TCP (Transmission Control Protocol)**:
   - A reliable, connection-oriented protocol.
   - Ensures messages are delivered in order and without duplication.
   - Involves three phases:
     - **Connection Establishment**: A three-way handshake (SYN, SYN-ACK, ACK).
     - **Data Transfer**: Sent as streams of data.
     - **Connection Termination**: Releases resources after the conversation.
2. **IP (Internet Protocol)**:
   - Handles routing and addressing of packets.
   - Ensures packets arrive at the correct destination.

---

#### **Multithreading in Networking**
1. **Why Use Multithreading?**
   - In a chat application, the server must handle multiple clients concurrently.
   - Each client is assigned a separate thread to manage communication independently.
2. **Thread Safety**:
   - Shared resources, like lists of connected clients or usernames, require synchronization to prevent conflicts.

---

#### **Key Features in the Chat Application**
1. **Broadcast**:
   - Sends a message from one client to all connected clients.
   - Accomplished using a list of client handlers (`clients`).
2. **Username Management**:
   - Ensures each client has a unique identifier (username) through `Set` for uniqueness.
3. **Disconnect Handling**:
   - Allows clients to leave the chat gracefully by typing `/quit`.

---

## **Detailed Explanation of the Code**

---

### **Server Code Breakdown**

#### **1. Import Required Libraries**
```java
import java.io.*;
import java.net.*;
import java.util.*;
```
- **`java.io`**: For input/output operations like reading client messages and writing responses.
- **`java.net`**: Manages networking constructs like `ServerSocket` and `Socket`.
- **`java.util`**: Utilized for managing collections like `Set` and `List`.

---

#### **2. Define Constants and Server Variables**
```java
private static final int PORT = 12345;
private static Set<String> usernames = new HashSet<>();
private static List<ClientHandler> clients = new ArrayList<>();
```
- **`PORT`**:
  - Sets the port on which the server listens for incoming connections.
  - Must match the client's configuration.
- **`usernames`**:
  - A `Set` ensures all usernames are unique.
- **`clients`**:
  - Stores active client handlers for broadcasting messages.

---

#### **3. Create and Start the Server**
```java
ServerSocket serverSocket = new ServerSocket(PORT);
```
- Creates a `ServerSocket` listening for incoming connections on the specified port.

---

#### **4. Accept Client Connections**
```java
Socket clientSocket = serverSocket.accept();
```
- Blocks until a client requests a connection.
- Establishes a `Socket` object to manage communication with the client.

---

#### **5. Handle Each Client in a Separate Thread**
```java
ClientHandler clientHandler = new ClientHandler(clientSocket);
clients.add(clientHandler);
clientHandler.start();
```
- A new `ClientHandler` thread is created for each connected client.
- The `start()` method runs the `run()` method concurrently.

---

#### **6. ClientHandler Class**
1. **Define Communication Streams**:
   ```java
   private PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
   private BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
   ```
   - **`PrintWriter`**: Sends data to the client.
   - **`BufferedReader`**: Reads data sent by the client.

2. **Request and Validate Username**:
   ```java
   out.println("Welcome to the chat server! Please enter your username:");
   username = in.readLine();
   synchronized (usernames) {
       while (usernames.contains(username)) {
           out.println("Username already taken. Please choose another one:");
           username = in.readLine();
       }
       usernames.add(username);
   }
   ```
   - Ensures each client has a unique username.
   - Uses `synchronized` to make `usernames` thread-safe.

3. **Broadcast Messages**:
   ```java
   private void broadcast(String message) {
       synchronized (clients) {
           for (ClientHandler client : clients) {
               client.out.println(message);
           }
       }
   }
   ```

4. **Handle Client Disconnection**:
   ```java
   if (username != null) {
       synchronized (usernames) {
           usernames.remove(username);
       }
       System.out.println(username + " has left the chat.");
       broadcast(username + " has left the chat.");
   }
   ```

---

### **Client Code Breakdown**

#### **1. Import Required Libraries**
```java
import java.io.*;
import java.net.*;
```
- **`java.io`**: Handles communication streams for sending and receiving messages.
- **`java.net`**: Manages the connection to the server through a `Socket`.

---

#### **2. Connect to Server**
```java
Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
```
- Creates a client-side socket to connect to the server at the specified address and port.

---

#### **3. Handle Incoming Messages**
```java
Thread receiveThread = new Thread(() -> {
    try {
        String message;
        while ((message = in.readLine()) != null) {
            System.out.println(message);
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
});
receiveThread.start();
```
- Runs a separate thread to listen for incoming messages from the server.
- Uses `BufferedReader` to read messages continuously.

---

#### **4. Send Messages to Server**
```java
String input;
while ((input = stdin.readLine()) != null) {
    out.println(input);
    if (input.equalsIgnoreCase("/quit")) {
        break;
    }
}
```
- Reads user input from the console and sends it to the server using `PrintWriter`.
- Typing `/quit` terminates the connection.

---

### **How to Run**

#### **Step 1: Compile Both Programs**
```bash
javac Server14.java Client14.java
```

#### **Step 2: Start the Server**
```bash
java Server14
```

#### **Step 3: Run Multiple Client Instances**
```bash
java Client14
```
Open multiple terminals to simulate a chat environment.

---

### **Enhancements and Future Improvements**
1. **Private Messaging**:
   - Add commands like `/msg <username>` to send private messages to specific users.
2. **User Authentication**:
   - Require a username and password for login.
3. **Logging**:
   - Save chat history to a file or database for future reference.
4. **Graphical User Interface (GUI)**:
   - Replace the command-line interface with a graphical client for better user experience.

---

### **Applications**
1. **Real-Time Communication**:
   - Build chat platforms or collaboration tools.
2. **Multiplayer Gaming**:
   - Implement chat systems for gaming environments.
3. **Education Tools**:
   - Facilitate group discussions and Q&A sessions in virtual classrooms.

This setup is robust and extensible. Let me know if you'd like a deeper dive into enhancements, debugging techniques, or scaling this application to more users! 😊*/
