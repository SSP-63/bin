23. Write a shell script to find whether given file exist or not in folder or on drive
#!/bin/bash


# Check if correct number of arguments are provided
if [ $# -ne 2 ]; then
        echo "Usage: $0 <folder_path> <file_name>"
        exit 1
fi


folder_path="$1"
file_name="$2"


# Check if the folder exists
if [ ! -d "$folder_path" ]; then
        echo "Error: Folder $folder_path does not exist"
        exit 1
fi


# Check if the file exists in the folder
if [ -e "$folder_path/$file_name" ]; then
        echo "File $file_name exists in $folder_path"
else
        echo "File $file_name does not exist in $folder_path"
fi

# omkar@omkar:~/Desktop/UOS POA$ chmod +x 23.sh
# omkar@omkar:~/Desktop/UOS POA$ ./23.sh "/home/omkar/Desktop/UOS POA" "9.c"
:'
### 🔍 **Line-by-Line Code Explanation**

This script verifies whether a given file exists within a specified folder or drive directory. It also handles incorrect input gracefully.

---

#### **1. Shebang**
```bash
#!/bin/bash
```
- Ensures the script runs in the Bash shell.
- Provides compatibility with Bash commands used in the script.

---

#### **2. Checking Number of Arguments**
```bash
if [ $# -ne 2 ]; then
    echo "Usage: $0 <folder_path> <file_name>"
    exit 1
fi
```
- **`$#`**: Represents the number of command-line arguments passed to the script.
- **Conditional**: Checks if exactly two arguments (`folder_path` and `file_name`) are provided.
- **Error Handling**:
  - Prints usage instructions if arguments are missing or invalid.
  - **`exit 1`**: Terminates the script with a status code of `1` (error).

---

#### **3. Assigning Variables**
```bash
folder_path="$1"
file_name="$2"
```
- **`$1` and `$2`**: Store the first and second command-line arguments.
- **`folder_path`**: Directory path to check.
- **`file_name`**: Name of the file to search for.

---

#### **4. Checking Folder Existence**
```bash
if [ ! -d "$folder_path" ]; then
    echo "Error: Folder $folder_path does not exist"
    exit 1
fi
```
- **`[ ! -d "$folder_path" ]`**:
  - **`-d`**: Tests if the argument is a valid directory.
  - **`!`**: Negates the condition (true if the directory doesn’t exist).
- **Error Handling**:
  - Displays an error message if the directory doesn’t exist.
  - **`exit 1`** terminates the script.

---

#### **5. Checking File Existence**
```bash
if [ -e "$folder_path/$file_name" ]; then
    echo "File $file_name exists in $folder_path"
else
    echo "File $file_name does not exist in $folder_path"
fi
```
- **`[ -e "$folder_path/$file_name" ]`**:
  - **`-e`**: Tests if the specified file exists (including regular files, symbolic links, etc.).
- **Condition**:
  - If the file exists, prints a success message.
  - Otherwise, displays a failure message.

---

### 📚 **Related Theory**

#### **Arguments (`$#`, `$1`, `$2`, `$@`)**
- **`$#`**: Number of arguments provided to the script.
- **`$1`, `$2`, etc.**: Positional parameters holding individual arguments.
- **`$@`**: Expands to all arguments passed to the script.

#### **Test Operators**
- **`-d`**: Checks if a directory exists.
- **`-e`**: Checks if a file exists.
- **`!`**: Logical NOT operator (negates conditions).

#### **Exit Codes**
- **`exit 0`**: Indicates successful execution.
- **`exit 1`**: Indicates an error occurred.

#### **Error Handling**
- **Usage Instructions**:
  - Ensure the user understands the required input format.
  - Example: **`Usage: script.sh <folder_path> <file_name>`**.

#### **Applications**
- Automating file checks across directories.
- Validating file presence before processing (e.g., backups or uploads).

---

### Example Execution

1. Make the script executable:
```bash
chmod +x script.sh
```

2. Run the script with valid inputs:
```bash
./script.sh "/home/user/folder" "example.txt"
```

Output:
- If the file exists: `File example.txt exists in /home/user/folder`.
- If the file doesn’t exist: `File example.txt does not exist in /home/user/folder`.

Let me know if you'd like to expand or adapt this functionality further! 😊
'
