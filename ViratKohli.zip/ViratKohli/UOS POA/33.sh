33. Write a shell script that will take a filename as input and check if it is executable. 2. Modify the
script in the previous question, to remove the execute permissions, if the file is executable.


1.Shell script to check if a file is executable
#!/bin/bash


# Check if correct number of arguments are provided
if [ $# -ne 1 ]; then
        echo "Usage: $0 <filename>"
        exit 1
fi


filename="$1"


# Check if the file is executable
if [ -x "$filename" ]; then
        echo "$filename is executable"
else
        echo "$filename is not executable"
fi




2.Shell script to remove execute permissions if the file is executable
#!/bin/bash


# Check if correct number of arguments are provided
if [ $# -ne 1 ]; then
        echo "Usage: $0 <filename>"
        exit 1
fi


filename="$1"

:"
### 🔍 **Detailed Explanation**

Below are two separate shell scripts that handle file execution permissions. The first checks if the file is executable, and the second modifies its permissions by removing the execute permissions.

---

### **1. Shell Script to Check if a File is Executable**
```bash
#!/bin/bash

# Check if correct number of arguments are provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <filename>"
    exit 1
fi

filename="$1"

# Check if the file is executable
if [ -x "$filename" ]; then
    echo "$filename is executable"
else
    echo "$filename is not executable"
fi
```

#### **Explanation**
1. **Input Validation**:
   - **`$#`**: Checks the number of arguments provided.
   - Ensures exactly 1 argument (the filename) is given; otherwise, prints usage instructions and exits.

2. **Executable File Check**:
   - **`-x`**: Tests whether the file has execute permissions.
   - Prints a message based on the result of the check.

---

### **2. Shell Script to Remove Execute Permissions**
```bash
#!/bin/bash

# Check if correct number of arguments are provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <filename>"
    exit 1
fi

filename="$1"

# Check if the file is executable
if [ -x "$filename" ]; then
    # Remove execute permissions
    chmod -x "$filename"
    echo "Execute permissions removed from $filename"
else
    echo "$filename is not executable"
fi
```

#### **Explanation**
1. **Input Validation**:
   - Same as the first script; checks for proper usage.

2. **Remove Execute Permissions**:
   - **`chmod -x`**: Removes execute permissions from the specified file.
   - Performs this action only if the file is executable.

3. **Permission Check**:
   - If the file isn’t executable, the script skips modifying permissions and informs the user.

---

### **How to Use the Scripts**

#### **Script 1: Check Executability**
- Run the script:
  ```bash
  ./check_executable.sh <filename>
  ```
- Example:
  ```bash
  ./check_executable.sh myscript.sh
  ```
- Output:
  - If executable: `myscript.sh is executable`.
  - If not executable: `myscript.sh is not executable`.

---

#### **Script 2: Remove Execute Permissions**
- Run the script:
  ```bash
  ./remove_execute_permission.sh <filename>
  ```
- Example:
  ```bash
  ./remove_execute_permission.sh myscript.sh
  ```
- Output:
  - If executable: `Execute permissions removed from myscript.sh`.
  - If not executable: `myscript.sh is not executable`.

---

### **Checking Permissions**
After modifying permissions, verify the changes:
```bash
ls -l <filename>
```
- **Execute permissions are visible** in the third character of the file's permission string:
  - `rwx`: Read, write, and execute permissions for the owner.
  - Example: `ls -l myscript.sh` might output:
    - Before: `-rwxr--r--` (executable).
    - After: `-rw-r--r--` (non-executable).

---

### 📚 **Theory Behind Concepts**

#### **File Permissions in Unix/Linux**
- **Permission Types**:
  - **`r` (read)**: View the file's content.
  - **`w` (write)**: Modify the file's content.
  - **`x` (execute)**: Run the file as a program/script.
- **Permission Groups**:
  - Owner (`u`), Group (`g`), Others (`o`).

#### **Test Operators**
- **`-x`**: Tests if the file is executable.
- **`-r`, `-w`**: Test for read and write permissions.

#### **Changing Permissions with `chmod`**
- **Syntax**:
  - `chmod [options] <filename>`
- **Options**:
  - `+x`: Adds execute permissions.
  - `-x`: Removes execute permissions.

#### **Applications**
- Automating permission management for scripts.
- Preventing unintended execution of sensitive files.

---

These scripts make it simple to manage file permissions. Let me know if you'd like enhancements, such as adding interactive prompts or handling multiple files! 😊
'


# Check if the file is executable
if [ -x "$filename" ]; then
        # Remove execute permissions
        chmod -x "$filename"
        echo "Execute permissions removed from $filename"
else
        echo "$filename is not executable"
fi


# To check if a file is executable:

# ./check_executable.sh <filename>

# For example:

# ./check_executable.sh myscript.sh

# This will print if the file is executable or not.
# To remove execute permissions (if the file is executable):

# ./remove_execute_permission.sh <filename>

# For example:

# ./remove_execute_permission.sh myscript.sh

# This will remove execute permissions from the file if it is executable.
# 4. Check if the Permissions Were Removed

# After running the second script, you can check if the execute permissions were removed by running:

# ls -l <filename>
