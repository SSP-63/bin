
// 9.Write a program to demonstrate the kill system call to send signals between related processes(fork)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>


void signal_handler(int signum) {
        printf("Child: Signal %d received\n", signum);
}


int main() {
        pid_t pid;


        pid = fork(); // Creating a child process using fork


        if (pid == -1) {
            perror("fork failed");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            // Child process
            printf("Child: I am the child process (PID: %d)\n", getpid());
            // Register signal handler for SIGUSR1
            signal(SIGUSR1, signal_handler);
            printf("Child: Waiting for signal from parent...\n");
            while(1); // Child process waits indefinitely
        } else {
            // Parent process
            printf("Parent: I am the parent process (PID: %d)\n", getpid());
            printf("Parent: Sending signal to child...\n");
            // Send SIGUSR1 signal to the child process
            kill(pid, SIGUSR1);
            wait(NULL); // Wait for child to finish
            printf("Parent: Child process finished\n");
        }


        return 0;
}
// #include <stdio.h>          // Standard input-output functions like printf()
// #include <stdlib.h>         // Standard library functions like exit()
// #include <unistd.h>         // Unix standard functions like fork(), getpid(), sleep()
// #include <signal.h>         // Functions for signal handling like signal(), kill()
// #include <sys/wait.h>       // Functions for handling child processes like wait()

// void signal_handler(int signum) {
//     // Signal handler function that prints a message when a signal is received
//     printf("Child: Signal %d received\n", signum);
// }

// int main() {
//     pid_t pid;             // Variable to store the process ID returned by fork()

//     pid = fork();          // Creating a child process using fork()

//     if (pid == -1) {       // If fork() fails, the process cannot continue
//         perror("fork failed");   // Print error message
//         exit(EXIT_FAILURE);      // Exit the program with failure status
//     } else if (pid == 0) { // If this is the child process (pid == 0)
//         printf("Child: I am the child process (PID: %d)\n", getpid());
//         // getpid() returns the process ID of the calling process (child in this case)

//         signal(SIGUSR1, signal_handler); // Register signal handler for SIGUSR1
//         printf("Child: Waiting for signal from parent...\n");
//         while(1); // Child process waits indefinitely for a signal
//     } else {               // If this is the parent process (pid > 0)
//         printf("Parent: I am the parent process (PID: %d)\n", getpid());
//         printf("Parent: Sending signal to child...\n");
//         kill(pid, SIGUSR1); // Send SIGUSR1 signal to the child process
//         // kill() sends a signal to the process with the specified PID (in this case, the child)

//         wait(NULL);        // Wait for the child process to finish
//         printf("Parent: Child process finished\n");
//     }

//     return 0; // End of program
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// fork():
// - fork() creates a new process by duplicating the parent process.
// - It returns 0 in the child process and the child's process ID in the parent process.
// - If fork() fails, it returns -1.

// signal():
// - signal() is used to set up a signal handler function for a specific signal.
// - The signal handler is executed when the specified signal (e.g., SIGUSR1) is received.
// - In this program, SIGUSR1 is used to send a custom signal from the parent to the child process.

// kill():
// - kill() sends a signal to a process with a specific PID.
// - It can be used to send various signals, such as SIGKILL, SIGTERM, or custom signals (e.g., SIGUSR1).
// - Here, kill(pid, SIGUSR1) sends SIGUSR1 to the child process with the given PID.

// wait():
// - wait() is used by the parent process to wait for the child process to finish.
// - The parent process will block until the child process has terminated.

