
// 59. Write a program using PIPE, to convert uppercase to lowercase filter to read command/from file
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>


#define BUFFER_SIZE 1024


int main() {
        int pipefd[2]; // File descriptors for the pipe
        pid_t pid; // Process ID


        // Create the pipe
        if (pipe(pipefd) == -1) {
            perror("pipe");
            exit(EXIT_FAILURE);
        }


        // Fork a child process
        pid = fork();


        if (pid < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        }


        if (pid > 0) { // Parent process (reads from file)
            close(pipefd[0]); // Close the reading end of the pipe in the parent


            printf("Parent: Reading from file and writing to pipe...\n");
            FILE *file = fopen("input.txt", "r");
            if (file == NULL) {
                perror("fopen");
                exit(EXIT_FAILURE);
            }


            char buffer[BUFFER_SIZE];
            ssize_t bytes_read;
            while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
                write(pipefd[1], buffer, bytes_read);
            }
            close(pipefd[1]); // Close the writing end of the pipe in the parent
            fclose(file);
        } else { // Child process (converts uppercase to lowercase)
            close(pipefd[1]); // Close the writing end of the pipe in the child


            printf("Child: Converting uppercase to lowercase...\n");
            char buffer[BUFFER_SIZE];
            ssize_t bytes_read;
            while ((bytes_read = read(pipefd[0], buffer, sizeof(buffer))) > 0) {
                for (int i = 0; i < bytes_read; ++i) {
                    if (buffer[i] >= 'A' && buffer[i] <= 'Z') {
                        buffer[i] = buffer[i] + 32; // Convert uppercase to lowercase
                    }
                }
                write(STDOUT_FILENO, buffer, bytes_read); // Write to standard output
            }
            close(pipefd[0]); // Close the reading end of the pipe in the child
        }


        return 0;
}

/* ### **Program Explanation: Filter File Content to Convert Uppercase to Lowercase Using Pipes**

This program utilizes **unnamed pipes** for interprocess communication (IPC) to transform uppercase text from a file (`input.txt`) into lowercase text, and then output it through the child process. Below is a detailed explanation of the workflow, code logic, and concepts.

---

### **Key Concepts: Unnamed Pipes**

#### **What is an Unnamed Pipe?**
1. **Definition**:
   - A pipe is a unidirectional communication mechanism for exchanging data between processes.
   - Unnamed pipes are temporary, existing only while the processes (parent and child) are active.
2. **Key Features**:
   - **Unidirectional**: Data flows in one direction (parent writes, child reads).
   - **Anonymous**: No persistent identifier in the filesystem, unlike FIFOs (named pipes).

---

### **Code Breakdown**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
```
- **`unistd.h`**: Provides pipe-related functions (`pipe`, `write`, `read`, etc.) and process control (`fork`).

---

#### **2. Define Constants**
```c
#define BUFFER_SIZE 1024
```
- **`BUFFER_SIZE`**:
  - Sets the size of the buffer used for reading and writing data between the processes.

---

#### **3. Declare Pipe and Process Variables**
```c
int pipefd[2]; // File descriptors for the pipe
pid_t pid; // Process ID
```
- **`pipefd[2]`**:
  - Array for file descriptors:
    - `pipefd[0]`: Reading end.
    - `pipefd[1]`: Writing end.
- **`pid`**:
  - Stores the process ID returned by `fork`.

---

#### **4. Create the Pipe**
```c
if (pipe(pipefd) == -1) {
    perror("pipe");
    exit(EXIT_FAILURE);
}
```
- **`pipe(pipefd)`**:
  - Initializes a unidirectional communication channel.
  - Returns `0` on success; `-1` on failure.
- **Error Handling**:
  - Prints an error and terminates the program if pipe creation fails.

---

#### **5. Fork the Process**
```c
pid = fork();
```
- **`fork()`**:
  - Creates a new child process that runs concurrently with the parent process.
  - Returns:
    - `0` for the child process.
    - Positive value (child's PID) for the parent process.
    - `-1` on failure.
- **Error Handling**:
  - Prints an error and exits if fork fails.

---

#### **6. Parent Process Logic**
```c
if (pid > 0) {
    close(pipefd[0]); // Close reading end
    FILE *file = fopen("input.txt", "r");
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        write(pipefd[1], buffer, bytes_read);
    }
    close(pipefd[1]);
    fclose(file);
}
```
- **Steps**:
  1. **Close the reading end**:
     - Parent writes data, so it closes the reading end (`pipefd[0]`).
  2. **Open the input file**:
     - Reads the contents of `input.txt` using `fopen`.
     - **Error Handling**:
       - If the file cannot be opened, `perror` prints the error message and exits.
  3. **Write file content to the pipe**:
     - Reads chunks of data from `input.txt` using `fread`.
     - Sends the data through the pipe using `write`.
  4. **Close resources**:
     - Closes the writing end of the pipe and the file.

---

#### **7. Child Process Logic**
```c
else if (pid == 0) {
    close(pipefd[1]); // Close writing end
    while ((bytes_read = read(pipefd[0], buffer, sizeof(buffer))) > 0) {
        for (int i = 0; i < bytes_read; ++i) {
            if (buffer[i] >= 'A' && buffer[i] <= 'Z') {
                buffer[i] = buffer[i] + 32; // Convert uppercase to lowercase
            }
        }
        write(STDOUT_FILENO, buffer, bytes_read); // Output to the console
    }
    close(pipefd[0]);
}
```
- **Steps**:
  1. **Close the writing end**:
     - Child only reads data, so it closes the writing end (`pipefd[1]`).
  2. **Read data from the pipe**:
     - Retrieves chunks of data written by the parent using `read`.
  3. **Filter data**:
     - Converts uppercase letters to lowercase using ASCII manipulation (`buffer[i] + 32`).
  4. **Output filtered data**:
     - Writes the modified text to the standard output (`STDOUT_FILENO`).
  5. **Close resources**:
     - Closes the reading end of the pipe.

---

### **Execution Workflow**

1. **Parent Process**:
   - Reads the content of `input.txt`.
   - Sends the data through the pipe to the child process.
2. **Child Process**:
   - Reads data from the pipe.
   - Converts uppercase letters to lowercase.
   - Outputs the filtered content to the console.

---

### **Compiling and Running the Program**

#### **1. Compile the Program**
```bash
gcc filter_pipe.c -o filter_pipe
```

#### **2. Create an Input File**
Create a file named `input.txt` and populate it with uppercase and lowercase text.

#### **3. Run the Program**
```bash
./filter_pipe
```

---

### **Sample Output**

#### **Input (`input.txt`)**:
```
HELLO World!
THIS IS A PIPE DEMO.
```

#### **Terminal Output**:
```
hello world!
this is a pipe demo.
```

---

### **Theory Behind Pipes**

#### **Advantages**
1. **Efficient IPC**:
   - Pipes provide a fast method for communication between related processes.
2. **Simple Implementation**:
   - Easy to use with basic `read`/`write` system calls.

#### **Limitations**
1. **Unidirectional**:
   - For bidirectional communication, two pipes are required.
2. **Temporary**:
   - Pipes exist only while the processes are active.

---

### **Applications**
1. **Text Filters**:
   - Process or modify data (e.g., converting text formats).
2. **Data Streaming**:
   - Real-time processing of data between processes.
3. **Command Pipelines**:
   - Similar to shell pipelines (`ls | grep`).

Let me know if you'd like additional features, such as writing the filtered output to a file or integrating bidirectional communication! 😊*/
