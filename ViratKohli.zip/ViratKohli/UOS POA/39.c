
// 39. Write a program to implement reader-writers problem using semaphore.
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h> // Include for usleep


#define NUM_READERS 5
#define NUM_WRITERS 2


sem_t mutex, write_mutex;
int readers_count = 0;
int shared_resource = 0;


void *reader(void *arg) {
        int id = *((int *)arg);
        while (1) {
            sem_wait(&mutex);
            readers_count++;
            if (readers_count == 1) {
                sem_wait(&write_mutex);
            }
            sem_post(&mutex);


            // Reading shared resource
            printf("Reader %d read: %d\n", id, shared_resource);


            sem_wait(&mutex);
            readers_count--;
            if (readers_count == 0) {
                sem_post(&write_mutex);
            }
            sem_post(&mutex);
            
            // Simulating some delay
            usleep(100000);
        }
}


void *writer(void *arg) {
        int id = *((int *)arg);
        while (1) {
            sem_wait(&write_mutex);
            
            // Writing to shared resource
            shared_resource++;
            printf("Writer %d wrote: %d\n", id, shared_resource);
            
            sem_post(&write_mutex);


            // Simulating some delay
            usleep(200000);
        }
}


int main() {
        pthread_t readers[NUM_READERS], writers[NUM_WRITERS];
        int reader_ids[NUM_READERS], writer_ids[NUM_WRITERS];


        sem_init(&mutex, 0, 1);
        sem_init(&write_mutex, 0, 1);


        for (int i = 0; i < NUM_READERS; i++) {
            reader_ids[i] = i + 1;
            pthread_create(&readers[i], NULL, reader, &reader_ids[i]);
        }


        for (int i = 0; i < NUM_WRITERS; i++) {
            writer_ids[i] = i + 1;
            pthread_create(&writers[i], NULL, writer, &writer_ids[i]);
        }


        for (int i = 0; i < NUM_READERS; i++) {
            pthread_join(readers[i], NULL);
        }


        for (int i = 0; i < NUM_WRITERS; i++) {
            pthread_join(writers[i], NULL);
        }


        sem_destroy(&mutex);
        sem_destroy(&write_mutex);


        return 0;
}

/*  ### **Reader-Writers Problem Explanation**

The reader-writers problem is a classic synchronization issue that arises when multiple threads (readers and writers) need to access a shared resource:
1. **Readers**: Need concurrent read access to the shared resource without interference.
2. **Writers**: Need exclusive write access to the shared resource.

The goal is to ensure:
- No writer modifies the shared resource while readers are reading.
- Only one writer can write to the shared resource at any given time.
- Multiple readers can read the shared resource simultaneously.

---

### **Key Concepts in the C Implementation**

#### **1. Shared Variables**
```c
int readers_count = 0;
int shared_resource = 0;
```
- **`readers_count`**:
  - Tracks the number of active readers.
  - Ensures writers wait until all readers finish reading.
- **`shared_resource`**:
  - Represents the resource being accessed.

---

#### **2. Semaphores**
```c
sem_t mutex, write_mutex;
```
- **`mutex`**:
  - Protects access to `readers_count`.
  - Ensures mutual exclusion for updating the reader count.
- **`write_mutex`**:
  - Protects access to `shared_resource`.
  - Prevents simultaneous writes or interference during reads.

#### **Semaphore Functions**:
- **Initialization**:
  ```c
  sem_init(&mutex, 0, 1);
  sem_init(&write_mutex, 0, 1);
  ```
  - Initializes `mutex` and `write_mutex` as binary semaphores.
- **Wait (`sem_wait`)**:
  - Decrements the semaphore value and blocks if the value is `0`.
- **Signal (`sem_post`)**:
  - Increments the semaphore value and wakes up waiting threads.
- **Destroy (`sem_destroy`)**:
  - Frees resources allocated for semaphores.

---

#### **3. Reader Logic**
```c
sem_wait(&mutex);
readers_count++;
if (readers_count == 1) {
    sem_wait(&write_mutex);
}
sem_post(&mutex);

// Reading shared resource
printf("Reader %d read: %d\n", id, shared_resource);

sem_wait(&mutex);
readers_count--;
if (readers_count == 0) {
    sem_post(&write_mutex);
}
sem_post(&mutex);
```
- **Steps**:
  1. Acquire the `mutex` to safely increment `readers_count`.
  2. If the first reader, acquire `write_mutex` to block writers.
  3. Release the `mutex` and read the resource.
  4. Acquire the `mutex` again to decrement `readers_count`.
  5. If the last reader, release `write_mutex` to allow writers.
  6. Release the `mutex`.

---

#### **4. Writer Logic**
```c
sem_wait(&write_mutex);
// Writing to shared resource
shared_resource++;
printf("Writer %d wrote: %d\n", id, shared_resource);
sem_post(&write_mutex);
```
- **Steps**:
  1. Acquire `write_mutex` for exclusive access to the shared resource.
  2. Write to the resource.
  3. Release `write_mutex`.

---

#### **5. Main Function**
```c
pthread_create(&readers[i], NULL, reader, &reader_ids[i]);
pthread_create(&writers[i], NULL, writer, &writer_ids[i]);
```
- Creates reader and writer threads using `pthread_create`.
- Assigns unique IDs to each thread for easier identification in logs.

---

### **Workflow of the Program**

1. **Readers**:
   - Multiple readers can read simultaneously if no writer is active.
   - The first reader blocks writers, and the last reader releases writers.

2. **Writers**:
   - Writers wait until no readers are active.
   - Only one writer can access the shared resource at a time.

---

### **Theory Behind Synchronization**

#### **1. Semaphores**
- Synchronization primitive used to coordinate threads.
- **Binary Semaphore**:
  - Acts like a mutex with values `0` (locked) or `1` (unlocked).
- **Counting Semaphore**:
  - Tracks resource availability.

#### **2. Critical Section**
- The portion of code where shared resources are accessed.
- Requires synchronization to prevent race conditions.

#### **3. Race Conditions**
- Occur when threads access shared data simultaneously, leading to unpredictable outcomes.
- Proper synchronization (e.g., using semaphores) avoids such issues.

#### **4. Starvation**
- Happens when one type of thread (readers or writers) is indefinitely delayed.
- This solution prevents starvation using fair semaphore usage.

---

### **Applications**

- **Database Systems**:
  - Ensure readers (queries) can access data without being blocked by writers (updates).
- **File Systems**:
  - Synchronize access to files between processes.
- **Networking**:
  - Manage simultaneous read/write operations on shared buffers.

---

### Example Execution

#### **Compile and Run**:
```bash
gcc -pthread reader_writer.c -o reader_writer
./reader_writer
```

#### Output:
```
Reader 1 read: 0
Reader 2 read: 0
Writer 1 wrote: 1
Reader 3 read: 1
Writer 2 wrote: 2
...
```

This output demonstrates readers and writers accessing the shared resource synchronously.

---

This implementation showcases efficient synchronization for the reader-writers problem. Let me know if you'd like additional features, such as prioritizing writers or limiting the number of readers! 😊*/
