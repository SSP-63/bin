
// CLIENT:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>


#define PORT 8080
#define BUFFER_SIZE 1024


int main() {
        int sock = 0;
        struct sockaddr_in serv_addr;
        char buffer[BUFFER_SIZE] = {0};


        // Create TCP socket
        if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
            perror("socket failed");
            exit(EXIT_FAILURE);
        }


        // Prepare sockaddr_in structure
        serv_addr.sin_family = AF_INET;
        serv_addr.sin_port = htons(PORT);


        // Convert IPv4 and IPv6 addresses from text to binary form
        if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
            perror("inet_pton");
            exit(EXIT_FAILURE);
        }


        // Connect to server
        if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
            perror("connect");
            exit(EXIT_FAILURE);
        }


        // Receive message from server
        read(sock, buffer, BUFFER_SIZE);
        printf("Message from server: %s\n", buffer);


        // Close the socket
        close(sock);
        return 0;
}


// gcc -o server server.c
// gcc -o client client.c


// ./server
// ./client

/* ### **Client-Server Communication Using TCP Sockets**

This program demonstrates a simple **client-server communication** model using **TCP sockets**. Below is a detailed explanation of the **client-side code** and how to run it alongside its corresponding server.

---

### **Step-by-Step Code Explanation**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
```
- **`stdio.h`**: Provides functions like `printf` and `perror`.
- **`stdlib.h`**: Contains utility functions like `exit`.
- **`string.h`**: Used for string manipulation (e.g., `memset`).
- **`unistd.h`**: Provides system call wrappers like `close`.
- **`arpa/inet.h`**: Includes networking-specific structures and functions, such as `inet_pton` for IP address conversion.

---

#### **2. Define Constants**
```c
#define PORT 8080
#define BUFFER_SIZE 1024
```
- **`PORT`**: Specifies the port on which the server is listening.
- **`BUFFER_SIZE`**: Defines the maximum size of the buffer for message exchange.

---

#### **3. Create TCP Socket**
```c
sock = socket(AF_INET, SOCK_STREAM, 0);
```
- **Purpose**: Creates a socket endpoint for communication.
- **Parameters**:
  - `AF_INET`: Specifies IPv4 address family.
  - `SOCK_STREAM`: Indicates TCP protocol (connection-oriented).
  - `0`: Selects the default protocol for the given type.
- **Error Handling**:
  - If `socket` creation fails, `perror` prints the error message and the program exits.

---

#### **4. Prepare Server Address Structure**
```c
serv_addr.sin_family = AF_INET;
serv_addr.sin_port = htons(PORT);
inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);
```
- **Fields**:
  - `sin_family`: Specifies the address family (IPv4 in this case).
  - `sin_port`: Sets the port number using `htons` (converts host byte order to network byte order).
  - `sin_addr`: Converts and assigns the server IP address in binary form using `inet_pton`.
- **Error Handling for `inet_pton`**:
  - If IP address conversion fails, an error message is displayed, and the program exits.

---

#### **5. Connect to the Server**
```c
connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
```
- **Purpose**: Establishes a connection to the server.
- **Parameters**:
  - `sock`: The socket created earlier.
  - `serv_addr`: The server's address and port information.
  - `sizeof(serv_addr)`: Size of the address structure.
- **Error Handling**:
  - If the connection fails, an error message is displayed, and the program exits.

---

#### **6. Read Data from Server**
```c
read(sock, buffer, BUFFER_SIZE);
printf("Message from server: %s\n", buffer);
```
- **Purpose**: Receives a message from the server through the connected socket.
- **Error Handling**:
  - Prints the received message stored in `buffer`.

---

#### **7. Close the Socket**
```c
close(sock);
```
- **Purpose**: Releases resources associated with the socket after communication is complete.

---

### **Execution Workflow**

#### **1. Compile**
Compile both the client and server programs:
```bash
gcc -o server server.c
gcc -o client client.c
```

#### **2. Run the Server**
Start the server in the first terminal:
```bash
./server
```

#### **3. Run the Client**
Execute the client in a new terminal:
```bash
./client
```

---

### **Sample Output**

**Terminal 1 (Server)**:
```
Server started and waiting for connections...
Connection established with client.
Message sent: Hello, Client!
```

**Terminal 2 (Client)**:
```
Message from server: Hello, Client!
```

---

### **Networking Concepts**

#### **What is TCP?**
- **Transmission Control Protocol** (TCP) is a connection-oriented protocol that ensures reliable delivery of data between two endpoints.

#### **How Client-Server Communication Works**
1. **Server**:
   - Listens on a specified port for incoming connections.
   - Establishes a connection with the client.
   - Sends a message to the connected client.
2. **Client**:
   - Initiates a connection to the server.
   - Receives messages and optionally sends responses.

---

### **Applications**
1. **Chat Applications**:
   - Use TCP for real-time messaging between users.
2. **Web Servers**:
   - Handle client requests for resources (e.g., HTML pages).
3. **File Transfer**:
   - Use sockets to transfer files between clients and servers.

Let me know if you'd like me to add enhancements, such as handling multiple clients or supporting bidirectional communication! 😊*/
