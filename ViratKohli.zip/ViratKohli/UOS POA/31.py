# 31. Take any txt file and count word frequencies in a file.(hint : file handling + basics )
def count_word_frequencies(file_path):
        word_freq = {}


        with open(file_path, 'r') as file:
            # Read each line from the file
            for line in file:
                # Split the line into words
                words = line.split()


                # Count the frequencies of words
                for word in words:
                    # Remove punctuation and convert to lowercase
                    word = word.strip().lower().strip('.,?!')


                    # Increment the frequency count for the word
                    word_freq[word] = word_freq.get(word, 0) + 1


        return word_freq


# Path to the text file
file_path = 'sample.txt'  # Change this to the path of your text file




# Count word frequencies in the file
word_freq = count_word_frequencies(file_path)


# Print word frequencies
for word, freq in word_freq.items():
        print(f'{word}: {freq}')

"""
### 🔍 **Code Explanation**

This Python script reads a text file, processes its content, and calculates the frequency of each word in the file. It effectively demonstrates file handling, basic string operations, and dictionary usage.

---

### **1. Function Definition: `count_word_frequencies`**
```python
def count_word_frequencies(file_path):
    word_freq = {}
```
- **Purpose**: Counts the occurrence of each word in the given file.
- **`word_freq`**: A dictionary where:
  - Keys are unique words.
  - Values are their corresponding frequencies.

---

### **2. Opening the File**
```python
    with open(file_path, 'r') as file:
```
- **`open(file_path, 'r')`**: Opens the file in read mode.
- **`with`**: Ensures the file is properly closed after its content is processed, even if an error occurs.

---

### **3. Reading and Processing Lines**
```python
        for line in file:
            words = line.split()
```
- Iterates through each line in the file.
- **`line.split()`**:
  - Splits the line into words based on whitespace.
  - Returns a list of words.

---

### **4. Cleaning and Counting Words**
```python
            for word in words:
                word = word.strip().lower().strip('.,?!')
                word_freq[word] = word_freq.get(word, 0) + 1
```
- **Cleaning**:
  - **`word.strip()`**: Removes leading and trailing spaces or unwanted characters.
  - **`word.lower()`**: Converts the word to lowercase to avoid case sensitivity.
  - **`word.strip('.,?!')`**: Removes specific punctuation from the word.
- **Counting**:
  - **`word_freq.get(word, 0)`**: Retrieves the current frequency of the word or `0` if it's not already in the dictionary.
  - Increments the count by 1.

---

### **5. Returning the Word Frequency Dictionary**
```python
        return word_freq
```
- After processing all lines, the function returns the `word_freq` dictionary.

---

### **6. File Path and Function Call**
```python
file_path = 'sample.txt'  # Change this to the path of your text file
word_freq = count_word_frequencies(file_path)
```
- **`file_path`**: Path to the text file. Modify as needed.
- Calls `count_word_frequencies` to process the specified file.

---

### **7. Printing the Word Frequencies**
```python
for word, freq in word_freq.items():
    print(f'{word}: {freq}')
```
- Iterates through the `word_freq` dictionary.
- Prints each word and its frequency in the format `word: frequency`.

---

### 📚 **Theory Behind Concepts**

#### **File Handling in Python**
- **`open(file_path, mode)`**:
  - Opens a file in the specified mode (`'r'` for reading).
  - Modes include `'r'` (read), `'w'` (write), `'a'` (append), and `'rb'`/`'wb'` (binary modes).
- **File Iteration**:
  - Reading line by line ensures efficient memory usage, especially for large files.
- **Closing Files**:
  - Using `with open()` ensures proper file closure.

#### **String Operations**
- **`split()`**: Splits a string into a list of words.
- **`strip()`**: Removes unwanted spaces or characters.
- **`lower()`**: Converts text to lowercase for uniformity.

#### **Dictionaries**
- **`dict.get(key, default)`**:
  - Returns the value associated with the key.
  - If the key doesn't exist, returns the default value (`0` in this case).
- Dynamic and efficient for tracking word counts.

---

### **Example Execution**

#### Input (`sample.txt`):
```
Hello, World! Hello Python.
Python is great, isn't it?
```

#### Output:
```
hello: 2
world: 1
python: 2
is: 1
great: 1
isn't: 1
it: 1
```

---

This script is a straightforward yet powerful demonstration of text processing. Let me know if you'd like to extend it—for example, by ignoring stop words (e.g., "is," "the") or handling additional edge cases! 😊
"""
