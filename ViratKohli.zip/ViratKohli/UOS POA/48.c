
// 48. Using OpemnMP library write a program in which master thread count the total no. of threads created, and others will print their thread numbers.
#include <stdio.h>
#include <omp.h>


int main() {
        int total_threads, thread_id;


        // Start parallel region
        #pragma omp parallel private(thread_id)
        {
            thread_id = omp_get_thread_num();
            // Only master thread counts total number of threads
            #pragma omp master
            {
                total_threads = omp_get_num_threads();
                printf("Total number of threads: %d\n", total_threads);
            }
            printf("Thread number: %d\n", thread_id);
        }


        return 0;
}
// gcc -fopenmp -o master_thread 48.c

// This will create an executable file named master_thread.

// Run the Executable: Now, execute the compiled program:

// ./master_thread

/*  ### **Using OpenMP to Manage Threads**

This program uses the OpenMP library to create a parallel region where the **master thread** counts the total number of threads created, while other threads print their thread IDs. Below is a detailed explanation of the code, OpenMP constructs, and relevant theoretical insights.

---

### **Line-by-Line Code Explanation**

#### **1. Include OpenMP Library**
```c
#include <omp.h>
```
- OpenMP is a shared-memory multiprocessing library.
- Provides APIs for thread management and parallel execution.

#### **2. Declare Variables**
```c
int total_threads, thread_id;
```
- **`total_threads`**:
  - Stores the count of threads created in the parallel region.
- **`thread_id`**:
  - Stores the unique ID assigned to each thread.

---

#### **3. Define Parallel Region**
```c
#pragma omp parallel private(thread_id)
```
- **Purpose**:
  - Starts the parallel region, enabling multiple threads to execute the enclosed block of code concurrently.
- **Key Features**:
  - **`private(thread_id)`**:
    - Declares `thread_id` as private to each thread, ensuring no data races occur.

---

#### **4. Master Thread Counts Total Threads**
```c
#pragma omp master
{
    total_threads = omp_get_num_threads();
    printf("Total number of threads: %d\n", total_threads);
}
```
- **`#pragma omp master`**:
  - Restricts the enclosed block to execute only by the master thread (thread with ID `0`).
- **Function Used**:
  - **`omp_get_num_threads()`**:
    - Returns the total number of threads created in the parallel region.

---

#### **5. Print Thread Numbers**
```c
thread_id = omp_get_thread_num();
printf("Thread number: %d\n", thread_id);
```
- **Function Used**:
  - **`omp_get_thread_num()`**:
    - Returns the unique ID of the calling thread.
- **Thread IDs**:
  - Sequentially assigned (starting from `0` for the master thread).

---

#### **6. End Parallel Region**
The parallel region ends when the block enclosed by `#pragma omp parallel` is completed. Each thread terminates its execution at this point.

---

### **Compiling and Running the Program**

#### **Compilation**
```bash
gcc -fopenmp -o master_thread 48.c
```
- **`-fopenmp`**:
  - Enables OpenMP support in GCC.

#### **Execution**
```bash
./master_thread
```

---

### **Sample Output**
```
Total number of threads: 4
Thread number: 0
Thread number: 1
Thread number: 2
Thread number: 3
```
- The number of threads may vary based on system settings or environment variables.

---

### **Theory Behind OpenMP and Parallelization**

#### **1. Parallel Region**
- **Purpose**:
  - Divides the workload across multiple threads.
- **Construct**:
  - **`#pragma omp parallel`**:
    - Initiates a parallel region.

#### **2. Master Thread**
- **Characteristics**:
  - The master thread is responsible for certain operations (e.g., gathering global information).
- **Construct**:
  - **`#pragma omp master`**:
    - Specifies a block of code to execute only by the master thread.

#### **3. Thread Management**
- **`omp_get_thread_num`**:
  - Provides a unique ID for each thread in the parallel region.
- **`omp_get_num_threads`**:
  - Returns the total number of threads active in the parallel region.

#### **4. Advantages of Parallelization**
1. **Improved Performance**:
   - Accelerates computational tasks by utilizing multiple CPU cores.
2. **Scalable**:
   - Efficiently handles large workloads across dynamic hardware configurations.

---

### **Applications**
1. **Multithreaded Programming**:
   - Optimized execution of complex tasks in scientific simulations or data processing.
2. **Parallel Debugging**:
   - Helps identify thread behavior and resource contention issues.
3. **System Performance Monitoring**:
   - Evaluates thread-level performance and distribution.

Feel free to share any specific requirements or questions for expanding this program further! 😊*/
