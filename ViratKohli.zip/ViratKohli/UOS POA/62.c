
// 62. Write a program to demonstrate the lockf system call for locking.
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>


int main() {
        int fd;
        char *filename = "example.txt";
        char data[] = "This is a test message.\n";


        // Open or create the file
        fd = open(filename, O_WRONLY | O_CREAT, 0644);
        if (fd == -1) {
            perror("open");
            exit(EXIT_FAILURE);
        }


        // Lock a portion of the file
        printf("Locking file...\n");
        if (lockf(fd, F_LOCK, 0) == -1) {
            perror("lockf");
            exit(EXIT_FAILURE);
        }


        // Write to the file
        printf("Writing to locked file...\n");
        if (write(fd, data, sizeof(data)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }


        // Release the lock
        printf("Releasing lock...\n");
        if (lockf(fd, F_ULOCK, 0) == -1) {
            perror("lockf");
            exit(EXIT_FAILURE);
        }


        // Close the file
        printf("Closing file...\n");
        if (close(fd) == -1) {
            perror("close");
            exit(EXIT_FAILURE);
        }


        printf("Program completed successfully.\n");


        return 0;
}
/*### **Program Explanation: Demonstrating the `lockf` System Call**

This program demonstrates the use of the **`lockf` system call** for locking and unlocking portions of a file in a safe and concurrent environment. Below is a detailed breakdown of how the program works and the concept behind file locking.

---

### **What is `lockf`?**

#### **Purpose**
- `lockf` is a system call used to lock and unlock sections of a file.
- It prevents simultaneous access to the file by multiple processes, ensuring data consistency and avoiding race conditions.

#### **Types of Locks**
1. **Exclusive Lock (`F_LOCK`)**:
   - Prevents other processes from reading or writing to the locked region.
2. **Unlock (`F_ULOCK`)**:
   - Releases the lock on the file, allowing other processes to access it.

---

### **Detailed Code Explanation**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
```
- **`fcntl.h`**: Provides definitions for file control options (`O_WRONLY`, `F_LOCK`, etc.).
- **`unistd.h`**: Includes system calls like `lockf`.

---

#### **2. Declare and Open the File**
```c
int fd;
char *filename = "example.txt";
fd = open(filename, O_WRONLY | O_CREAT, 0644);
```
- **`open`**:
  - Opens the file `example.txt` for writing. If the file doesn't exist, it creates one with permissions `0644` (read/write for the owner, read-only for others).
- **Error Handling**:
  - If the file cannot be opened, prints an error message using `perror` and exits.

---

#### **3. Lock the File**
```c
if (lockf(fd, F_LOCK, 0) == -1) {
    perror("lockf");
    exit(EXIT_FAILURE);
}
```
- **`lockf(fd, F_LOCK, 0)`**:
  - Locks the entire file (`0` signifies the whole file).
  - Blocks other processes from accessing the file until it is unlocked.
- **Error Handling**:
  - If locking fails, prints an error message and exits.

---

#### **4. Write to the Locked File**
```c
char data[] = "This is a test message.\n";
write(fd, data, sizeof(data));
```
- **`write(fd, data, sizeof(data))`**:
  - Writes the contents of `data` into the locked file.
- **Error Handling**:
  - If writing fails, prints an error and exits.

---

#### **5. Unlock the File**
```c
if (lockf(fd, F_ULOCK, 0) == -1) {
    perror("lockf");
    exit(EXIT_FAILURE);
}
```
- **`lockf(fd, F_ULOCK, 0)`**:
  - Unlocks the file, allowing other processes to access it.
- **Error Handling**:
  - If unlocking fails, prints an error and exits.

---

#### **6. Close the File**
```c
if (close(fd) == -1) {
    perror("close");
    exit(EXIT_FAILURE);
}
```
- **`close(fd)`**:
  - Closes the file descriptor, releasing any system resources associated with it.
- **Error Handling**:
  - Prints an error if closing fails.

---

### **Execution Workflow**

1. **Open/Create File**:
   - The program opens or creates the file `example.txt`.
2. **Lock File**:
   - The file is locked using `lockf` to ensure no other process can write to it concurrently.
3. **Write Data**:
   - Writes a test message to the locked file.
4. **Unlock File**:
   - The file is unlocked, allowing other processes to access it.
5. **Close File**:
   - The program closes the file descriptor to free resources.

---

### **Compiling and Running the Program**

#### **1. Compile**
```bash
gcc lockf_demo.c -o lockf_demo
```

#### **2. Run**
```bash
./lockf_demo
```

---

### **Output**
**Terminal**:
```
Locking file...
Writing to locked file...
Releasing lock...
Closing file...
Program completed successfully.
```

**Contents of `example.txt`**:
```
This is a test message.
```

---

### **Theory Behind File Locking**

#### **Why Lock Files?**
1. **Prevent Race Conditions**:
   - Ensures exclusive access to a file, avoiding simultaneous writes that could corrupt data.
2. **Data Integrity**:
   - Guarantees consistency in shared file access.

---

#### **Types of File Locking**

1. **Advisory Locking**:
   - Requires all processes to cooperate; if a process ignores the lock, it can still access the file.
   - `lockf` provides advisory locking.

2. **Mandatory Locking**:
   - Enforced by the system; prevents access by other processes, even if they ignore the lock.

---

### **Applications**
1. **Log Files**:
   - Ensure that multiple processes writing to the same log file do not corrupt data.
2. **Databases**:
   - Prevent simultaneous modifications to the same records.
3. **File Operations in Distributed Systems**:
   - Synchronize file access across networked systems.

This program effectively demonstrates file locking using the `lockf` system call. Let me know if you'd like to explore alternative approaches, such as `flock` or more complex locking scenarios! 😊 */
