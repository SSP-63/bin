
// 45. Write programs to simulate linux commands cat, ls, cp, mv, head etc.
// Cat:
#include <stdio.h>


int main(int argc, char *argv[]) {
        FILE *file;
        char ch;


        if (argc < 2) {
            printf("Usage: %s <filename1> [filename2] ...\n", argv[0]);
            return 1;
        }


        for (int i = 1; i < argc; i++) {
            file = fopen(argv[i], "r");
            if (file == NULL) {
                printf("Cannot open file: %s\n", argv[i]);
                continue;
            }


            while ((ch = fgetc(file)) != EOF) {
                putchar(ch);
            }


            fclose(file);
        }


        return 0;
}


// Ls:
// #include <stdio.h>
// #include <dirent.h>


// int main() {
//         DIR *dir;
//         struct dirent *entry;


//         dir = opendir(".");
//         if (dir == NULL) {
//             perror("opendir");
//             return 1;
//         }


//         while ((entry = readdir(dir)) != NULL) {
//             printf("%s\n", entry->d_name);
//         }


//         closedir(dir);
//         return 0;
// }


// Cp:
// #include <stdio.h>


// int main(int argc, char *argv[]) {
//         FILE *src, *dest;
//         char ch;


//         if (argc != 3) {
//             printf("Usage: %s <source> <destination>\n", argv[0]);
//             return 1;
//         }


//         src = fopen(argv[1], "r");
//         if (src == NULL) {
//             perror("fopen");
//             return 1;
//         }


//         dest = fopen(argv[2], "w");
//         if (dest == NULL) {
//             perror("fopen");
//             fclose(src);
//             return 1;
//         }


//         while ((ch = fgetc(src)) != EOF) {
//             fputc(ch, dest);
//         }


//         fclose(src);
//         fclose(dest);


//         return 0;
// }






// Head:
// #include <stdio.h>


// #define DEFAULT_LINES 10


// int main(int argc, char *argv[]) {
//         FILE *file;
//         char ch;
//         int lines = DEFAULT_LINES;
//         int count = 0;


//         if (argc < 2) {
//             printf("Usage: %s <filename> [lines]\n", argv[0]);
//             return 1;
//         }


//         if (argc >= 3) {
//             lines = atoi(argv[2]);
//         }


//         file = fopen(argv[1], "r");
//         if (file == NULL) {
//             perror("fopen");
//             return 1;
//         }


//         while ((ch = fgetc(file)) != EOF && count < lines) {
//             putchar(ch);
//             if (ch == '\n') {
//                 count++;
//             }
//         }


//         fclose(file);
//         return 0;
// }



// Steps for Running the Programs:
// 1. Cat Program:

// This program simulates the cat command, which prints the contents of a file to the standard output.

//     File name: cat_program.c

//     Compile the cat_program.c:

// gcc cat_program.c -o cat_program

// Run the cat_program:

//     ./cat_program file1.txt file2.txt

//     Replace file1.txt and file2.txt with the actual filenames you want to display.

// 2. Ls Program:

// This program simulates the ls command, which lists the files and directories in the current directory.

//     File name: ls_program.c

//     Compile the ls_program.c:

// gcc ls_program.c -o ls_program

// Run the ls_program:

//     ./ls_program

//     This will list the files and directories in the current directory.

// 3. Cp Program:

// This program simulates the cp command, which copies the contents of one file to another.

//     File name: cp_program.c

//     Compile the cp_program.c:

// gcc cp_program.c -o cp_program

// Run the cp_program:

//     ./cp_program source_file.txt destination_file.txt

//     Replace source_file.txt with the file you want to copy and destination_file.txt with the destination file name.

// 4. Head Program:

// This program simulates the head command, which displays the first few lines of a file.

//     File name: head_program.c

//     Compile the head_program.c:

// gcc head_program.c -o head_program

// Run the head_program:

// ./head_program file1.txt 5

// This will display the first 5 lines of file1.txt. If you don't specify a number of lines, the program will default to 10 lines.


/* ### 📚 **Detailed Explanation of Simulated Linux Commands**

This series of programs demonstrates the functionality of key Linux commands, including `cat`, `ls`, `cp`, and `head`. Below is an in-depth explanation of the concepts, logic, and execution behind each program.

---

### **1. Simulating `cat` Command**

#### **Code Overview**
```c
FILE *file;
char ch;

// Open each file specified in the command-line arguments.
file = fopen(argv[i], "r");

// Read the file character by character using `fgetc` and output to the console.
while ((ch = fgetc(file)) != EOF) {
    putchar(ch);
}
```
- **Purpose**: Mimics the `cat` command by printing the contents of one or more files to standard output.
- **Error Handling**:
  - If a file cannot be opened, the program prints an error message and continues processing other files.
- **Use Case**:
  - Combine and display the contents of multiple files sequentially.

#### **Steps to Run**:
1. Compile:
   ```bash
   gcc cat_program.c -o cat_program
   ```
2. Execute:
   ```bash
   ./cat_program file1.txt file2.txt
   ```
3. Output:
   - Displays the contents of `file1.txt` and `file2.txt`.

---

### **2. Simulating `ls` Command**

#### **Code Overview**
```c
DIR *dir;
struct dirent *entry;

// Open the current directory using `opendir`.
dir = opendir(".");

// Iterate through directory entries using `readdir`.
while ((entry = readdir(dir)) != NULL) {
    printf("%s\n", entry->d_name);
}
```
- **Purpose**: Mimics the `ls` command by listing all files and directories in the current directory.
- **Structure**:
  - `DIR` represents the directory stream.
  - `struct dirent` contains information about individual entries (e.g., file names).
- **Error Handling**:
  - If the directory cannot be opened, prints an error message (`perror("opendir")`).

#### **Steps to Run**:
1. Compile:
   ```bash
   gcc ls_program.c -o ls_program
   ```
2. Execute:
   ```bash
   ./ls_program
   ```
3. Output:
   - Lists the contents of the current directory.

---

### **3. Simulating `cp` Command**

#### **Code Overview**
```c
FILE *src, *dest;
char ch;

// Open the source file in read mode.
src = fopen(argv[1], "r");

// Open the destination file in write mode.
dest = fopen(argv[2], "w");

// Copy each character from the source file to the destination using `fgetc` and `fputc`.
while ((ch = fgetc(src)) != EOF) {
    fputc(ch, dest);
}
```
- **Purpose**: Mimics the `cp` command by copying the contents of a source file to a destination file.
- **Error Handling**:
  - Ensures both files can be opened successfully.
  - Frees resources if errors occur.

#### **Steps to Run**:
1. Compile:
   ```bash
   gcc cp_program.c -o cp_program
   ```
2. Execute:
   ```bash
   ./cp_program source_file.txt destination_file.txt
   ```
3. Output:
   - Copies the contents of `source_file.txt` to `destination_file.txt`.

---

### **4. Simulating `head` Command**

#### **Code Overview**
```c
FILE *file;
char ch;
int count = 0;

// Open the file in read mode.
file = fopen(argv[1], "r");

// Read up to the specified number of lines using `fgetc` and track newlines.
while ((ch = fgetc(file)) != EOF && count < lines) {
    putchar(ch);
    if (ch == '\n') {
        count++;
    }
}
```
- **Purpose**: Mimics the `head` command by displaying the first few lines of a file.
- **Structure**:
  - Reads the file character by character.
  - Tracks the number of lines printed using a newline counter.
- **Error Handling**:
  - Ensures the file can be opened successfully.

#### **Steps to Run**:
1. Compile:
   ```bash
   gcc head_program.c -o head_program
   ```
2. Execute:
   ```bash
   ./head_program file1.txt 5
   ```
3. Output:
   - Displays the first 5 lines of `file1.txt`.

---

### **Core Concepts and Theory Behind Linux Command Simulation**

#### **1. File I/O in C**
- **`fopen`**: Opens a file for reading (`"r"`) or writing (`"w"`).
- **`fgetc`**: Reads a single character from a file.
- **`fputc`**: Writes a single character to a file.
- **`fclose`**: Closes an open file.

#### **2. Directory Operations**
- **`opendir`**: Opens a directory stream.
- **`readdir`**: Reads entries from the directory stream (e.g., file and subdirectory names).
- **`closedir`**: Closes the directory stream.

#### **3. Command-Line Arguments**
- **`argc`**: Represents the number of arguments passed to the program.
- **`argv`**: Contains the actual arguments as an array of strings.
  - Example: In `./cat_program file1.txt file2.txt`, `argv[1]` is `file1.txt` and `argv[2]` is `file2.txt`.

---

### **Applications and Use Cases**

1. **Educational Purposes**:
   - Helps understand how Linux commands work under the hood.
2. **Custom Command Extensions**:
   - Build customized variations of standard Linux commands.
3. **File Management**:
   - Automate file operations programmatically.

---

Feel free to share additional requirements or enhancements you'd like to explore! 😊 */
