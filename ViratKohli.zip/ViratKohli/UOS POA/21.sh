
# 21. Write a program to sort 10 the given 10 numbers in ascending order using shell.
#!/bin/bash


# Input 10 numbers
echo "Enter 10 numbers:"
read -a numbers


# Sort the numbers in ascending order
sorted_numbers=$(printf "%s\n" "${numbers[@]}" | sort -n)


# Print the sorted numbers
echo "Sorted numbers in ascending order:"
echo "$sorted_numbers"

:'
### 🔍 **Line-by-Line Code Explanation**
This script takes 10 numbers as input, sorts them in ascending order, and displays the sorted output.

---

#### **1. Prompt for Input**
```bash
echo "Enter 10 numbers:"
```
- **`echo`**: Displays a message prompting the user to input 10 numbers.

---

#### **2. Read Input**
```bash
read -a numbers
```
- **`read`**: Reads the input entered by the user.
- **`-a numbers`**: Reads the input into an array called `numbers`.
  - Example: If the user inputs `3 1 4 2 5`, the array will store `numbers[0]=3`, `numbers[1]=1`, and so on.

---

#### **3. Sorting Numbers**
```bash
sorted_numbers=$(printf "%s\n" "${numbers[@]}" | sort -n)
```
- **`printf "%s\n"`**: Prints each element of the `numbers` array on a new line.
  - **`${numbers[@]}`**: Refers to all elements of the `numbers` array.
- **Piping (`|`)**: Redirects the output of `printf` to the `sort` command.
- **`sort -n`**:
  - Sorts the input numerically (`-n`).
  - Ensures numbers are sorted in ascending order.

---

#### **4. Display Sorted Output**
```bash
echo "Sorted numbers in ascending order:"
echo "$sorted_numbers"
```
- Displays the sorted list of numbers stored in `sorted_numbers`.

---

### 📚 **Theory Behind Concepts**

#### **Bash Arrays**
- **Definition**: Arrays in Bash are collections of data indexed numerically starting from 0.
- **Accessing Elements**: Use `${array[index]}` to access a specific element, or `${array[@]}` to access all elements.

#### **Input Handling**
- **`read -a`**: Reads space-separated values into an array.
  - Suitable for inputs like a list of numbers.

#### **`printf` Command**
- **Purpose**: Formats and prints output.
- **Key Syntax**: `printf FORMAT [ARGUMENTS]`.
  - Example: `printf "%s\n" "${array[@]}"` prints each array element on a new line.

#### **Sorting**
- **`sort` Command**:
  - **`-n`**: Sorts input numerically.
  - Without `-n`, sorting is treated lexicographically (alphabetical order).

#### **Output Redirection**
- **Piping (`|`)**: Sends the output of one command as input to another.
  - Example: `printf | sort` ensures numbers are processed and sorted.

#### **Applications**
- **Sorting Algorithms**: Useful for arranging datasets or processing numeric data.
- **User-Interactive Programs**: Enhances dynamic input/output processing.

---

This script effectively demonstrates user input handling, data sorting, and output display in Bash. It's a simple yet powerful illustration of array manipulation and command chaining. Let me know if you'd like to expand on this or explore similar scripts! 😊
'
