# 29. Write a python recursive function for prime number input limit in as parameter to it.
def is_prime(n, divisor=2):
        if n <= 1:
            return False
        if n == 2:
            return True
        if n % divisor == 0:
            return False
        if divisor * divisor > n:
            return True
        return is_prime(n, divisor + 1)


def find_primes(limit, num=2):
        if num <= limit:
            if is_prime(num):
                print(num, end=" ")
            find_primes(limit, num + 1)


# Example usage:
limit = int(input("Enter the limit to find prime numbers: "))
print("Prime numbers up to", limit, "are:")
find_primes(limit)

"""
### 🔍 **Code Explanation**

This Python script uses recursion to identify and print prime numbers up to a user-specified limit.

---

### **1. Recursive Function to Check Primality (`is_prime`)**
```python
def is_prime(n, divisor=2):
    if n <= 1:
        return False
    if n == 2:
        return True
    if n % divisor == 0:
        return False
    if divisor * divisor > n:
        return True
    return is_prime(n, divisor + 1)
```
- **Purpose**: Determines whether a given number `n` is prime.
- **Arguments**:
  - `n`: The number to check.
  - `divisor`: Starts at 2 (the smallest prime number) and increments recursively.
- **Logic**:
  - **Base Cases**:
    - `n <= 1`: Non-prime numbers are less than or equal to 1.
    - `n == 2`: The smallest prime number, directly returned as `True`.
    - `n % divisor == 0`: If divisible by `divisor`, it's not a prime number.
    - `divisor * divisor > n`: No need to check divisors larger than the square root of `n`.
  - **Recursive Step**: Calls itself with the next divisor (`divisor + 1`) to continue checking.

---

### **2. Recursive Function to Find Primes (`find_primes`)**
```python
def find_primes(limit, num=2):
    if num <= limit:
        if is_prime(num):
            print(num, end=" ")
        find_primes(limit, num + 1)
```
- **Purpose**: Identifies and prints all prime numbers up to a given limit.
- **Arguments**:
  - `limit`: The upper bound to find primes.
  - `num`: Starts at 2 (the smallest prime) and increments recursively.
- **Logic**:
  - **Base Case**:
    - If `num > limit`, the recursion stops.
  - **Recursive Step**:
    - Checks if `num` is prime using `is_prime`.
    - Prints the number if it's prime.
    - Calls itself with the next number (`num + 1`).

---

### **3. Example Usage**
```python
limit = int(input("Enter the limit to find prime numbers: "))
print("Prime numbers up to", limit, "are:")
find_primes(limit)
```
- **Workflow**:
  - Accepts the upper limit as user input.
  - Invokes the `find_primes` function to display all prime numbers up to the limit.

---

### 📚 **Theory Behind Concepts**

#### **1. Recursion**
- **Definition**: A function calling itself to solve smaller instances of a problem.
- **Key Points**:
  - Base case prevents infinite recursion.
  - Recursive calls solve subproblems incrementally.

#### **2. Prime Numbers**
- A prime number is greater than 1 and divisible only by itself and 1.
- Efficient primality testing avoids divisors greater than the square root of the number.

#### **3. Python Functions**
- **Default Arguments**: Allows optional parameters (e.g., `divisor=2`).
- **Conditional Statements**: Logical checks (e.g., `if`).

---

### Example Execution

#### Input:
```
Enter the limit to find prime numbers: 10
```

#### Output:
```
Prime numbers up to 10 are:
2 3 5 7
```

---

This script effectively combines recursion with primality testing for intuitive prime number generation. Let me know if you'd like further optimizations or extensions! 😊
"""
