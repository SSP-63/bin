# 25. Write a shell script to find the given file in the system using find or locate command.
#!/bin/bash


# Check if correct number of arguments are provided
if [ $# -ne 1 ]; then
        echo "Usage: $0 <file_name>"
        exit 1
fi


file_name="$1"


# Use the find command to search for the file in the system
found_files=$(find / -name "$file_name" 2>/dev/null)


# Check if any files are found
if [ -n "$found_files" ]; then
        echo "Found the following occurrences of $file_name in the system:"
        echo "$found_files"
else
        echo "File $file_name not found in the system"
fi

# chmod +x "/home/omkar/Desktop/UOS POA/25.sh"
# bash "/home/omkar/Desktop/UOS POA/25.sh" "file_name"
# bash "/home/omkar/Desktop/UOS POA/25.sh" "test.txt"

:'
### 🔍 **Line-by-Line Explanation**

This script searches for a specific file in the system using the `find` command, handling both valid and invalid scenarios.

---

#### **1. Shebang**
```bash
#!/bin/bash
```
- Specifies that the script should be executed in the Bash shell.

---

#### **2. Argument Validation**
```bash
if [ $# -ne 1 ]; then
    echo "Usage: $0 <file_name>"
    exit 1
fi
```
- **`$#`**: Checks the number of arguments passed to the script.
  - If not exactly 1 argument is provided, the script:
    - Prints a usage guide (e.g., `Usage: ./script.sh <file_name>`).
    - Exits with a status code of `1` to indicate an error.
    
---

#### **3. Capture the File Name Argument**
```bash
file_name="$1"
```
- Assigns the first argument (expected to be the file name) to the variable `file_name`.

---

#### **4. Searching for the File**
```bash
found_files=$(find / -name "$file_name" 2>/dev/null)
```
- **`find /`**:
  - Starts searching from the root directory (`/`) to locate the specified file.
  - **`-name "$file_name"`**: Matches files with the given name (case-sensitive).
- **`2>/dev/null`**:
  - Redirects error messages (e.g., "Permission denied") to `/dev/null` to suppress them.
- **`found_files`**:
  - Captures the output (list of paths where the file is found) from the `find` command.

---

#### **5. Checking if Files are Found**
```bash
if [ -n "$found_files" ]; then
    echo "Found the following occurrences of $file_name in the system:"
    echo "$found_files"
else
    echo "File $file_name not found in the system"
fi
```
- **`-n "$found_files"`**: Checks if the `found_files` variable contains any data (non-empty).
- If matches are found:
  - Prints the message along with the file paths.
- If no matches are found:
  - Prints a message indicating the file was not found.

---

#### **6. Usage and Example Commands**
```bash
chmod +x "/home/omkar/Desktop/UOS POA/25.sh"
bash "/home/omkar/Desktop/UOS POA/25.sh" "file_name"
bash "/home/omkar/Desktop/UOS POA/25.sh" "test.txt"
```
- **Making the Script Executable**:
  - `chmod +x script.sh`: Grants execute permissions to the script.
- **Running the Script**:
  - `bash script.sh "file_name"`: Invokes the script and searches for the file `file_name`.
  - Example: `bash script.sh "test.txt"` searches for `test.txt`.

---

### 📚 **Theory Behind the Commands**

#### **`find` Command**
- Used for file and directory searches.
- **Syntax**:
  - `find [path] [options]`.
  - Example: `find /home/user -name "file.txt"` searches for `file.txt` in `/home/user`.
- **Common Options**:
  - `-name`: Matches files by name (case-sensitive).
  - `-iname`: Matches files by name (case-insensitive).
  - `-type`: Filters by file type (`f` for files, `d` for directories).

#### **Redirection (`2>/dev/null`)**
- **Purpose**: Suppresses errors caused by insufficient permissions or inaccessible directories.
- **`2>`**: Redirects standard error (file descriptor 2) to `/dev/null` (discards output).

#### **Exit Status Codes**
- **`exit 0`**: Indicates successful execution.
- **`exit 1`**: Indicates failure (e.g., incorrect usage or file not found).

#### **Applications**
- Automating file searches across directories.
- Useful in system diagnostics or verifying the presence of files.

---

This script is efficient for locating files, even on large systems. Let me know if you’d like additional features, such as searching for directories or filtering results! 😊

'
