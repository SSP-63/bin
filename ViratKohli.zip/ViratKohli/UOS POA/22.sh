
# 22. Write a program to print “Hello World” message in bold, blink effect, and in different colors like red, blue etc.
#!/bin/bash


# Bold text
echo -e "\e[1mHello World\e[0m"


# Blinking text
echo -e "\e[5mHello World\e[0m"


# Red text
echo -e "\e[31mHello World\e[0m"


# Green text
echo -e "\e[32mHello World\e[0m"


# Yellow text
echo -e "\e[33mHello World\e[0m"


# Blue text
echo -e "\e[34mHello World\e[0m"


# Magenta text
echo -e "\e[35mHello World\e[0m"


# Cyan text
echo -e "\e[36mHello World\e[0m"

:'
### 🔍 **Line-by-Line Explanation**

This script uses escape sequences to apply text formatting effects like bold, blinking, and color to the "Hello World" message.

---

#### **1. Shebang**
```bash
#!/bin/bash
```
- Specifies the script should be executed using the Bash shell.
- Ensures compatibility with Bash for text formatting commands.

---

#### **2. Printing "Hello World" in Bold**
```bash
echo -e "\e[1mHello World\e[0m"
```
- **`-e`**: Enables interpretation of escape sequences.
- **`\e[1m`**: Applies the bold effect to the text.
- **`\e[0m`**: Resets text formatting after "Hello World" to avoid affecting subsequent output.

---

#### **3. Printing "Hello World" with Blink Effect**
```bash
echo -e "\e[5mHello World\e[0m"
```
- **`\e[5m`**: Enables the blinking text effect (though support depends on the terminal being used).
- **`\e[0m`**: Resets formatting.

---

#### **4. Printing "Hello World" in Various Colors**
Each color is applied using its respective escape sequence code.

##### Red Text
```bash
echo -e "\e[31mHello World\e[0m"
```
- **`\e[31m`**: Sets the text color to red.

##### Green Text
```bash
echo -e "\e[32mHello World\e[0m"
```
- **`\e[32m`**: Sets the text color to green.

##### Yellow Text
```bash
echo -e "\e[33mHello World\e[0m"
```
- **`\e[33m`**: Sets the text color to yellow.

##### Blue Text
```bash
echo -e "\e[34mHello World\e[0m"
```
- **`\e[34m`**: Sets the text color to blue.

##### Magenta Text
```bash
echo -e "\e[35mHello World\e[0m"
```
- **`\e[35m`**: Sets the text color to magenta.

##### Cyan Text
```bash
echo -e "\e[36mHello World\e[0m"
```
- **`\e[36m`**: Sets the text color to cyan.

---

### 📚 **Related Theory**

#### **ANSI Escape Codes**
- **Purpose**: Enable text styling and color effects in terminal output.
- **Structure**: Begins with `\e[` or `\033[`, followed by formatting codes, and ends with `m`.
  - Example: `\e[31m` changes the text color to red.
- **Reset Code**: `\e[0m` resets all text formatting.

#### **Text Effects**
- **Bold (`\e[1m`)**: Makes text appear thicker or highlighted.
- **Blink (`\e[5m`)**: Adds a blinking effect (depends on terminal support).

#### **Colors**
- **Foreground Colors**:
  - `31`: Red.
  - `32`: Green.
  - `33`: Yellow.
  - `34`: Blue.
  - `35`: Magenta.
  - `36`: Cyan.

#### **Terminal Compatibility**
- Not all terminals fully support text effects (e.g., blinking).
- Modern terminals like GNOME Terminal, Konsole, or xterm often have better support.

#### **Applications**
- **Enhancing Readability**: Format important messages or warnings.
- **Aesthetic Design**: Add visually appealing effects to scripts.

---

This script showcases the use of escape codes for text formatting and colorization, making terminal outputs more engaging. If you'd like, I can help extend this to include background colors or additional text effects! 😊
'
