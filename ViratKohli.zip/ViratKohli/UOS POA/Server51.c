
// 51. Write a program for TCP to demonstrate the socket system calls in c/python


// Server:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>


#define PORT 8080
#define BUFFER_SIZE 1024


int main() {
        int server_fd, new_socket;
        struct sockaddr_in address;
        int addrlen = sizeof(address);
        char buffer[BUFFER_SIZE] = {0};
        const char *message = "Hello from server";


        // Create TCP socket
        if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
            perror("socket failed");
            exit(EXIT_FAILURE);
        }


        // Prepare the sockaddr_in structure
        address.sin_family = AF_INET;
        address.sin_addr.s_addr = INADDR_ANY;
        address.sin_port = htons(PORT);


        // Bind socket to localhost and port 8080
        if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
            perror("bind failed");
            exit(EXIT_FAILURE);
        }


        // Start listening for incoming connections
        if (listen(server_fd, 3) < 0) {
            perror("listen");
            exit(EXIT_FAILURE);
        }


        // Accept an incoming connection
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            perror("accept");
            exit(EXIT_FAILURE);
        }


        // Send message to client
        send(new_socket, message, strlen(message), 0);
        printf("Message sent to client\n");


        // Close the socket
        close(server_fd);
        return 0;
}
/* Certainly! Here's a more detailed explanation of the code provided and the underlying theory behind the TCP and UDP concepts:

---

## **TCP Server Explanation**

### **Step-by-Step Code Details**
1. **Include Required Libraries**:
   ```c
   #include <stdio.h>
   #include <stdlib.h>
   #include <string.h>
   #include <unistd.h>
   #include <arpa/inet.h>
   ```
   - **`stdio.h`**:
     - Provides input/output operations like `printf` for displaying messages and `perror` for error handling.
   - **`stdlib.h`**:
     - Includes functions like `exit()` for program termination when critical errors occur.
   - **`string.h`**:
     - Allows manipulation of strings, such as `strlen()` for calculating the size of a message.
   - **`unistd.h`**:
     - Contains system call wrappers such as `close()` to release file descriptors.
   - **`arpa/inet.h`**:
     - Includes networking structures and functions, like `sockaddr_in` for IPv4 and `inet_addr` for converting IP addresses.

2. **Create a TCP Socket**:
   ```c
   server_fd = socket(AF_INET, SOCK_STREAM, 0);
   ```
   - **Socket**:
     - Serves as an endpoint for communication.
   - **Parameters**:
     - `AF_INET`: Specifies the address family (IPv4).
     - `SOCK_STREAM`: Specifies TCP (connection-oriented protocol).
     - `0`: Uses the default protocol.
   - **Return Value**:
     - A positive integer called the **file descriptor** if successful.
     - `-1` indicates failure, leading to the `perror()` error message.

3. **Prepare the Server's Address Structure**:
   ```c
   address.sin_family = AF_INET;
   address.sin_addr.s_addr = INADDR_ANY;
   address.sin_port = htons(PORT);
   ```
   - **`sockaddr_in`**:
     - Stores server information such as its address and port.
   - **`AF_INET`**:
     - Indicates IPv4 address family.
   - **`INADDR_ANY`**:
     - Binds the socket to all available network interfaces (e.g., localhost).
   - **`htons(PORT)`**:
     - Converts the port number from host byte order to network byte order (big endian), ensuring compatibility across systems.

4. **Bind the Socket to an Address**:
   ```c
   bind(server_fd, (struct sockaddr *)&address, sizeof(address));
   ```
   - **Purpose**:
     - Links the socket to the server's address (`localhost` and port `8080`).
   - **Error Handling**:
     - If binding fails, prints `"bind failed"` and exits the program.

5. **Listen for Connections**:
   ```c
   listen(server_fd, 3);
   ```
   - Sets the socket in listening mode, allowing it to accept incoming connection requests.
   - **Parameters**:
     - `server_fd`: The socket descriptor.
     - `3`: Maximum number of pending connections in the queue.

6. **Accept Client Connection**:
   ```c
   new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
   ```
   - Blocks until a client connects to the server.
   - **Return Value**:
     - A new socket descriptor representing the client connection.

7. **Send Data to the Client**:
   ```c
   send(new_socket, message, strlen(message), 0);
   ```
   - Sends the string `"Hello from server"` to the connected client.
   - **Parameters**:
     - `new_socket`: Socket representing the client connection.
     - `message`: The data to send.
     - `strlen(message)`: The size of the data.

8. **Close the Socket**:
   ```c
   close(server_fd);
   ```
   - Releases resources associated with the socket.

---

## **Theory of TCP Communication**

### **Transmission Control Protocol (TCP)**
1. **Connection-Oriented**:
   - TCP establishes a connection between the client and server through a **handshake process** (SYN, SYN-ACK, ACK).
   - Ensures reliable delivery of data.

2. **Stream-Oriented**:
   - Data is transmitted as a continuous stream, split into packets.

3. **Error Handling**:
   - Retransmits lost packets and ensures correct delivery using acknowledgments.

4. **Use Cases**:
   - Web servers, email communication, and file transfer protocols (FTP).

---

## **UDP Server Explanation**

### **Step-by-Step Code Details**
1. **Create a UDP Socket**:
   ```c
   sockfd = socket(AF_INET, SOCK_DGRAM, 0);
   ```
   - **Socket**:
     - Provides a datagram-based endpoint for communication.
   - **Parameters**:
     - `AF_INET`: Specifies IPv4 address family.
     - `SOCK_DGRAM`: Specifies UDP (connectionless protocol).

2. **Prepare the Server's Address Structure**:
   ```c
   servaddr.sin_family = AF_INET;
   servaddr.sin_addr.s_addr = INADDR_ANY;
   servaddr.sin_port = htons(PORT);
   ```

3. **Bind the Socket**:
   ```c
   bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr));
   ```
   - Associates the socket with the server's address and port.
   - Necessary for receiving messages.

4. **Receive a Message**:
   ```c
   n = recvfrom(sockfd, buffer, BUFFER_SIZE, MSG_WAITALL, (struct sockaddr *)&cliaddr, &len);
   ```
   - Blocks until a message is received.
   - Stores the message in the `buffer` and the sender's information in `cliaddr`.

5. **Send a Response**:
   ```c
   sendto(sockfd, message, strlen(message), MSG_CONFIRM, (const struct sockaddr *)&cliaddr, len);
   ```

6. **Close the Socket**:
   ```c
   close(sockfd);
   ```

---

## **Theory of UDP Communication**

### **User Datagram Protocol (UDP)**
1. **Connectionless**:
   - Unlike TCP, UDP does not establish a connection before sending data.
   - Each packet is sent independently, without guarantees of delivery.

2. **Fast and Lightweight**:
   - Ideal for applications where speed is critical and occasional packet loss is acceptable.

3. **Use Cases**:
   - Real-time applications like streaming, gaming, and DNS queries.

---

### **Comparison of TCP and UDP**
| **Aspect**       | **TCP**                   | **UDP**                      |
|-------------------|---------------------------|------------------------------|
| **Reliability**   | Reliable (error correction)| Unreliable (no guarantee)   |
| **Connection**    | Connection-oriented       | Connectionless               |
| **Speed**         | Slower due to checks      | Faster, lightweight          |
| **Applications**  | Web, email, file transfer | Streaming, gaming, VoIP      |

---

### **Applications of Sockets**
1. **Networking Protocols**:
   - Implement HTTP, FTP, SMTP, and other protocols.
2. **Real-Time Communication**:
   - Chat applications, multiplayer games, and video conferencing.
3. **IoT Systems**:
   - Send and receive sensor data in smart devices.

Let me know if you'd like more details, examples, or extensions of these concepts! 😊*/
