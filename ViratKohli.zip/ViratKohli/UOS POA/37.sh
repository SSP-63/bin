

# 37. Write a shell script to download a given file from ftp://10.10.13.16 if it exists on ftp.(use lftp, get and mget commands).
#!/bin/bash


# FTP server details
FTP_SERVER="10.10.13.16"
FTP_USERNAME="your_username"
FTP_PASSWORD="your_password"


# File to download
FILE_TO_DOWNLOAD="example_file.txt"


# Check if file exists on the FTP server
lftp -u $FTP_USERNAME,$FTP_PASSWORD -e "ls $FILE_TO_DOWNLOAD; quit" $FTP_SERVER > /dev/null 2>&1
if [ $? -eq 0 ]; then
        # File exists, download it
        lftp -u $FTP_USERNAME,$FTP_PASSWORD -e "get $FILE_TO_DOWNLOAD; quit" $FTP_SERVER
        echo "File downloaded successfully."
else
        echo "File does not exist on the FTP server."
fi

# sudo apt update
# sudo apt install lftp
:'
### 🔍 **Line-by-Line Code Explanation**

This script utilizes the `lftp` utility to check for and download a file from an FTP server. Below is a breakdown of its functionality:

---

### **1. FTP Server Details**
```bash
FTP_SERVER="10.10.13.16"
FTP_USERNAME="your_username"
FTP_PASSWORD="your_password"
```
- **Variables**:
  - **`FTP_SERVER`**: Specifies the IP address or hostname of the FTP server.
  - **`FTP_USERNAME`** and **`FTP_PASSWORD`**: Hold the login credentials for the FTP server.
- **Note**: Replace `your_username` and `your_password` with actual credentials.

---

### **2. File to Download**
```bash
FILE_TO_DOWNLOAD="example_file.txt"
```
- Specifies the name of the file you want to download from the FTP server.
- Replace `example_file.txt` with the desired filename.

---

### **3. Checking If the File Exists**
```bash
lftp -u $FTP_USERNAME,$FTP_PASSWORD -e "ls $FILE_TO_DOWNLOAD; quit" $FTP_SERVER > /dev/null 2>&1
```
- **`lftp`**:
  - A powerful and flexible FTP/HTTP client commonly used for managing file transfers.
- **Command Details**:
  - **`-u $FTP_USERNAME,$FTP_PASSWORD`**: Logs in to the FTP server using the specified username and password.
  - **`-e "ls $FILE_TO_DOWNLOAD; quit"`**:
    - Executes `ls $FILE_TO_DOWNLOAD` to check if the file exists.
    - `quit` ensures the session terminates after the command executes.
  - **`$FTP_SERVER`**: Specifies the FTP server address.
- **Redirection (`> /dev/null 2>&1`)**:
  - Suppresses the command's output and errors, ensuring the script remains clean.
- **Exit Status (`$?`)**:
  - `0`: Indicates the file exists.
  - Non-zero: Indicates the file does not exist or an error occurred.

---

### **4. Downloading the File**
```bash
if [ $? -eq 0 ]; then
    lftp -u $FTP_USERNAME,$FTP_PASSWORD -e "get $FILE_TO_DOWNLOAD; quit" $FTP_SERVER
    echo "File downloaded successfully."
else
    echo "File does not exist on the FTP server."
fi
```
- **`get $FILE_TO_DOWNLOAD`**:
  - Downloads the specified file to the current working directory.
- **`echo`**:
  - Prints a success or failure message based on whether the file existed.

---

### **5. Additional Notes**
- **Dependencies**:
  - `lftp` must be installed on your system. Install it using:
    ```bash
    sudo apt update
    sudo apt install lftp
    ```
- **Permissions**:
  - Ensure you have the necessary permissions to read files from the FTP server and write them to your local directory.

---

### Example Execution

#### Input:
- FTP server: `ftp://10.10.13.16`
- Username: `user1`
- Password: `password123`
- File: `testfile.txt`

#### Script:
```bash
FTP_SERVER="10.10.13.16"
FTP_USERNAME="user1"
FTP_PASSWORD="password123"
FILE_TO_DOWNLOAD="testfile.txt"
```

#### Execution:
```bash
chmod +x download_from_ftp.sh
./download_from_ftp.sh
```

#### Output (if the file exists):
```
File downloaded successfully.
```

#### Output (if the file does not exist):
```
File does not exist on the FTP server.
```

---

### 📚 **Theory Behind Concepts**

#### **1. File Transfer Protocol (FTP)**
- **Purpose**:
  - A standard network protocol for transferring files between a client and server.
- **Commands**:
  - `ls`: Lists files on the server.
  - `get`: Downloads a single file.
  - `mget`: Downloads multiple files.

#### **2. `lftp` Client**
- A robust command-line utility for FTP, SFTP, and HTTP file transfers.
- Features:
  - Non-interactive and automated mode for scripting.
  - Supports commands like `ls`, `get`, and `mget`.

#### **3. Exit Status (`$?`)**
- Provides the exit code of the last executed command.
  - `0`: Success.
  - Non-zero: Failure or error.

---

This script simplifies file checking and downloading from an FTP server. Let me know if you'd like to add features like downloading multiple files (`mget`) or logging progress! 😊
'
