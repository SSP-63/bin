
# 24. Write a shell script to show the disk partitions and their size and disk usage i.e free space.
#!/bin/bash


echo "Disk partitions and their sizes:"


# Use the df command to display disk partitions and their sizes
df -h | awk '{print $1 "\t" $2 "\t" $4}'


echo -e "\nDisk usage (free space) for each partition:"


# Use the df command to display disk usage (free space) for each partition
df -h | awk '{print $1 "\t" $5}'

:'
### 🔍 **Line-by-Line Code Explanation**

This script displays disk partition details, including their sizes and free space, using `df` and `awk` commands.

---

#### **1. Shebang**
```bash
#!/bin/bash
```
- Specifies that the script will be executed in the Bash shell.
- Ensures compatibility with Bash commands.

---

#### **2. Display Header Message**
```bash
echo "Disk partitions and their sizes:"
```
- Prints a header to inform the user about the information being displayed next.

---

#### **3. Display Partition Sizes**
```bash
df -h | awk '{print $1 "\t" $2 "\t" $4}'
```
- **`df -h`**:
  - Displays disk space usage in a human-readable format (e.g., GB, MB).
  - Outputs details about mounted file systems.
- **`awk '{print $1 "\t" $2 "\t" $4}'`**:
  - Filters and formats specific columns:
    - `$1`: File system name (e.g., `/dev/sda1`).
    - `$2`: Total size of the partition.
    - `$4`: Available free space on the partition.
  - Adds tabs (`\t`) between columns for better readability.

---

#### **4. Display Header for Disk Usage**
```bash
echo -e "\nDisk usage (free space) for each partition:"
```
- **`-e`**: Enables interpretation of special characters (e.g., `\n` for newline).
- Prints a separate header for the disk usage output.

---

#### **5. Display Partition Free Space**
```bash
df -h | awk '{print $1 "\t" $5}'
```
- **`df -h`**: Again retrieves disk partition information.
- **`awk '{print $1 "\t" $5}'`**:
  - Filters specific columns:
    - `$1`: File system name.
    - `$5`: Usage percentage (e.g., `75%` or `30%`).

---

### 📚 **Theory Behind Concepts**

#### **`df` Command**
- **Purpose**: Displays disk space usage for file systems.
- **Options**:
  - `-h`: Outputs sizes in human-readable units (e.g., GB, MB, KB).
  - Provides details such as total size, used space, available space, and usage percentage.

#### **`awk` Command**
- **Purpose**: Processes and formats text or command output based on patterns and actions.
- **Syntax**: `awk '{print column1, column2}'`.
  - `$1, $2, etc.`: Represent columns in the input text.
- **Applications**:
  - Extract and format specific columns.
  - Handle tabular data like `df` output efficiently.

#### **Text Formatting (`echo` Options)**
- **`echo -e`**: Enables escape sequences (`\n`, `\t`).
- **`Header Messages`**: Improve readability and inform the user about the script's output.

#### **Disk Monitoring**
- **Use Cases**:
  - Check available storage before running space-intensive tasks.
  - Monitor disk usage on servers for capacity planning.

---

### Example Output (Simulated)
Assume the following partitions:

| File System | Size | Available Space | Usage Percentage |
|-------------|------|-----------------|------------------|
| `/dev/sda1` | 100G | 30G            | 70%              |
| `/dev/sdb1` | 50G  | 20G            | 60%              |

Output:
```
Disk partitions and their sizes:
/dev/sda1	100G	30G
/dev/sdb1	50G	20G

Disk usage (free space) for each partition:
/dev/sda1	70%
/dev/sdb1	60%
```

This script is a concise way to monitor storage usage. Let me know if you'd like additional features, such as sorting or filtering specific partitions! 😊
'
