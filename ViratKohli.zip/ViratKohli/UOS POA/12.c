// 12. Write a program to give statistics of a given file using stat system call. (few imp field like FAP, file type)
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>

int main() {
    // ✅ Hardcoding the filename here
    char filename[] = "1.c"; // <-- File name is now 1.c

    struct stat fileStat;

    if (stat(filename, &fileStat) == -1) {
        perror("stat");
        exit(EXIT_FAILURE);
    }

    printf("File: %s\n", filename);
    printf("Size: %ld bytes\n", fileStat.st_size);
    printf("File Permissions: ");
    printf((S_ISDIR(fileStat.st_mode)) ? "d" : "-");
    printf((fileStat.st_mode & S_IRUSR) ? "r" : "-");
    printf((fileStat.st_mode & S_IWUSR) ? "w" : "-");
    printf((fileStat.st_mode & S_IXUSR) ? "x" : "-");
    printf((fileStat.st_mode & S_IRGRP) ? "r" : "-");
    printf((fileStat.st_mode & S_IWGRP) ? "w" : "-");
    printf((fileStat.st_mode & S_IXGRP) ? "x" : "-");
    printf((fileStat.st_mode & S_IROTH) ? "r" : "-");
    printf((fileStat.st_mode & S_IWOTH) ? "w" : "-");
    printf((fileStat.st_mode & S_IXOTH) ? "x\n" : "-\n");

    printf("File Type: ");
    switch (fileStat.st_mode & S_IFMT) {
        case S_IFREG:
            printf("Regular File\n");
            break;
        case S_IFDIR:
            printf("Directory\n");
            break;
        case S_IFLNK:
            printf("Symbolic Link\n");
            break;
        case S_IFBLK:
            printf("Block Device\n");
            break;
        case S_IFCHR:
            printf("Character Device\n");
            break;
        case S_IFIFO:
            printf("FIFO/Named Pipe\n");
            break;
        case S_IFSOCK:
            printf("Socket\n");
            break;
        default:
            printf("Unknown\n");
    }

    printf("Inode Number: %ld\n", fileStat.st_ino);
    printf("Number of Hard Links: %ld\n", fileStat.st_nlink);

    struct passwd *pwd = getpwuid(fileStat.st_uid);
    printf("Owner User ID: %d (%s)\n", fileStat.st_uid, pwd ? pwd->pw_name : "Unknown");

    struct group *grp = getgrgid(fileStat.st_gid);
    printf("Owner Group ID: %d (%s)\n", fileStat.st_gid, grp ? grp->gr_name : "Unknown");

    printf("Last Access Time: %s", ctime(&fileStat.st_atime));
    printf("Last Modification Time: %s", ctime(&fileStat.st_mtime));
    printf("Last Status Change Time: %s", ctime(&fileStat.st_ctime));

    return 0;
}
/*  Here’s the **full commented explanation**, exactly in your requested format:

---

```c
#include <stdio.h>
```
- Includes standard input-output functions like `printf()`.

```c
#include <stdlib.h>
```
- Includes functions like `exit()` for program termination.

```c
#include <sys/stat.h>
```
- Includes structure definitions and macros needed for file information using `stat()`.

```c
#include <unistd.h>
```
- Provides access to the POSIX operating system API, used here for compatibility.

```c
#include <errno.h>
```
- Defines macros for reporting and handling errors like `perror()`.

```c
#include <time.h>
```
- Defines functions and structures for time manipulation like `ctime()`.

```c
#include <pwd.h>
```
- Provides functions to retrieve password file information like `getpwuid()`.

```c
#include <grp.h>
```
- Provides functions to retrieve group information like `getgrgid()`.

```c
int main() {
```
- Entry point of the program.

```c
char filename[] = "1.c";
```
- Hardcodes the filename `1.c` into a character array.

```c
struct stat fileStat;
```
- Declares a `stat` structure to hold the file information.

```c
if (stat(filename, &fileStat) == -1) {
```
- Retrieves file statistics; if fails, enters the `if` block.

```c
perror("stat");
```
- Prints the error message corresponding to the last error encountered.

```c
exit(EXIT_FAILURE);
```
- Terminates the program immediately with a failure status.

```c
printf("File: %s\n", filename);
```
- Prints the file name.

```c
printf("Size: %ld bytes\n", fileStat.st_size);
```
- Prints the file size in bytes.

```c
printf("File Permissions: ");
```
- Begins the output of file permissions.

```c
printf((S_ISDIR(fileStat.st_mode)) ? "d" : "-");
```
- Prints `d` if the file is a directory; otherwise `-`.

```c
printf((fileStat.st_mode & S_IRUSR) ? "r" : "-");
```
- Prints `r` if the owner has read permission; otherwise `-`.

```c
printf((fileStat.st_mode & S_IWUSR) ? "w" : "-");
```
- Prints `w` if the owner has write permission; otherwise `-`.

```c
printf((fileStat.st_mode & S_IXUSR) ? "x" : "-");
```
- Prints `x` if the owner has execute permission; otherwise `-`.

```c
printf((fileStat.st_mode & S_IRGRP) ? "r" : "-");
```
- Prints `r` if the group has read permission; otherwise `-`.

```c
printf((fileStat.st_mode & S_IWGRP) ? "w" : "-");
```
- Prints `w` if the group has write permission; otherwise `-`.

```c
printf((fileStat.st_mode & S_IXGRP) ? "x" : "-");
```
- Prints `x` if the group has execute permission; otherwise `-`.

```c
printf((fileStat.st_mode & S_IROTH) ? "r" : "-");
```
- Prints `r` if others have read permission; otherwise `-`.

```c
printf((fileStat.st_mode & S_IWOTH) ? "w" : "-");
```
- Prints `w` if others have write permission; otherwise `-`.

```c
printf((fileStat.st_mode & S_IXOTH) ? "x\n" : "-\n");
```
- Prints `x` if others have execute permission; otherwise `-`, and moves to next line.

```c
printf("File Type: ");
```
- Prepares to print the type of the file.

```c
switch (fileStat.st_mode & S_IFMT) {
```
- Begins a switch block based on file type mask.

```c
case S_IFREG:
```
- If the file is a regular file.

```c
printf("Regular File\n");
break;
```
- Prints "Regular File" and exits the case.

```c
case S_IFDIR:
```
- If the file is a directory.

```c
printf("Directory\n");
break;
```
- Prints "Directory" and exits the case.

```c
case S_IFLNK:
```
- If the file is a symbolic link.

```c
printf("Symbolic Link\n");
break;
```
- Prints "Symbolic Link" and exits the case.

```c
case S_IFBLK:
```
- If the file is a block device.

```c
printf("Block Device\n");
break;
```
- Prints "Block Device" and exits the case.

```c
case S_IFCHR:
```
- If the file is a character device.

```c
printf("Character Device\n");
break;
```
- Prints "Character Device" and exits the case.

```c
case S_IFIFO:
```
- If the file is a FIFO/Named pipe.

```c
printf("FIFO/Named Pipe\n");
break;
```
- Prints "FIFO/Named Pipe" and exits the case.

```c
case S_IFSOCK:
```
- If the file is a socket.

```c
printf("Socket\n");
break;
```
- Prints "Socket" and exits the case.

```c
default:
```
- If the file type is unknown.

```c
printf("Unknown\n");
```
- Prints "Unknown" file type.

```c
}
```
- Ends the switch block.

```c
printf("Inode Number: %ld\n", fileStat.st_ino);
```
- Prints the inode number of the file.

```c
printf("Number of Hard Links: %ld\n", fileStat.st_nlink);
```
- Prints the number of hard links to the file.

```c
struct passwd *pwd = getpwuid(fileStat.st_uid);
```
- Retrieves the password structure for the file’s owner user ID.

```c
printf("Owner User ID: %d (%s)\n", fileStat.st_uid, pwd ? pwd->pw_name : "Unknown");
```
- Prints the owner's user ID and name; "Unknown" if not found.

```c
struct group *grp = getgrgid(fileStat.st_gid);
```
- Retrieves the group structure for the file’s group ID.

```c
printf("Owner Group ID: %d (%s)\n", fileStat.st_gid, grp ? grp->gr_name : "Unknown");
```
- Prints the owner's group ID and name; "Unknown" if not found.

```c
printf("Last Access Time: %s", ctime(&fileStat.st_atime));
```
- Prints the last access time of the file.

```c
printf("Last Modification Time: %s", ctime(&fileStat.st_mtime));
```
- Prints the last modification time of the file.

```c
printf("Last Status Change Time: %s", ctime(&fileStat.st_ctime));
```
- Prints the last status change time (metadata change).

```c
return 0;
```
- Terminates the program with success status.

```c
}
```
- End of `main()` function.

---

## Unix Concepts Explained:

- **`stat()`**:  
  Retrieves detailed information about a file (size, permissions, timestamps, inode, etc.). Returns `-1` on error.

- **`perror()`**:  
  Displays a human-readable string describing the last error that occurred during a library function call.

- **`ctime()`**:  
  Converts time_t value (like access time, modification time) into a human-readable string.

- **`getpwuid()` and `getgrgid()`**:  
  `getpwuid()` retrieves the user account information given a user ID.  
  `getgrgid()` retrieves the group account information given a group ID.

- **File Mode Macros**:  
  - `S_IRUSR`, `S_IWUSR`, `S_IXUSR`: Read, write, execute permissions for the user.
  - `S_IRGRP`, `S_IWGRP`, `S_IXGRP`: Permissions for the group.
  - `S_IROTH`, `S_IWOTH`, `S_IXOTH`: Permissions for others.
  - `S_IFREG`, `S_IFDIR`, etc.: File type identifiers.

---

✅ Done exactly in your preferred format.  
Would you like me to also create a **shell script** that displays this file info next time? 🚀*/
