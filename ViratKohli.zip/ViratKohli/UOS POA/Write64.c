
// 64. Using FIFO as named pipe use read and write system calls to establish communication (IPC) between two ends.
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
 
int main()
{
        int fd;
 
        // FIFO file path
        char * myfifo = "/tmp/myfifo";
 
        // Creating the named file(FIFO)
        // mkfifo(<pathname>, <permission>)
        mkfifo(myfifo, 0666);
 
        char arr1[80], arr2[80];
        while (1)
        {
            // Open FIFO for write only
            fd = open(myfifo, O_WRONLY);
 
            // Take an input arr2ing from user.
            // 80 is maximum length
            fgets(arr2, 80, stdin);
 
            // Write the input arr2ing on FIFO
            // and close it
            write(fd, arr2, strlen(arr2)+1);
            close(fd);
 
            // Open FIFO for Read only
            fd = open(myfifo, O_RDONLY);
 
            // Read from FIFO
            read(fd, arr1, sizeof(arr1));
 
            // Print the read message
            printf("User2: %s\n", arr1);
            close(fd);
        }
        return 0;
}


// Writes first
/* ### **Explanation: Using FIFO as Named Pipe for IPC with Read and Write System Calls**

This program demonstrates **Interprocess Communication (IPC)** using **FIFO (named pipe)**. The goal is to establish bidirectional communication between two processes using the `read` and `write` system calls. Below is a detailed explanation of how the code works.

---

### **What is a FIFO (Named Pipe)?**
1. **FIFO**:
   - A **First-In, First-Out** mechanism used for IPC. 
   - Unlike unnamed pipes, FIFOs have names and exist in the filesystem.
   - They allow communication between **unrelated processes**.

2. **Characteristics**:
   - **Persistent**:
     - The FIFO remains in the filesystem until explicitly removed.
   - **Blocking Behavior**:
     - The `read` operation blocks until data is written to the FIFO, and vice versa.

---

### **Step-by-Step Code Breakdown**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
```
- **`stdio.h`**: Provides functions for input/output operations (`printf`, `fgets`).
- **`string.h`**: Includes string manipulation functions like `strlen`.
- **`fcntl.h`**: Defines file descriptor operations (`O_WRONLY`, `O_RDONLY`).
- **`sys/stat.h`**: Provides constants for file permissions (`0666`) and functions like `mkfifo` for creating FIFOs.
- **`unistd.h`**: Includes system calls like `open`, `read`, `write`, and `close`.

---

#### **2. Define and Create FIFO**
```c
char * myfifo = "/tmp/myfifo";
mkfifo(myfifo, 0666);
```
- **`mkfifo`**:
  - Creates a named pipe at the specified path (`/tmp/myfifo`) if it does not already exist.
  - **Permissions**:
    - `0666` allows read and write access to all users.
- **Persistence**:
  - The named pipe remains in the filesystem until manually removed using `unlink`.

---

#### **3. Prepare Communication Variables**
```c
char arr1[80], arr2[80];
```
- **`arr1`**:
  - Stores the message received from the FIFO.
- **`arr2`**:
  - Stores the message entered by the user before sending it to the FIFO.

---

#### **4. Write Data to the FIFO**
```c
fd = open(myfifo, O_WRONLY);
fgets(arr2, 80, stdin);
write(fd, arr2, strlen(arr2)+1);
close(fd);
```
- **Steps**:
  1. **Open FIFO**:
     - Opens the named pipe (`myfifo`) in write mode (`O_WRONLY`).
     - Blocks if no process has opened the FIFO for reading.
  2. **Read User Input**:
     - Reads up to 80 characters from standard input (`stdin`) using `fgets`.
  3. **Write to FIFO**:
     - Writes the user input (`arr2`) to the FIFO using `write`.
     - Appends `+1` to account for the null terminator (`\0`).
  4. **Close FIFO**:
     - Releases the file descriptor after writing.

---

#### **5. Read Data from the FIFO**
```c
fd = open(myfifo, O_RDONLY);
read(fd, arr1, sizeof(arr1));
printf("User2: %s\n", arr1);
close(fd);
```
- **Steps**:
  1. **Open FIFO**:
     - Opens the named pipe (`myfifo`) in read mode (`O_RDONLY`).
     - Blocks if no process has opened the FIFO for writing.
  2. **Read from FIFO**:
     - Reads up to 80 characters from the FIFO into `arr1`.
  3. **Display Received Message**:
     - Prints the received message with the prefix `"User2: "`.
  4. **Close FIFO**:
     - Releases the file descriptor after reading.

---

### **Program Workflow**

1. **FIFO Creation**:
   - Ensures a named pipe (`myfifo`) exists for communication.
2. **Message Exchange**:
   - Alternates between writing user input (`arr2`) to the FIFO and reading messages (`arr1`) from the FIFO.
3. **Infinite Loop**:
   - Keeps the program running for continuous communication until manually terminated.

---

### **Compiling and Running the Program**

#### **Step 1: Compile**
```bash
gcc -o fifo_ipc fifo_ipc.c
```

#### **Step 2: Run**
1. **Start the program in Terminal 1**:
   ```bash
   ./fifo_ipc
   ```
   - This acts as the write end initially.

2. **Start another instance in Terminal 2**:
   ```bash
   ./fifo_ipc
   ```
   - This acts as the read end initially.

---

### **Sample Interaction**

#### **Terminal 1**:
```
Hello, User2!
User2: Hi, User1!
How are you?
User2: I am fine!
```

#### **Terminal 2**:
```
User2: Hello, User2!
Hi, User1!
User2: How are you?
I am fine!
```

---

### **Theory: FIFO in IPC**

#### **How FIFO Works**
1. **Unidirectional Communication**:
   - Data flows in one direction: from writer to reader.
2. **Blocking Mechanism**:
   - Both `read` and `write` operations block until their counterpart is ready.

#### **Why Use FIFO?**
1. **Decouple Processes**:
   - Allows communication between processes that are not directly related (no parent-child relationship).
2. **Simple Interface**:
   - Uses file-like operations (`read`, `write`) for communication.

---

### **Applications**
1. **Interprocess Communication**:
   - Pass messages between separate programs running concurrently.
2. **Log Systems**:
   - Collect logs from multiple sources and send them to a central reader.
3. **Producer-Consumer Model**:
   - Efficiently manage communication between data producers and consumers.

Let me know if you'd like further assistance or enhancements on this program! 😊*/
