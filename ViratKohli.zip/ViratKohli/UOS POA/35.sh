
# 35. Write a bash script that takes 2 or more arguments,
# i)All arguments are filenames
# ii)If fewer than two arguments are given, print an error message
# iii)If the files do not exist, print error message
# iv)Otherwise concatenate files
#!/bin/bash


# Check if the number of arguments is less than 2
if [ "$#" -lt 2 ]; then
        echo "Error: At least two filenames are required."
        exit 1
fi


# Check if all files exist
for filename in "$@"; do
        if [ ! -f "$filename" ]; then
            echo "Error: File $filename does not exist."
            exit 1
        fi
done


# Concatenate all files
cat "$@"


# omkar@omkar:~/Desktop/UOS POA$ chmod +x 35.sh
# omkar@omkar:~/Desktop/UOS POA$ ./35.sh sample.txt sample1.txt 

:"
### 🔍 **Line-by-Line Code Explanation**

This bash script ensures robust file validation and concatenation, adhering to specified requirements.

---

#### **1. Shebang**
```bash
#!/bin/bash
```
- Specifies that the script will run in the Bash shell.

---

#### **2. Check for Minimum Number of Arguments**
```bash
if [ "$#" -lt 2 ]; then
    echo "Error: At least two filenames are required."
    exit 1
fi
```
- **`$#`**: Counts the number of arguments passed to the script.
- **Condition**:
  - If fewer than 2 arguments are provided, prints an error message and exits with a status code of `1`.

---

#### **3. Verify File Existence**
```bash
for filename in "$@"; do
    if [ ! -f "$filename" ]; then
        echo "Error: File $filename does not exist."
        exit 1
    fi
done
```
- **`$@`**: Represents all script arguments as a space-separated list.
- **`for filename in "$@"`**:
  - Iterates over each argument.
  - Checks if the specified file exists.
- **`[ ! -f "$filename" ]`**:
  - Tests if the file is NOT a regular file.
  - If any file doesn’t exist, prints an error message and exits with a status code of `1`.

---

#### **4. Concatenate Files**
```bash
cat "$@"
```
- **`cat`**: Concatenates the contents of all files provided as arguments.
- **`$@`**: Passes all file arguments to `cat`.
- Result: Displays the combined content of the files sequentially in the terminal.

---

### 📚 **Related Theory**

#### **1. Script Arguments**
- **`$#`**:
  - Represents the total number of arguments passed.
  - Used for validating the minimum required arguments.
- **`$@`**:
  - Expands to all command-line arguments.
  - Useful for handling multiple inputs dynamically.

#### **2. Test Operators**
- **`[ ! -f "$filename" ]`**:
  - Tests if the provided input isn’t a regular file.
  - Ensures that only valid, existing files are processed.

#### **3. `cat` Command**
- **Purpose**:
  - Concatenates and displays the contents of files.
- **Syntax**:
  - `cat file1 file2 ...` prints the contents of `file1` followed by `file2`, and so on.
- **Applications**:
  - Merging file content.
  - Viewing file contents directly in the terminal.

---

### Example Usage

1. **Make the Script Executable**:
   ```bash
   chmod +x 35.sh
   ```

2. **Run the Script with Valid Arguments**:
   ```bash
   ./35.sh file1.txt file2.txt
   ```
   - Combines and displays the content of `file1.txt` and `file2.txt`.

#### Sample Output:
If `file1.txt` contains:
```
Hello from file1.
```
And `file2.txt` contains:
```
Hello from file2.
```
The output would be:
```
Hello from file1.
Hello from file2.
```

3. **Run the Script with Missing Files**:
   ```bash
   ./35.sh file1.txt nonexistent.txt
   ```
   Output:
   ```
   Error: File nonexistent.txt does not exist.
   ```

4. **Run the Script with Fewer than Two Arguments**:
   ```bash
   ./35.sh file1.txt
   ```
   Output:
   ```
   Error: At least two filenames are required.
   ```

---

### **Applications**
- **Automation**:
  - Useful for combining log files or text reports.
- **Error Handling**:
  - Prevents invalid inputs or missing files from being processed.

This script is a simple yet effective utility for file validation and concatenation. Let me know if you'd like enhancements, such as saving the concatenated output to a new file or handling directories! 😊
'
