# 27. Write a shell script to download a webpage from given URL . (Using wget command)
#!/bin/bash


# Check if correct number of arguments are provided
if [ $# -ne 1 ]; then
        echo "Usage: $0 <url>"
        exit 1
fi


url="$1"


# Use wget to download the webpage at the given URL
wget "$url" -O downloaded_page.html


if [ $? -eq 0 ]; then
        echo "Webpage downloaded successfully"
else
        echo "Failed to download the webpage"
fi

:"

### 🔍 **Line-by-Line Explanation**

This script automates downloading a webpage from a given URL using the `wget` command, handling errors and validating user input effectively.

---

#### **1. Shebang**
```bash
#!/bin/bash
```
- Specifies the script is to be executed with the Bash shell.

---

#### **2. Checking the Number of Arguments**
```bash
if [ $# -ne 1 ]; then
    echo "Usage: $0 <url>"
    exit 1
fi
```
- **`$#`**: Represents the number of arguments passed to the script.
- **Condition**:
  - Ensures exactly one argument (the URL) is provided.
- **Usage Message**:
  - If the argument is missing, prints usage instructions (`Usage: ./script.sh <url>`).
- **`exit 1`**:
  - Terminates the script with a status code of `1` to indicate improper usage.

---

#### **3. Capturing the URL**
```bash
url="$1"
```
- Assigns the first argument (the given URL) to the variable `url`.

---

#### **4. Downloading the Webpage**
```bash
wget "$url" -O downloaded_page.html
```
- **`wget`**: Downloads the content of the provided URL.
- **Options**:
  - `"$url"`: Specifies the target URL.
  - `-O downloaded_page.html`: Saves the downloaded content to a file named `downloaded_page.html`.

---

#### **5. Verifying the Download**
```bash
if [ $? -eq 0 ]; then
    echo "Webpage downloaded successfully"
else
    echo "Failed to download the webpage"
fi
```
- **`$?`**: Captures the exit status of the previous command (`wget` in this case).
- **Exit Status Check**:
  - `0`: Indicates success (the webpage was downloaded).
  - Non-zero: Indicates failure (e.g., invalid URL, network issues).
- **Message**:
  - Prints a success or failure message based on the status.

---

### 📚 **Theory Behind Concepts**

#### **`wget` Command**
- **Purpose**: Downloads files from the web.
- **Syntax**: `wget [options] [url]`.
- **Common Options**:
  - `-O [filename]`: Saves the downloaded content to the specified file.
  - `--quiet`: Suppresses output (optional for silent downloads).
- **Error Handling**:
  - A non-zero exit status indicates issues like invalid URLs or connection failures.

#### **Exit Status (`$?`)**
- Reflects the result of the last executed command:
  - `0`: Success.
  - Non-zero: Failure.

#### **Input Validation**
- **Arguments (`$#`, `$1`)**:
  - Ensures the script is used correctly by requiring exactly one argument.

#### **Applications**
- Automating webpage downloads for archiving.
- Fetching data for offline analysis or processing.

---

### Example Execution

1. **Make the Script Executable**:
   ```bash
   chmod +x download_webpage.sh
   ```

2. **Run the Script**:
   ```bash
   ./download_webpage.sh "https://example.com"
   ```

   **Output (on success)**:
   ```
   Webpage downloaded successfully
   ```

   **Output (on failure)**:
   ```
   Failed to download the webpage
   ```

---

This script demonstrates efficient error handling and automation for downloading web content. Let me know if you'd like enhancements like user feedback during downloads or handling specific errors! 😊

'
