package TCP_Concurrent;
import java.io.*;
import java.net.*;

public class Server53 {
    public static void main(String[] args) {
        try {
            // Set up server socket to listen on port 8080
            ServerSocket serverSocket = new ServerSocket(8080);
            System.out.println("Concurrent TCP Echo Server started. Listening on port 8080...");

            // Infinite loop to accept multiple client connections
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket);

                // Start a new thread for each client connection
                Thread clientHandler = new Thread(new ClientHandler(clientSocket));
                clientHandler.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ClientHandler class that handles communication with the client
    static class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try {
                // Set up input and output streams for communication with the client
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

                String message;
                // Read messages from the client and send back as echo
                while ((message = in.readLine()) != null) {
                    System.out.println("Received from client: " + message);
                    out.println("Echo: " + message);  // Send echo message back to client
                }

                // Close resources after communication
                in.close();
                out.close();
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
// }
// There are a few steps to ensure that everything works correctly:

//     Create the Correct Directory Structure: Since your code is in the TCP_Concurrent package, you need to create a directory structure matching the package name. That is, inside your current directory (~/Desktop/UOS POA), create a directory called TCP_Concurrent.

//     Move the Java Files into the Correct Directory: You need to place the Server53.java and Client53.java files inside the TCP_Concurrent directory.

// mkdir -p TCP_Concurrent
// mv Server53.java TCP_Concurrent/
// mv Client53.java TCP_Concurrent/

// Recompile the Java Files: After moving the files into the TCP_Concurrent directory, you can recompile them from the parent directory (~/Desktop/UOS POA):

// javac TCP_Concurrent/Server53.java
// javac TCP_Concurrent/Client53.java

// Run the Server and Client: When running the classes, you must include the package structure. Here's how you run the Server53 class and Client53 class:

//     Run the Server:

// java TCP_Concurrent.Server53

// Run the Client:

//         java TCP_Concurrent.Client53

// By doing this, Java will be able to find the correct classes and run them with the proper package structure.

// Let me know if you encounter any further issues!

/* ### **Implementation Explanation: TCP Echo Server with Concurrent Logic**

This program is a **TCP Echo Server-Client** implementation in **Java**, enabling communication between multiple clients and a server. The server uses **multithreading** to handle client connections concurrently.

---

### **Theory of TCP and Echo Server**

#### **TCP (Transmission Control Protocol)**
1. **Connection-Oriented Protocol**:
   - Establishes a reliable connection between a server and client through a **three-way handshake**.
   - Guarantees delivery of messages without data duplication or loss.
   - Data is sent as a stream, ensuring ordered and complete transmission.

2. **Applications**:
   - Web services, file transfer (FTP), email communication, and chat applications.

---

#### **Echo Server**
1. **Definition**:
   - An Echo Server receives a message from a client and sends the same message back (echo).
2. **Purpose**:
   - Often used for testing network communication.
   - Demonstrates basic client-server communication principles.

---

### **Code Concepts and Explanation**

---

#### **1. Server Class: `Server53`**

##### **Step 1: Import Libraries**
```java
import java.io.*;
import java.net.*;
```
- **`java.io`**: Used for input/output streams (`BufferedReader` and `PrintWriter`).
- **`java.net`**: Provides socket programming classes (`Socket` and `ServerSocket`).

---

##### **Step 2: Create Server Socket**
```java
ServerSocket serverSocket = new ServerSocket(8080);
System.out.println("Concurrent TCP Echo Server started. Listening on port 8080...");
```
- **`ServerSocket`**:
  - Listens for incoming client connections on port `8080`.
  - Port `8080` must match the client configuration to establish communication.
- **Blocking**:
  - The server socket waits indefinitely for client connections using `accept()`.

---

##### **Step 3: Accept Client Connections**
```java
Socket clientSocket = serverSocket.accept();
System.out.println("Client connected: " + clientSocket);
```
- **`accept()`**:
  - Returns a `Socket` object when a client connects.
- **Thread Creation**:
  - A new thread (`ClientHandler`) is instantiated and started for each client to handle communication concurrently.

---

##### **Step 4: ClientHandler Class**
The `ClientHandler` class manages communication with a specific client.

###### **Key Features**
1. **Input and Output Streams**:
   ```java
   BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
   PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
   ```
   - **`BufferedReader`**:
     - Reads text sent from the client.
   - **`PrintWriter`**:
     - Sends text back to the client.

2. **Read and Echo Messages**:
   ```java
   while ((message = in.readLine()) != null) {
       System.out.println("Received from client: " + message);
       out.println("Echo: " + message);
   }
   ```
   - Continuously reads messages from the client and sends back the same message prefixed with `"Echo: "`.

3. **Close Resources**:
   ```java
   in.close();
   out.close();
   clientSocket.close();
   ```
   - Closes the socket and streams after communication ends.

---

#### **2. Client Class: `Client53`**

##### **Step 1: Create Client Socket**
```java
Socket socket = new Socket("localhost", 8080);
```
- **`Socket`**:
  - Connects to the server running on the local machine (`localhost`) at port `8080`.

---

##### **Step 2: Set Up Communication Streams**
```java
BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
```
- **`BufferedReader`**:
  - Reads messages from the server (`in`) or user input (`userInput`).
- **`PrintWriter`**:
  - Sends messages to the server.

---

##### **Step 3: Send and Receive Messages**
```java
while ((message = userInput.readLine()) != null) {
    out.println(message); // Send to server
    System.out.println("Sent to Server: " + message);
}
```
- **Message Flow**:
  - Reads user input from the console, sends it to the server, and prints confirmation locally.

---

##### **Step 4: Close Resources**
```java
userInput.close();
in.close();
out.close();
socket.close();
```
- Closes the socket and streams when communication ends.

---

### **Workflow and Execution**

#### **1. Directory Structure**
- Create a directory matching the package name:
```bash
mkdir -p TCP_Concurrent
mv Server53.java TCP_Concurrent/
mv Client53.java TCP_Concurrent/
```

#### **2. Compilation**
```bash
javac TCP_Concurrent/Server53.java
javac TCP_Concurrent/Client53.java
```

#### **3. Run the Server**
```bash
java TCP_Concurrent.Server53
```

#### **4. Run the Client**
Run multiple clients in separate terminals:
```bash
java TCP_Concurrent.Client53
```

---

### **Sample Interaction**

#### **Server Output**:
```
Concurrent TCP Echo Server started. Listening on port 8080...
Client connected: Socket[addr=/127.0.0.1,port=client_port,localport=8080]
Received from client: Hello, Server!
Received from client: How are you?
```

#### **Client Output**:
```
Sent to Server: Hello, Server!
Echo: Hello, Server!
Sent to Server: How are you?
Echo: How are you?
```

---

### **Concepts in Play**

#### **Concurrent Logic**
- The server creates a new thread (`ClientHandler`) for each client connection, enabling **parallel communication**.

#### **Blocking and Streams**
1. **Blocking**:
   - Both the server and client block during `accept()` or `readLine()` calls until data is received.
2. **Streams**:
   - `InputStream` and `OutputStream` allow bi-directional communication.

#### **TCP and Reliability**
- TCP ensures ordered delivery of data without duplication or loss, making it suitable for echo servers.

---

### **Advantages**
1. **Concurrent Client Handling**:
   - Multiple clients can connect simultaneously without interrupting one another.
2. **Scalability**:
   - The server dynamically creates threads based on client demand.
3. **Ease of Communication**:
   - Simple message echoing for testing and debugging purposes.

---

### **Further Enhancements**
1. **Broadcasting**:
   - Allow the server to send a message from one client to all connected clients.
2. **Authentication**:
   - Require a username/password for secure communication.
3. **Error Handling**:
   - Improve exception handling for socket timeouts or connection failures.

This implementation illustrates the foundation of concurrent TCP communication. If you need additional features or explanation, let me know! 😊*/
