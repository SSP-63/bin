
// 53. Implement echo server using TCP in iterative/concurrent logic.
// CLIENT:
package TCP_Concurrent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;

public class Client53 {

    public static void main(String[] args) {
        try {
            // Connect to the server on localhost and port 8080
            Socket socket = new Socket("localhost", 8080);

            // Set up input and output streams for communication
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            // Read user input from the console
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            String message;

            // Read messages from the user and send them to the server
            while ((message = userInput.readLine()) != null) {
                out.println(message);  // Send message to server
                System.out.println("Sent to Server: " + message);
            }

            // Close streams and socket after done
            userInput.close();
            in.close();
            out.close();
            socket.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}


// There are a few steps to ensure that everything works correctly:

//     Create the Correct Directory Structure: Since your code is in the TCP_Concurrent package, you need to create a directory structure matching the package name. That is, inside your current directory (~/Desktop/UOS POA), create a directory called TCP_Concurrent.

//     Move the Java Files into the Correct Directory: You need to place the Server53.java and Client53.java files inside the TCP_Concurrent directory.

// mkdir -p TCP_Concurrent
// mv Server53.java TCP_Concurrent/
// mv Client53.java TCP_Concurrent/

// Recompile the Java Files: After moving the files into the TCP_Concurrent directory, you can recompile them from the parent directory (~/Desktop/UOS POA):

// javac TCP_Concurrent/Server53.java
// javac TCP_Concurrent/Client53.java

// Run the Server and Client: When running the classes, you must include the package structure. Here's how you run the Server53 class and Client53 class:

//     Run the Server:

// java TCP_Concurrent.Server53

// Run the Client:

//         java TCP_Concurrent.Client53

// By doing this, Java will be able to find the correct classes and run them with the proper package structure.

// Let me know if you encounter any further issues!