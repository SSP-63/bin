
# 65. write shell script with FIFO/mknod (named pipe) us for communication (IPC)
#!/bin/bash


# Define the FIFO name
FIFO_NAME="myfifo"


# Create the FIFO (named pipe)
if [ ! -p "$FIFO_NAME" ]; then
        mkfifo "$FIFO_NAME"
fi


# Function to read data from the FIFO
read_from_fifo() {
        echo "Reader process is listening for messages..."
        while read line < "$FIFO_NAME"; do
            echo "Received message: $line"
        done
}


# Function to write data to the FIFO
write_to_fifo() {
        echo "Enter message to send (or 'exit' to quit):"
        while true; do
            read message
            if [ "$message" = "exit" ]; then
                break
            fi
            echo "$message" > "$FIFO_NAME"
        done
}


# Check if the script is run with an argument
if [ $# -ne 1 ]; then
        echo "Usage: $0 [read|write]"
        exit 1
fi


# Check the argument and run the appropriate function
case "$1" in
        read) read_from_fifo ;;
        write) write_to_fifo ;;
        *) echo "Invalid argument: $1"; exit 1 ;;
esac


# chmod +x fifo.sh 
# ./fifo.sh write
# ./fifo.sh read
:'  
### **Explanation: Shell Script for IPC Using FIFO (Named Pipe)**

This script demonstrates **Interprocess Communication (IPC)** using a **FIFO (named pipe)**. It allows processes to **read** messages from or **write** messages to the FIFO. Below is a detailed explanation of how the script works and its features:

---

### **1. What is a FIFO (Named Pipe)?**

1. **FIFO (First In, First Out)**:
   - A special type of file that acts as a unidirectional pipe.
   - Unlike regular pipes (which are temporary), FIFOs are persistent and exist in the filesystem until explicitly deleted.

2. **Characteristics**:
   - **File-like Behavior**: Processes can read/write to FIFOs just like regular files.
   - **Blocking Mechanism**:
     - The **reader** blocks until data is written.
     - The **writer** blocks until a process is available to read the data.

---

### **2. Key Script Features**

#### **FIFO Creation**
```bash
if [ ! -p "$FIFO_NAME" ]; then
    mkfifo "$FIFO_NAME"
fi
```
- **`mkfifo`**:
  - Creates a named pipe at the path specified by `FIFO_NAME`.
- **`[ ! -p "$FIFO_NAME" ]`**:
  - Checks if the FIFO already exists (`-p` checks for a named pipe).
- If the FIFO doesn't exist, it is created.

---

#### **Functions**

1. **`read_from_fifo`**:
   - Continuously listens for messages written to the FIFO and prints them.
   ```bash
   while read line < "$FIFO_NAME"; do
       echo "Received message: $line"
   done
   ```
   - **Usage**:
     - Acts as the reader process in the IPC.
     - Blocks until a message is available in the FIFO.

2. **`write_to_fifo`**:
   - Writes user input to the FIFO.
   ```bash
   while true; do
       read message
       if [ "$message" = "exit" ]; then
           break
       fi
       echo "$message" > "$FIFO_NAME"
   done
   ```
   - **Usage**:
     - Acts as the writer process in the IPC.
     - The user enters a message, and it is sent to the FIFO.
     - Typing `exit` terminates the writing process.

---

#### **Argument Handling**
```bash
if [ $# -ne 1 ]; then
    echo "Usage: $0 [read|write]"
    exit 1
fi
```
- Ensures the script is executed with a single argument (`read` or `write`).
- Exits with an error if no argument or an invalid argument is provided.

---

#### **Case Statement**
```bash
case "$1" in
    read) read_from_fifo ;;
    write) write_to_fifo ;;
    *) echo "Invalid argument: $1"; exit 1 ;;
esac
```
- **Switches**:
  - If the argument is `read`, the `read_from_fifo` function is called.
  - If the argument is `write`, the `write_to_fifo` function is called.
  - Any other argument is rejected as invalid.

---

### **Usage Instructions**

#### **1. Make the Script Executable**
```bash
chmod +x fifo.sh
```

#### **2. Run as Writer**
```bash
./fifo.sh write
```
- Enter messages to send to the FIFO.
- Type `exit` to quit the writer process.

#### **3. Run as Reader**
```bash
./fifo.sh read
```
- Listens for incoming messages and displays them in real-time.

---

### **Example**

1. Open **two terminals**.
2. On the first terminal, run the **reader**:
   ```bash
   ./fifo.sh read
   ```
   Output:
   ```
   Reader process is listening for messages...
   ```

3. On the second terminal, run the **writer**:
   ```bash
   ./fifo.sh write
   ```
   Enter:
   ```
   Hello, Reader!
   ```

4. Output on the **reader terminal**:
   ```
   Received message: Hello, Reader!
   ```

---

### **Cleanup**

After execution, the named pipe (`myfifo`) persists in the filesystem. Remove it manually if no longer needed:
```bash
rm myfifo
```

---

### **Advantages of FIFOs**

1. **Unrelated Process Communication**:
   - FIFOs allow communication between processes that don’t have a parent-child relationship.
2. **Ease of Use**:
   - Use standard file operations (`read`/`write`).
3. **Persistence**:
   - FIFOs exist in the filesystem until explicitly removed.

---

### **Limitations**

1. **Blocking Behavior**:
   - The reader blocks until data is written to the FIFO, and the writer blocks until a reader is available.
2. **Unidirectional**:
   - Data flows in one direction. Bidirectional communication requires two FIFOs.

This script demonstrates a simple yet effective way to use FIFOs for IPC. Let me know if you’d like to explore more advanced IPC techniques, such as bidirectional communication or integration with C programs! 😊
'
