
# 20. Write a program to check whether system is in network or not using ’ping’ command using shell script.
#!/bin/bash


# Define the IP address or domain name to ping
target="google.com"


# Ping the target with a single packet and wait for 1 second
ping -c 1 -W 1 "$target" > /dev/null 2>&1


# Check the exit status of the ping command
if [ $? -eq 0 ]; then
        echo "System is connected to the network"
else
        echo "System is not connected to the network"
fi

:'
### 🔍 **Line-by-Line Explanation**
This shell script checks whether the system is connected to the network by attempting to ping a specified target.

---

#### **1. Defining the Target**
```bash
target="google.com"
```
- **Purpose**: Sets the variable `target` to a domain name or IP address (in this case, "google.com").
- This target is the endpoint that the script will ping to verify network connectivity.

---

#### **2. Ping Command**
```bash
ping -c 1 -W 1 "$target" > /dev/null 2>&1
```
- **`ping`**: Sends ICMP echo requests to check if the specified target is reachable.
- **Options**:
  - `-c 1`: Sends exactly one packet (minimizing network usage).
  - `-W 1`: Waits for up to 1 second for a reply before timing out.
- **`> /dev/null 2>&1`**:
  - Redirects standard output (`stdout`) and standard error (`stderr`) to `/dev/null`.
  - Ensures the command runs silently without printing to the terminal.

---

#### **3. Check Exit Status**
```bash
if [ $? -eq 0 ]; then
```
- **`$?`**: Represents the exit status of the last executed command.
- **Exit Status**:
  - `0`: Indicates the ping command was successful (target is reachable).
  - Non-zero: Indicates failure (target unreachable).

---

#### **4. Connection Status Messages**
```bash
echo "System is connected to the network"
```
- Displays a message if the target is reachable.

```bash
echo "System is not connected to the network"
```
- Displays a message if the ping failed, indicating lack of network connectivity.

---

### 📚 **Theory Behind Concepts**

#### **Ping Command**
- **ICMP Protocol**: Ping uses Internet Control Message Protocol (ICMP) to check the reachability of a host.
- **Echo Request/Reply**: The ping command sends an echo request packet to the target and waits for an echo reply.

#### **Exit Status**
- **System Commands**: Most commands return an exit code:
  - `0`: Success.
  - Non-zero: Error or failure.
- Scripts commonly use `$?` to evaluate the success or failure of a command.

#### **Redirection**
- **`> /dev/null`**: Suppresses standard output (e.g., ping replies).
- **`2>&1`**: Redirects standard error to standard output, ensuring all output is suppressed.

#### **Conditional Statements**
- **`if` Statement**: Evaluates the exit status and branches execution based on the condition.

#### **Applications**
- **Network Diagnostics**: Quickly determines if the system is online.
- **Automation**: Can be incorporated into scripts for monitoring network status.

---

This script is efficient for checking basic network connectivity in real-time. Let me know if you'd like to discuss optimizations or additional features! 😊

'
