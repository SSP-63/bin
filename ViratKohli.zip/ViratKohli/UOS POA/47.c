// 47. Write a program using OpenMP library to parallelize the for loop in sequential program of finding prime numbers in given range
#include <stdio.h>
#include <omp.h>


int is_prime(int n) {
        if (n <= 1) return 0;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) return 0;
        }
        return 1;
}


int main() {
        int lower = 2, upper = 100; // Define the range
        printf("Prime numbers between %d and %d are:\n", lower, upper);


        #pragma omp parallel for
        for (int num = lower; num <= upper; num++) {
            if (is_prime(num)) {
                printf("%d\n", num);
            }
        }


        return 0;
}


// gcc -fopenmp -o prime prime.c
//./prime
/* ### **Program Explanation for Parallel Prime Number Calculation Using OpenMP**

This program uses the OpenMP library to parallelize the computation of prime numbers in a given range, significantly reducing execution time by leveraging multiple threads. Below is a detailed breakdown of the code, the role of OpenMP, and the underlying theoretical concepts.

---

### **1. Key Concepts of OpenMP**

#### **What is OpenMP?**
- OpenMP (Open Multi-Processing) is an API that supports multi-platform shared memory multiprocessing programming in C, C++, and Fortran.
- **Features**:
  - Simple syntax for parallelizing loops and sections of code.
  - Dynamic thread management.
  - Work-sharing constructs, such as `#pragma omp parallel for`.

#### **How Parallelization Works**
- In sequential execution, a single thread processes the entire range.
- In parallel execution:
  - The workload (e.g., iterating over a range of numbers) is divided among multiple threads.
  - Each thread processes a portion of the range independently, leveraging multi-core CPU architecture.

---

### **2. Code Explanation**

#### **`is_prime` Function**
```c
int is_prime(int n) {
    if (n <= 1) return 0;  // Numbers <= 1 are not prime
    for (int i = 2; i * i <= n; i++) {  // Check divisors up to √n
        if (n % i == 0) return 0;  // If divisible, it's not prime
    }
    return 1;  // Number is prime
}
```
- **Purpose**:
  - Determines whether a given number `n` is prime.
- **Optimization**:
  - The loop runs up to the square root of `n` (`i * i <= n`), reducing the number of iterations.
- **Return Values**:
  - `0`: Not a prime number.
  - `1`: Prime number.

---

#### **Main Function**

##### **Defining the Range**
```c
int lower = 2, upper = 100;
printf("Prime numbers between %d and %d are:\n", lower, upper);
```
- Sets the range of numbers to test for primality (e.g., 2 to 100).

---

##### **Parallelizing the For Loop**
```c
#pragma omp parallel for
for (int num = lower; num <= upper; num++) {
    if (is_prime(num)) {
        printf("%d\n", num);
    }
}
```
- **`#pragma omp parallel for`**:
  - Parallelizes the for loop.
  - Divides the range of numbers (`lower` to `upper`) among multiple threads.
- **Execution**:
  - Each thread evaluates primality for a subset of numbers in the range.
- **Synchronization**:
  - OpenMP internally handles thread creation, workload distribution, and synchronization.

---

##### **Compiling and Running the Program**
1. **Compile the Program with OpenMP**:
   ```bash
   gcc -fopenmp -o prime prime.c
   ```
   - `-fopenmp` enables OpenMP support in GCC.
2. **Run the Program**:
   ```bash
   ./prime
   ```

#### **Sample Output**:
```
Prime numbers between 2 and 100 are:
2
3
5
7
11
13
17
19
23
29
31
...
97
```

---

### **3. Theoretical Insights**

#### **Advantages of Parallelization**
1. **Performance Improvement**:
   - Dividing the workload across threads reduces computation time.
   - Especially beneficial for large ranges (e.g., millions of numbers).
2. **Scalability**:
   - Exploits multi-core CPUs effectively.

#### **How OpenMP Schedules Work**
- **Work Distribution**:
  - OpenMP divides the for loop iterations among threads dynamically or statically.
- **Synchronization**:
  - Ensures proper handling of shared variables and avoids race conditions.

#### **Challenges in Parallelization**
1. **I/O Bottlenecks**:
   - Printing results (`printf`) can create contention among threads.
   - To resolve this, individual thread outputs can be stored and combined later.
2. **Thread Overhead**:
   - For small workloads, thread creation and management may outweigh the benefits.

---

### **Applications**
1. **Mathematical Computations**:
   - Prime number calculations, matrix operations, and large-scale simulations.
2. **Data Processing**:
   - Sorting, searching, and filtering large datasets.
3. **Scientific Research**:
   - High-performance computing for physics, chemistry, and engineering simulations.

Let me know if you'd like to explore further optimizations or additional OpenMP concepts! 😊 */
