

// 55. Write a program using PIPE, to Send data from parent to child over a pipe.
// (unnamed pipe )
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>


#define BUFFER_SIZE 25


int main() {
        int pipefd[2]; // File descriptors for the pipe
        pid_t pid; // Process ID


        char buffer[BUFFER_SIZE]; // Buffer for reading from and writing to the pipe


        // Create the pipe
        if (pipe(pipefd) == -1) {
            perror("pipe");
            exit(EXIT_FAILURE);
        }


        // Fork a child process
        pid = fork();


        if (pid < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        }


        if (pid > 0) { // Parent process
            close(pipefd[0]); // Close the reading end of the pipe in the parent


            printf("Parent: Writing data to the pipe...\n");
            // Write data to the pipe
            write(pipefd[1], "Hello, child!", 14);


            close(pipefd[1]); // Close the writing end of the pipe in the parent
            printf("Parent: Data written to the pipe.\n");
        } else { // Child process
            close(pipefd[1]); // Close the writing end of the pipe in the child


            printf("Child: Reading data from the pipe...\n");
            // Read data from the pipe
            read(pipefd[0], buffer, BUFFER_SIZE);
            printf("Child: Received message: %s\n", buffer);


            close(pipefd[0]); // Close the reading end of the pipe in the child
        }


        return 0;
}

/*This program implements **Interprocess Communication (IPC)** using an unnamed pipe to transfer data between a **parent process** and its **child process**. Below is a detailed explanation of the code:

---

### **Concept: Pipes**
A **pipe** is a unidirectional IPC mechanism used for communication between related processes. It creates a communication channel that connects the **reading end** (`pipefd[0]`) and the **writing end** (`pipefd[1]`).

---

### **Code Breakdown**

#### **1. Header Files**
```c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
```
- **`stdio.h`**: Provides functions for input/output operations like `printf`.
- **`stdlib.h`**: Provides general-purpose functions like `exit`.
- **`unistd.h`**: Provides pipe and process-related functions (`pipe`, `fork`, etc.).

---

#### **2. Buffer and Pipe Initialization**
```c
#define BUFFER_SIZE 25
int pipefd[2];
```
- **`BUFFER_SIZE`**: Size of the buffer to store data read from the pipe.
- **`pipefd`**: Array containing file descriptors for the pipe:
  - **`pipefd[0]`**: Reading end.
  - **`pipefd[1]`**: Writing end.

---

#### **3. Creating the Pipe**
```c
if (pipe(pipefd) == -1) {
    perror("pipe");
    exit(EXIT_FAILURE);
}
```
- **`pipe(pipefd)`**:
  - Creates an unnamed pipe.
  - Returns `0` on success and `-1` on failure.
- **Error Handling**:
  - Prints an error message using `perror` and exits if pipe creation fails.

---

#### **4. Forking the Process**
```c
pid = fork();
```
- **`fork()`**:
  - Creates a child process by duplicating the parent.
  - Returns:
    - `0` for the child process.
    - Positive value (child's PID) for the parent process.
    - `-1` on failure.
- **Error Handling**:
  - Prints an error and exits if the fork fails.

---

#### **5. Parent Process**
```c
if (pid > 0) {
    close(pipefd[0]); // Close reading end
    write(pipefd[1], "Hello, child!", 14);
    close(pipefd[1]); // Close writing end
}
```
- **Steps**:
  1. **Close the reading end**: The parent only writes, so it doesn't need the reading end (`pipefd[0]`).
  2. **Write data**: Sends the message `"Hello, child!"` to the child process via `pipefd[1]`.
  3. **Close the writing end**: After writing, closes the writing end of the pipe.

---

#### **6. Child Process**
```c
else if (pid == 0) {
    close(pipefd[1]); // Close writing end
    read(pipefd[0], buffer, BUFFER_SIZE); // Read data
    printf("Child: Received message: %s\n", buffer);
    close(pipefd[0]); // Close reading end
}
```
- **Steps**:
  1. **Close the writing end**: The child only reads, so it doesn't need the writing end (`pipefd[1]`).
  2. **Read data**: Retrieves the message sent by the parent process via `pipefd[0]`.
  3. **Display message**: Prints the received message.
  4. **Close the reading end**: After reading, closes the reading end of the pipe.

---

### **Key Points to Note**
1. **Unidirectional Communication**:
   - Data flows in one direction: parent writes, and child reads.
2. **Pipe Lifetime**:
   - The pipe exists only while the parent and child processes are running.

---

### **Compiling and Running the Program**

#### **1. Compile**:
```bash
gcc unnamed_pipe.c -o unnamed_pipe
```

#### **2. Execute**:
```bash
./unnamed_pipe
```

---

### **Sample Output**
```
Parent: Writing data to the pipe...
Parent: Data written to the pipe.
Child: Reading data from the pipe...
Child: Received message: Hello, child!
```

---

### **Theory Behind Pipes**

#### **What Are Pipes?**
1. **Definition**:
   - Pipes are a form of IPC that allow unidirectional data flow between processes.
2. **Key Features**:
   - **Anonymous**: Exists only while the processes are running.
   - **Unidirectional**: Requires two pipes for bidirectional communication.

#### **How Data Flows**
- **Write End (`pipefd[1]`)**: Used by the parent process to send data.
- **Read End (`pipefd[0]`)**: Used by the child process to receive data.

---

#### **Advantages**
1. **Simplicity**:
   - Easy to implement and manage.
2. **Direct Communication**:
   - Parent and child processes communicate efficiently without additional overhead.

#### **Limitations**
1. **Unidirectional**:
   - Data flows in one direction only.
2. **Parent-Child Relationship**:
   - Only related processes (parent-child or siblings) can use unnamed pipes.

---

### **Applications**
1. **Parent-Child Communication**:
   - Pass data or commands from parent to child.
2. **Command Pipelining**:
   - Build pipeline-like structures for related processes (e.g., `ls | grep`).

Let me know if you'd like to explore more advanced IPC mechanisms, such as named pipes or message queues! 😊 */
