
# 34. Generate a word frequency list for wonderland.txt. Hint: use grep, tr, sort, uniq (or anything else that you want)
#!/bin/bash


# Check if the file exists
if [ ! -f "sample.txt" ]; then
        echo "Error: File wonderland.txt not found."
        exit 1
fi


# Extract words from the file, convert to lowercase, and remove punctuation
words=$(grep -oE '\b\w+\b' sample.txt | tr '[:upper:]' '[:lower:]' | tr -d '[:punct:]')


# Count the frequency of each word and sort them
word_freq=$(echo "$words" | tr ' ' '\n' | sort | uniq -c)


# Print the word frequency list
echo "$word_freq"
:'
### 🔍 **Code Explanation**

This shell script analyzes a text file (`wonderland.txt`), processes its content, and generates a word frequency list. It utilizes text manipulation commands such as `grep`, `tr`, `sort`, and `uniq`.

---

### **Step-by-Step Code Analysis**

#### **1. File Existence Check**
```bash
if [ ! -f "sample.txt" ]; then
    echo "Error: File wonderland.txt not found."
    exit 1
fi
```
- **Purpose**: Ensures the file exists before attempting any operations.
- **`[ ! -f "sample.txt" ]`**:
  - Tests whether `sample.txt` is a regular file.
  - **Condition**:
    - If the file is missing, an error message is displayed, and the script exits (`exit 1`).

---

#### **2. Extracting Words**
```bash
words=$(grep -oE '\b\w+\b' sample.txt | tr '[:upper:]' '[:lower:]' | tr -d '[:punct:]')
```
- **`grep -oE '\b\w+\b' sample.txt`**:
  - **`-o`**: Outputs only matched portions.
  - **`-E`**: Enables extended regular expressions.
  - **`\b\w+\b`**: Matches whole words (word boundary `\b` and one or more word characters `\w+`).
- **`tr '[:upper:]' '[:lower:]'`**:
  - Converts all uppercase letters to lowercase to avoid case sensitivity.
- **`tr -d '[:punct:]'`**:
  - Removes punctuation marks, ensuring only clean words remain.

---

#### **3. Counting Word Frequencies**
```bash
word_freq=$(echo "$words" | tr ' ' '\n' | sort | uniq -c)
```
- **`echo "$words" | tr ' ' '\n'`**:
  - Converts space-separated words into newline-separated words, preparing for sorting.
- **`sort`**:
  - Arranges the words alphabetically.
- **`uniq -c`**:
  - Counts occurrences of each unique word.
  - Format: `[frequency] [word]`.

---

#### **4. Printing the Frequency List**
```bash
echo "$word_freq"
```
- Displays the word frequency list.

---

### 📚 **Theory Behind Commands**

#### **1. `grep` Command**
- **Purpose**: Searches for patterns in text files.
- **Options Used**:
  - `-o`: Outputs matching patterns only.
  - `-E`: Enables extended regex for complex patterns.

#### **2. `tr` Command**
- **Purpose**: Translates or deletes characters from input text.
- **Options Used**:
  - `[:upper:]`: Matches uppercase letters.
  - `[:lower:]`: Matches lowercase letters.
  - `-d '[:punct:]'`: Deletes punctuation.

#### **3. `sort` Command**
- **Purpose**: Sorts input text alphabetically or numerically.
- **Usage**:
  - Organizes words to group identical ones together for counting.

#### **4. `uniq` Command**
- **Purpose**: Filters duplicate lines and counts occurrences.
- **Options Used**:
  - `-c`: Counts the occurrences of duplicate lines.

---

### Example Execution

#### Input:
Contents of `wonderland.txt`:
```
Alice was beginning to get very tired of sitting by her sister on the bank.
```

#### Command Execution:
```bash
chmod +x word_frequency.sh
./word_frequency.sh
```

#### Output:
```
1 alice
1 bank
1 beginning
1 by
1 get
1 her
1 of
1 on
1 sitting
1 sister
1 the
1 tired
1 to
1 very
1 was
```

---

### **Applications**
- Text Analysis:
  - Identify frequently used words in a document.
- Data Preprocessing:
  - Clean text for machine learning or natural language processing (NLP).
- Research:
  - Examine word usage in literature, articles, or books.

Let me know if you'd like further improvements, such as handling stop words or generating detailed reports! 😊
'



