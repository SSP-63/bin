

// 43. Write a program to demonstrate IPC using shared memory (shmget, shmat, shmdt). In this, one process will take numbers as input from user and second process will sort the numbers and put back to shared memory. Third process will display the shared memory.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>


#define SHM_SIZE 1024 // Size of shared memory segment


int main() {
        key_t key = ftok(".", 'A'); // Generate a unique key
        int shmid; // Shared memory ID
        int *shm_ptr; // Pointer to shared memory
        int numbers[100]; // Array to store numbers
        int num_count; // Number of numbers entered by user
        int i;


        // Create a shared memory segment
        shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
        if (shmid == -1) {
            perror("shmget");
            exit(1);
        }


        // Attach the shared memory segment to the process's address space
        shm_ptr = (int *) shmat(shmid, NULL, 0);
        if (shm_ptr == (int *) -1) {
            perror("shmat");
            exit(1);
        }


        // Prompt the user to enter numbers
        printf("Enter the number of numbers (up to 100): ");
        scanf("%d", &num_count);


        printf("Enter %d numbers:\n", num_count);
        for (i = 0; i < num_count; i++) {
            scanf("%d", &numbers[i]);
        }


        // Write input numbers to shared memory
        for (i = 0; i < num_count; i++) {
            shm_ptr[i] = numbers[i];
        }


        // Fork a child process to sort numbers in shared memory
        pid_t pid = fork();
        if (pid == -1) {
            perror("fork");
            exit(1);
        } else if (pid == 0) { // Child process
            // Sort numbers in shared memory using bubble sort algorithm
            for (i = 0; i < num_count - 1; i++) {
                for (int j = 0; j < num_count - i - 1; j++) {
                    if (shm_ptr[j] > shm_ptr[j + 1]) {
                        // Swap numbers if they are in the wrong order
                        int temp = shm_ptr[j];
                        shm_ptr[j] = shm_ptr[j + 1];
                        shm_ptr[j + 1] = temp;
                    }
                }
            }
            exit(0);
        } else { // Parent process
            wait(NULL); // Wait for the child process to finish sorting


            // Fork another child process to display sorted numbers
            pid_t pid2 = fork();
            if (pid2 == -1) {
                perror("fork");
                exit(1);
            } else if (pid2 == 0) { // Child process
                printf("Sorted numbers in shared memory:\n");
                for (i = 0; i < num_count; i++) {
                    printf("%d ", shm_ptr[i]);
                }
                printf("\n");
                exit(0);
            } else { // Parent process
                wait(NULL); // Wait for the second child process to finish


                // Detach the shared memory segment
                if (shmdt(shm_ptr) == -1) {
                    perror("shmdt");
                    exit(1);
                }


                // Remove the shared memory segment
                if (shmctl(shmid, IPC_RMID, NULL) == -1) {
                    perror("shmctl");
                    exit(1);
                }
            }
        }


        return 0;
}
/* ### 📚 **In-depth Explanation of IPC Using Shared Memory**

This program demonstrates **Interprocess Communication (IPC)** using shared memory. Here, three processes perform the following tasks:
1. **First Process**: Accepts an array of numbers from the user and writes them to shared memory.
2. **Second Process**: Sorts the numbers stored in shared memory.
3. **Third Process**: Displays the sorted numbers.

Shared memory is used as the communication medium between these processes.

---

### **Key Concepts: Shared Memory**

#### **1. What is Shared Memory?**
- Shared memory is an IPC mechanism that allows multiple processes to access a common memory segment.
- One process can write data into shared memory, and other processes can read or modify it directly without additional system calls.

#### **2. System Calls for Shared Memory**
- **`shmget`**: Creates or retrieves a shared memory segment.
- **`shmat`**: Attaches the shared memory segment to the process's address space.
- **`shmdt`**: Detaches the shared memory segment from the process.
- **`shmctl`**: Controls or removes the shared memory segment.

#### **3. Synchronization Between Processes**
- Processes communicate via shared memory but must use synchronization mechanisms (e.g., forks or semaphores) to manage concurrent access.

---

### **Line-by-Line Explanation**

#### **1. Key and Shared Memory Initialization**
```c
key_t key = ftok(".", 'A');
shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
```
- **`ftok`**: Generates a unique key based on the file path (`"."`) and an identifier (`'A'`).
- **`shmget`**:
  - Creates a shared memory segment of size `SHM_SIZE` (1024 bytes).
  - Flags: `IPC_CREAT` (create if it doesn't exist) and `0666` (read/write for all users).
- **Error Handling**:
  - If `shmget` fails, it prints an error message and exits.

---

#### **2. Attaching to Shared Memory**
```c
shm_ptr = (int *) shmat(shmid, NULL, 0);
if (shm_ptr == (int *) -1) {
    perror("shmat");
    exit(1);
}
```
- **`shmat`**:
  - Maps the shared memory segment to the process's virtual address space.
  - Returns a pointer to the beginning of the shared memory segment.
- **Error Handling**:
  - Prints an error if the attachment fails.

---

#### **3. Writing Numbers to Shared Memory**
```c
for (i = 0; i < num_count; i++) {
    shm_ptr[i] = numbers[i];
}
```
- User input is stored in an array (`numbers`) and then copied into shared memory (`shm_ptr`).

---

#### **4. Sorting Numbers in Shared Memory**
```c
for (i = 0; i < num_count - 1; i++) {
    for (int j = 0; j < num_count - i - 1; j++) {
        if (shm_ptr[j] > shm_ptr[j + 1]) {
            int temp = shm_ptr[j];
            shm_ptr[j] = shm_ptr[j + 1];
            shm_ptr[j + 1] = temp;
        }
    }
}
```
- **Sorting**:
  - Uses the bubble sort algorithm to sort numbers directly in shared memory.
  - Ensures numbers are sorted in ascending order.

---

#### **5. Displaying Sorted Numbers**
```c
printf("Sorted numbers in shared memory:\n");
for (i = 0; i < num_count; i++) {
    printf("%d ", shm_ptr[i]);
}
printf("\n");
```
- Iterates through the sorted array stored in shared memory and prints the numbers to the console.

---

#### **6. Cleaning Up Shared Memory**
```c
if (shmdt(shm_ptr) == -1) {
    perror("shmdt");
    exit(1);
}
if (shmctl(shmid, IPC_RMID, NULL) == -1) {
    perror("shmctl");
    exit(1);
}
```
- **`shmdt`**:
  - Detaches the shared memory segment from the process's address space.
- **`shmctl`**:
  - Removes the shared memory segment from the system.

---

### **Program Workflow**

1. **Parent Process (First Process)**:
   - Creates shared memory and writes user-provided numbers to it.
   - Forks a child process to sort the numbers.

2. **Child Process (Second Process)**:
   - Sorts the numbers in shared memory using the bubble sort algorithm.

3. **Parent Process**:
   - Waits for the second process to complete.
   - Forks another child process to display the sorted numbers.

4. **Second Child Process (Third Process)**:
   - Reads sorted numbers from shared memory and prints them to the console.

5. **Cleanup**:
   - Detaches and removes the shared memory segment.

---

### **Theory Behind IPC Using Shared Memory**

#### **Advantages**
1. **High Speed**:
   - Shared memory avoids data copying between processes, making it faster than other IPC mechanisms like pipes or message queues.
2. **Shared State**:
   - Allows multiple processes to operate on the same data, useful for collaborative applications.

#### **Challenges**
1. **Synchronization**:
   - Requires mechanisms like semaphores or mutexes to prevent race conditions.
2. **Resource Cleanup**:
   - Explicit cleanup is necessary to avoid resource leaks.

---

### Example Execution

#### **Compilation**:
```bash
gcc 43.c -o 43
```

#### **Execution**:
```bash
./43
```

#### **Sample Interaction**:
Input:
```
Enter the number of numbers (up to 100): 5
Enter 5 numbers:
42 17 8 23 11
```

Output:
```
Sorted numbers in shared memory:
8 11 17 23 42
```

---

### **Applications**
1. **Real-Time Data Sharing**:
   - Useful in applications requiring fast communication, such as gaming or sensor data processing.
2. **Collaboration Between Processes**:
   - Can be extended to scenarios like shared caches or collaborative computation.

This implementation efficiently showcases IPC using shared memory with three cooperating processes. Let me know if you'd like further optimizations or synchronization techniques like semaphores to ensure process-safe shared memory access! 😊 */
