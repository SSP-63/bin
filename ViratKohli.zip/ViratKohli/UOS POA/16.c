
// 16. Write a multithread program in linux to use the pthread library.
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>


#define NUM_THREADS 5


void *threadFunction(void *threadId) {
        long tid;
        tid = (long) threadId;
        printf("Hello from thread %ld\n", tid);
        pthread_exit(NULL);
}


int main() {
        pthread_t threads[NUM_THREADS];
        int rc;
        long t;


        for (t = 0; t < NUM_THREADS; t++) {
            printf("Creating thread %ld\n", t);
            rc = pthread_create(&threads[t], NULL, threadFunction, (void *) t);
            if (rc) {
                printf("ERROR: return code from pthread_create() is %d\n", rc);
                exit(-1);
            }
        }


        pthread_exit(NULL);
}
/*  This code demonstrates multithreading in C using the POSIX Threads (pthread) library. Let's go step by step and understand both the code logic and the theoretical concepts behind it.

---

### 🔍 **Line-by-Line Explanation**
1. **`#include <stdio.h>`**: Provides functionality for input/output, like `printf()` used to print messages.
2. **`#include <stdlib.h>`**: Includes standard utility functions like `exit()` to terminate the program in case of errors.
3. **`#include <pthread.h>`**: Includes the POSIX Threads library, enabling multithreading by providing thread-related functions like `pthread_create()` and `pthread_exit()`.

4. **`#define NUM_THREADS 5`**: Defines a constant `NUM_THREADS` with a value of 5, representing the number of threads to create.

5. **Thread Function:**
   ```c
   void *threadFunction(void *threadId)
   ```
   - Function executed by each thread.
   - Accepts a `void*` parameter (`threadId`) for thread-specific data, in this case, the thread ID.
   - **`tid = (long) threadId;`**: Converts the passed pointer (`void*`) into a long integer, representing the thread ID.
   - **`printf()`**: Prints a message with the thread ID, showing which thread is running.
   - **`pthread_exit(NULL);`**: Terminates the thread after it completes execution, signaling the thread's end.

6. **`int main()`**: The main function orchestrates thread creation and execution.
   - **`pthread_t threads[NUM_THREADS];`**: Declares an array of `pthread_t` variables to hold thread identifiers for the threads created.
   - **`int rc;`**: Variable to store the return code of `pthread_create()`.
   - **`long t;`**: Loop variable to iterate through thread creation.

7. **Thread Creation Loop:**
   ```c
   for (t = 0; t < NUM_THREADS; t++) {
   ```
   - Loops `NUM_THREADS` times (5 in this case) to create threads.
   - **`printf()`**: Displays which thread is being created.
   - **`pthread_create()`**: Creates a new thread:
     - **First Argument**: Pointer to `pthread_t` where the thread ID will be stored.
     - **Second Argument**: `NULL` specifies default thread attributes (e.g., stack size).
     - **Third Argument**: Pointer to the thread function (`threadFunction`), which will execute in the thread.
     - **Fourth Argument**: Data to pass to the thread function, in this case, the loop index `t` as the thread ID.

   - **Error Handling:**
     ```c
     if (rc) {
         printf("ERROR: return code from pthread_create() is %d\n", rc);
         exit(-1);
     }
     ```
     - Checks `rc` for errors during thread creation.
     - If non-zero, an error message is printed, and the program exits with a non-successful exit code `-1`.

8. **`pthread_exit(NULL);`**
   - Prevents the main thread from terminating before child threads complete.
   - Without this, the program might end before the threads finish running.

---

### 📚 **Concepts Behind Multithreading in C**
1. **Threads**: Threads are lightweight processes that share the same memory space but execute independently. They allow programs to perform multiple tasks concurrently.

2. **POSIX Threads (pthreads)**:
   - A standard API for creating and managing threads.
   - Functions like `pthread_create()` and `pthread_exit()` are part of this library.

3. **Thread Creation (`pthread_create`)**:
   - Syntax: 
     ```c
     int pthread_create(pthread_t *thread, const pthread_attr_t *attr, void *(*start_routine)(void *), void *arg);
     ```
     - Creates a thread and executes `start_routine`.
     - Returns 0 on success, or an error code otherwise.

4. **Thread Termination (`pthread_exit`)**:
   - Ensures a thread ends cleanly after execution.
   - Prevents abrupt termination and ensures proper resource cleanup.

5. **Race Conditions**: 
   - This code doesn’t deal with shared resources, so race conditions are not an issue.
   - If threads modified shared data, synchronization mechanisms (like mutexes) would be necessary to prevent conflicts.

6. **Error Handling**:
   - Robust error checking ensures smooth program flow and avoids crashes.

7. **Scalability**:
   - Threads enable efficient utilization of multi-core processors by running tasks in parallel.

---

This code is a simple and effective demonstration of threading. It showcases how threads can execute tasks simultaneously, improving performance in real-world applications like web servers, image processing, or simulations. Do you have any specific questions or need further clarification on this? 😊*/
