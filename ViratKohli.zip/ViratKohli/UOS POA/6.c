// 6. Write a program to demonstrate the variations exec system call.
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main() {
        pid_t pid;
        int status;


        // Using execl
        pid = fork(); // Create a child process
        if (pid == 0) { // If this is the child process
            printf("Child process using execl:\n");
            execl("/bin/ls", "ls", "-l", NULL); // Execute ls -l command
            perror("execl"); // Print error if execl fails
            _exit(1); // Terminate child process
        }
        waitpid(pid, &status, 0); // Wait for child process to finish


        // Using execlp
        pid = fork(); // Create a child process
        if (pid == 0) { // If this is the child process
            printf("\nChild process using execlp:\n");
            execlp("ls", "ls", "-l", NULL); // Execute ls -l command using PATH
            perror("execlp"); // Print error if execlp fails
            _exit(1); // Terminate child process
        }
        waitpid(pid, &status, 0); // Wait for child process to finish


        // Using execle
        pid = fork(); // Create a child process
        if (pid == 0) { // If this is the child process
            printf("\nChild process using execle:\n");
            char *envp[] = {"PATH=/bin", NULL}; // Define environment variable
            execle("/bin/ls", "ls", "-l", NULL, envp); // Execute ls -l command with custom environment
            perror("execle"); // Print error if execle fails
            _exit(1); // Terminate child process
        }
        waitpid(pid, &status, 0); // Wait for child process to finish


        // Using execv
        pid = fork(); // Create a child process
        if (pid == 0) { // If this is the child process
            printf("\nChild process using execv:\n");
            char *args[] = {"ls", "-l", NULL}; // Arguments array
            execv("/bin/ls", args); // Execute ls -l command with arguments
            perror("execv"); // Print error if execv fails
            _exit(1); // Terminate child process
        }
        waitpid(pid, &status, 0); // Wait for child process to finish


        // Using execvp
        pid = fork(); // Create a child process
        if (pid == 0) { // If this is the child process
            printf("\nChild process using execvp:\n");
            char *args[] = {"ls", "-l", NULL}; // Arguments array
            execvp("ls", args); // Execute ls -l command using PATH and arguments
            perror("execvp"); // Print error if execvp fails
            _exit(1); // Terminate child process
        }
        waitpid(pid, &status, 0); // Wait for child process to finish


        printf("\nParent process done.\n");


        return 0; // Exit parent process
}

// #include <stdio.h>          // Standard input-output functions like printf(), perror()
// #include <unistd.h>         // Unix standard functions like fork(), execl(), execlp(), execle(), execv(), execvp()
// #include <sys/types.h>      // Defines pid_t and other process-related types
// #include <sys/wait.h>       // Functions for process control like waitpid()

// int main() {
//         pid_t pid;           // Variable to store the process ID returned by fork()
//         int status;          // Variable to store the exit status of the child process

//         // Using execl
//         pid = fork();        // fork() creates a new child process
//         if (pid == 0) {      // If this is the child process
//             printf("Child process using execl:\n");
//             execl("/bin/ls", "ls", "-l", NULL);
//             // execl() replaces the child process with /bin/ls and passes arguments "-l"
//             // The first argument "ls" is used as argv[0] and must match the program name
//             // NULL marks the end of the argument list
//             perror("execl");  // If execl() fails, print the error message
//             _exit(1);         // Exit the child process with an error status
//         }
//         waitpid(pid, &status, 0); // Parent waits for child to finish


//         // Using execlp
//         pid = fork();        // fork() creates a new child process
//         if (pid == 0) {      // If this is the child process
//             printf("\nChild process using execlp:\n");
//             execlp("ls", "ls", "-l", NULL);
//             // execlp() searches for the "ls" command in the directories listed in PATH
//             // Similar to execl, but with PATH lookup
//             perror("execlp"); // If execlp() fails, print the error message
//             _exit(1);         // Exit the child process with an error status
//         }
//         waitpid(pid, &status, 0); // Parent waits for child to finish


//         // Using execle
//         pid = fork();        // fork() creates a new child process
//         if (pid == 0) {      // If this is the child process
//             printf("\nChild process using execle:\n");
//             char *envp[] = {"PATH=/bin", NULL}; // Define custom environment variables
//             execle("/bin/ls", "ls", "-l", NULL, envp);
//             // execle() is similar to execl() but allows passing custom environment variables
//             // Here, we are setting PATH=/bin to search only in the /bin directory
//             perror("execle"); // If execle() fails, print the error message
//             _exit(1);         // Exit the child process with an error status
//         }
//         waitpid(pid, &status, 0); // Parent waits for child to finish


//         // Using execv
//         pid = fork();        // fork() creates a new child process
//         if (pid == 0) {      // If this is the child process
//             printf("\nChild process using execv:\n");
//             char *args[] = {"ls", "-l", NULL}; // Arguments array
//             execv("/bin/ls", args); 
//             // execv() takes an array of arguments (argv) and does not search PATH
//             // It directly uses the full path to the executable provided
//             perror("execv");  // If execv() fails, print the error message
//             _exit(1);         // Exit the child process with an error status
//         }
//         waitpid(pid, &status, 0); // Parent waits for child to finish


//         // Using execvp
//         pid = fork();        // fork() creates a new child process
//         if (pid == 0) {      // If this is the child process
//             printf("\nChild process using execvp:\n");
//             char *args[] = {"ls", "-l", NULL}; // Arguments array
//             execvp("ls", args);
//             // execvp() is similar to execv() but searches for the executable in PATH
//             // It looks up "ls" in the directories listed in the PATH environment variable
//             perror("execvp"); // If execvp() fails, print the error message
//             _exit(1);         // Exit the child process with an error status
//         }
//         waitpid(pid, &status, 0); // Parent waits for child to finish


//         printf("\nParent process done.\n");
//         // Parent process finishes after all child processes have executed

//         return 0; // Program ends successfully
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// exec* family of functions:
// - exec() is a family of system calls used to execute a new program within the current process.
// - It replaces the current process image with a new program.
// - There are variations of exec() based on how arguments and environment variables are passed:
//     - execl(): Passes a list of arguments as separate parameters.
//     - execlp(): Similar to execl() but looks for the program in the directories listed in the PATH environment variable.
//     - execle(): Passes a list of arguments and environment variables.
//     - execv(): Passes arguments as an array of strings.
//     - execvp(): Similar to execv() but searches for the program in the PATH.

// fork():
// - fork() creates a new process by duplicating the parent process.
// - The new process is a child process that starts executing from the point of fork().

// waitpid():
// - waitpid() is used by the parent process to wait for the termination of a specific child process.
// - It allows checking the exit status of the child process.

