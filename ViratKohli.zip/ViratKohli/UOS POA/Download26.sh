# 26. Write a shell script to download webpage at given url using command(wget)
#!/bin/bash

# Check if correct number of arguments are provided
if [ $# -ne 1 ]; then
        echo "Usage: $0 <url>"
        exit 1
fi

url="$1"

# Use wget to download the webpage at the given URL
wget "$url" -O downloaded_page.html

if [ $? -eq 0 ]; then
        echo "Webpage downloaded successfully"
else
        echo "Failed to download the webpage"
fi


# Make the script executable:

# chmod +x Download26.sh

# Run the script with a URL: Example usage:

# ./Download26.sh https://www.google.com
