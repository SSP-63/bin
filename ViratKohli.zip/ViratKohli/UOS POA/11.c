
// 11. Write a program for alarm clock using alarm and signal system call.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>


// Global variable to track whether the alarm has gone off
volatile sig_atomic_t alarm_triggered = 0;


// Signal handler function for SIGALRM
void alarm_handler(int signum) {
        alarm_triggered = 1;
}


int main() {
        int seconds;


        // Set up signal handler for SIGALRM
        if (signal(SIGALRM, alarm_handler) == SIG_ERR) {
            perror("signal");
            exit(EXIT_FAILURE);
        }


        printf("Enter the number of seconds for the alarm: ");
        scanf("%d", &seconds);


        printf("Setting alarm for %d seconds...\n", seconds);


        // Set an alarm for the specified number of seconds
        alarm(seconds);


        // Wait for the alarm to go off
        while (!alarm_triggered) {
            // Wait for the alarm to trigger
        }


        printf("Alarm triggered! Time's up!\n");


        return 0;
}
// #include <stdio.h>        // Standard input-output functions like printf(), scanf()
// #include <stdlib.h>       // Standard library functions like exit()
// #include <unistd.h>       // Unix standard functions like alarm()
// #include <signal.h>       // Functions for signal handling like signal(), alarm()

// volatile sig_atomic_t alarm_triggered = 0;
// Global variable to track whether the alarm has gone off.
// 'volatile' ensures the variable is always fetched from memory, avoiding optimization by the compiler.

// void alarm_handler(int signum) {
//     // Signal handler function for SIGALRM
//     alarm_triggered = 1;   // Set the alarm_triggered flag when the alarm goes off
// }

// int main() {
//     int seconds; // Variable to store the number of seconds for the alarm

//     // Set up signal handler for SIGALRM (signal for alarm)
    
//     if (signal(SIGALRM, alarm_handler) == SIG_ERR) {  // Register the signal handler for SIGALRM
//         perror("signal");   // Print error if signal setup fails
//         exit(EXIT_FAILURE); // Exit the program with failure status
//     }

//     printf("Enter the number of seconds for the alarm: ");

//     // Get user input for the number of seconds to set the alarm for
//     scanf("%d", &seconds);  // Read the number of seconds

//     printf("Setting alarm for %d seconds...\n", seconds);

//     // Set an alarm for the specified number of seconds
//     alarm(seconds);  // Trigger the SIGALRM signal after the specified number of seconds

//     // Wait for the alarm to go off
//     while (!alarm_triggered) {  // Loop until the alarm is triggered
//         // The program will keep waiting here until the alarm_handler is called
//     }

//     printf("Alarm triggered! Time's up!\n");  // Notify the user when the alarm goes off

//     return 0;  // End the program
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// signal():
// - signal() is used to associate a signal (SIGALRM) with a signal handler function (alarm_handler).
// - When the signal is received, the alarm_handler function is executed to set the alarm_triggered flag.

// alarm():
// - alarm() is used to send a SIGALRM signal to the process after the specified number of seconds.
// - The process will wait for this signal and respond with the signal handler defined for SIGALRM.

// volatile sig_atomic_t:
// - The volatile keyword tells the compiler not to optimize the variable, ensuring the program always reads the value from memory.
// - sig_atomic_t is used for variables modified in signal handlers to ensure they are safely updated and read across multiple contexts.

