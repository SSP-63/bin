

// 66.write prog using FIFO/mknod (named pipe)/unmanned pipe for uppercase to lowercase conversion
#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <cstring>
#include <cctype>
#include <cstdlib>


using namespace std;


const char *inputFifo = "/tmp/input_fifo";
const char *outputFifo = "/tmp/output_fifo";


int main()
{
  // Create the input FIFO (named pipe) if it doesn't exist
  if (mkfifo(inputFifo, 0666) == -1)
  {
        cerr << "Error creating input FIFO" << endl;
        exit(EXIT_FAILURE);
  }


  // Create the output FIFO (named pipe) if it doesn't exist
  if (mkfifo(outputFifo, 0666) == -1)
  {
        cerr << "Error creating output FIFO" << endl;
        exit(EXIT_FAILURE);
  }


  // Open the input FIFO for reading
  int inputFd = open(inputFifo, O_RDONLY);
  if (inputFd == -1)
  {
        cerr << "Error opening input FIFO for reading" << endl;
        exit(EXIT_FAILURE);
  }


  // Open the output FIFO for writing
  int outputFd = open(outputFifo, O_WRONLY);
  if (outputFd == -1)
  {
        cerr << "Error opening output FIFO for writing" << endl;
        exit(EXIT_FAILURE);
  }


  char buffer[256];
  ssize_t bytesRead;


  // Read from the input FIFO and convert to lowercase
  while ((bytesRead = read(inputFd, buffer, sizeof(buffer))) > 0)
  {
        for (ssize_t i = 0; i < bytesRead; ++i)
        {
          buffer[i] = tolower(buffer[i]);
        }


        // Write the converted text to the output FIFO
        if (write(outputFd, buffer, bytesRead) == -1)
        {
          cerr << "Error writing to output FIFO" << endl;
          exit(EXIT_FAILURE);
        }
  }


  // Close the FIFOs
  close(inputFd);
  close(outputFd);


  // Remove the FIFOs
  unlink(inputFifo);
  unlink(outputFifo);


  cout << "Conversion complete." << endl;


  return 0;
}
// How to run:
// rm /tmp/input_fifo /tmp/output_fifo
// g++ 66.cpp -o uppercase_to_lowercase
// ./uppercase_to_lowercase
// On New Terminal
// echo "HELLO" >/tmp/input_fifo
// cat /tmp/output_fifo
// rm /tmp/input_fifo /tmp/output_fifo


// Step-by-Step Instructions:

//     Remove any existing FIFO files:

//     Before running the program, ensure that there are no existing FIFO files that might interfere. In your terminal, run the following commands:

// rm /tmp/input_fifo /tmp/output_fifo

// Compile the C++ program:

// Use the following command to compile your 66.cpp file:

// g++ 66.cpp -o uppercase_to_lowercase

// Run the Program:

// After compiling the program, run it to start the process:

// ./uppercase_to_lowercase

// This program will create the named FIFOs (/tmp/input_fifo and /tmp/output_fifo) and start waiting for input.

// In a New Terminal, Send Input to the FIFO:

// Open a new terminal and send uppercase text through the /tmp/input_fifo FIFO using the echo command:

// echo "HELLO" > /tmp/input_fifo

// This sends the string HELLO to the FIFO, which will be processed by your program.

// Read the Output from the Output FIFO:

// Now, you can check the output in the output FIFO:

// cat /tmp/output_fifo

// The program should print the lowercase version of the string, which will be:

// hello

// Clean up by Removing the FIFOs:

// Once you're done, you can clean up the FIFOs by deleting them:

// rm /tmp/input_fifo /tmp/output_fifo

/* This program efficiently uses **named pipes (FIFOs)** to achieve **uppercase-to-lowercase conversion** for interprocess communication (IPC). Here's a clear explanation of its functionality and execution steps.

---

### **1. Overview of the Program**

- The program creates two FIFOs:
  1. **`/tmp/input_fifo`**: To receive uppercase text.
  2. **`/tmp/output_fifo`**: To store and output lowercase-converted text.
  
- It **reads uppercase text** from the input FIFO, **converts it to lowercase**, and **writes the result** into the output FIFO.

---

### **2. Key Components of the Program**

#### **2.1 FIFO Creation**
```cpp
if (mkfifo(inputFifo, 0666) == -1)
if (mkfifo(outputFifo, 0666) == -1)
```
- **`mkfifo`**:
  - Creates the named pipes (input and output FIFOs) with read/write permissions (`0666`).
- **Error Handling**:
  - If the FIFOs cannot be created, the program terminates with an error message.

#### **2.2 FIFO Reading and Conversion**
```cpp
int inputFd = open(inputFifo, O_RDONLY);
int outputFd = open(outputFifo, O_WRONLY);
```
- **`open`**:
  - Opens the FIFOs:
    - Input FIFO: Opened for reading (`O_RDONLY`).
    - Output FIFO: Opened for writing (`O_WRONLY`).
  
#### **Conversion Logic**
```cpp
for (ssize_t i = 0; i < bytesRead; ++i) {
    buffer[i] = tolower(buffer[i]);
}
```
- Loops through each character read from the input FIFO.
- Converts uppercase letters (`A-Z`) to lowercase using `tolower`.

#### **2.3 Writing to Output FIFO**
```cpp
write(outputFd, buffer, bytesRead);
```
- Writes the converted text into the output FIFO.
- **Error Handling**:
  - If writing fails, the program terminates with an error message.

#### **2.4 Cleanup**
```cpp
unlink(inputFifo);
unlink(outputFifo);
```
- **`unlink`**:
  - Removes the FIFOs from the filesystem after the conversion is complete.

---

### **3. How to Run the Program**

#### **Step 1: Clean Existing FIFOs**
Remove any pre-existing FIFOs to avoid conflicts:
```bash
rm /tmp/input_fifo /tmp/output_fifo
```

#### **Step 2: Compile the Program**
Compile the program using the `g++` compiler:
```bash
g++ 66.cpp -o uppercase_to_lowercase
```

#### **Step 3: Start the Program**
Run the compiled program to initialize the FIFOs:
```bash
./uppercase_to_lowercase
```

#### **Step 4: Send Input**
In a new terminal, send uppercase text to the input FIFO:
```bash
echo "HELLO WORLD" > /tmp/input_fifo
```

#### **Step 5: View Output**
In the same or another terminal, read the converted output from the output FIFO:
```bash
cat /tmp/output_fifo
```

#### **Step 6: Clean Up**
Once finished, remove the FIFOs:
```bash
rm /tmp/input_fifo /tmp/output_fifo
```

---

### **4. Example Execution**

#### **Input (Sent to `/tmp/input_fifo`)**:
```
HELLO WORLD
```

#### **Output (Read from `/tmp/output_fifo`)**:
```
hello world
```

---

### **5. Theory: Advantages of FIFOs**

#### **Key Features of FIFOs**
1. **Named Pipe**:
   - Unlike unnamed pipes, FIFOs persist in the filesystem and can be shared by unrelated processes.
2. **Unidirectional**:
   - Data flows in a single direction (input to output). Bidirectional communication requires two FIFOs.
3. **Blocking Behavior**:
   - The `read` call blocks until the FIFO receives data.
   - The `write` call blocks until a process reads the data.

#### **Use Case Scenarios**
- **Data Transformation**:
  - Process and manipulate text or data streams (e.g., uppercase-to-lowercase conversion).
- **Producer-Consumer Model**:
  - The FIFO acts as an intermediary between the producer (input) and the consumer (output).

---

This program is an excellent example of using FIFOs for real-time text processing in a simple and structured way. Let me know if you'd like additional features like handling larger data streams or adding bidirectional communication! 😊*/
