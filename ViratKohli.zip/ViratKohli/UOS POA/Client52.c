
// Client:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>


#define PORT 8080
#define BUFFER_SIZE 1024


int main() {
        int sockfd;
        char buffer[BUFFER_SIZE];
        struct sockaddr_in servaddr;


        // Create UDP socket
        if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
            perror("socket creation failed");
            exit(EXIT_FAILURE);
        }


        // Initialize server address structure
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(PORT);
        servaddr.sin_addr.s_addr = INADDR_ANY;


        int n, len;
        len = sizeof(servaddr); // len is value/result


        // Send message to server
        const char *message = "Hello from client";
        sendto(sockfd, (const char *)message, strlen(message), MSG_CONFIRM, (const struct sockaddr *)&servaddr, len);
        printf("Message sent to server\n");


        // Receive message from server
        n = recvfrom(sockfd, (char *)buffer, BUFFER_SIZE, MSG_WAITALL, (struct sockaddr *)&servaddr, &len);
        buffer[n] = '\0';
        printf("Server : %s\n", buffer);


        // Close the socket
        close(sockfd);
        return 0;
}


// gcc -o udp_server udp_server.c
// gcc -o udp_client udp_client.c


// ./udp_server
// ./udp_client

/* This program implements **UDP client-server communication** using the **UDP protocol**. Below is a detailed explanation of the client-side code provided, as well as the necessary steps to run it alongside its server counterpart.

---

### **Understanding UDP**

UDP stands for **User Datagram Protocol**:
1. **Connectionless Protocol**:
   - Unlike TCP, UDP does not establish a connection before sending data.
   - Each message is sent independently, without guaranteeing delivery.
2. **Faster and Lightweight**:
   - UDP is faster but lacks reliability compared to TCP.
3. **Common Use Cases**:
   - Used in real-time applications like streaming, gaming, and DNS resolution.

---

### **Step-by-Step Code Explanation**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
```
- **`stdio.h`**: Provides input/output functions like `printf` and `perror`.
- **`stdlib.h`**: Includes `exit` for error handling.
- **`string.h`**: Used for string manipulation (e.g., `memset`).
- **`unistd.h`**: Contains system call wrappers like `close`.
- **`arpa/inet.h`**: Includes networking-specific functions like `inet_pton` and `sendto`.

---

#### **2. Define Constants**
```c
#define PORT 8080
#define BUFFER_SIZE 1024
```
- **`PORT`**:
  - Specifies the port number on which the server is listening.
- **`BUFFER_SIZE`**:
  - Defines the maximum size of the buffer for message exchange.

---

#### **3. Create UDP Socket**
```c
if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    perror("socket creation failed");
    exit(EXIT_FAILURE);
}
```
- **`socket`**:
  - Creates a socket endpoint for communication.
  - **Parameters**:
    - `AF_INET`: Specifies IPv4 address family.
    - `SOCK_DGRAM`: Indicates UDP protocol (connectionless).
    - `0`: Selects the default protocol for the given type.
- **Error Handling**:
  - Prints an error and terminates the program if socket creation fails.

---

#### **4. Prepare Server Address Structure**
```c
memset(&servaddr, 0, sizeof(servaddr));
servaddr.sin_family = AF_INET;
servaddr.sin_port = htons(PORT);
servaddr.sin_addr.s_addr = INADDR_ANY;
```
- **`memset`**:
  - Initializes the server address structure (`servaddr`) with zeros.
- **Fields**:
  - **`sin_family`**: Specifies the IPv4 address family (`AF_INET`).
  - **`sin_port`**: Sets the server port number using `htons` (host-to-network byte order conversion).
  - **`sin_addr.s_addr`**: Assigns the wildcard address (`INADDR_ANY`) to indicate that any available server address can be used.

---

#### **5. Send Message to Server**
```c
const char *message = "Hello from client";
sendto(sockfd, (const char *)message, strlen(message), MSG_CONFIRM, (const struct sockaddr *)&servaddr, len);
```
- **`sendto`**:
  - Sends the message `message` to the server via the socket (`sockfd`).
  - **Parameters**:
    - `sockfd`: The UDP socket.
    - `message`: The data to send.
    - `strlen(message)`: Length of the message.
    - `MSG_CONFIRM`: Confirms successful delivery (optional for UDP).
    - `servaddr`: Specifies the server's address and port information.
    - `len`: Size of the server address structure.
- **Output**:
  - Displays `"Message sent to server"` once the message is successfully sent.

---

#### **6. Receive Message from Server**
```c
n = recvfrom(sockfd, (char *)buffer, BUFFER_SIZE, MSG_WAITALL, (struct sockaddr *)&servaddr, &len);
buffer[n] = '\0';
```
- **`recvfrom`**:
  - Receives a message from the server via the socket (`sockfd`).
  - **Parameters**:
    - `sockfd`: The UDP socket.
    - `buffer`: Stores the received message.
    - `BUFFER_SIZE`: Maximum size of the buffer.
    - `MSG_WAITALL`: Blocks until the full message is received.
    - `servaddr`: Specifies the server's address and port information.
    - `len`: Size of the server address structure.
- **Output**:
  - Displays the server's response, e.g., `"Server: Hello, Client!"`.

---

#### **7. Close the Socket**
```c
close(sockfd);
```
- **`close`**:
  - Releases resources associated with the socket after communication is complete.

---

### **Execution Workflow**

#### **1. Compile**
Compile both the client and server programs:
```bash
gcc -o udp_server udp_server.c
gcc -o udp_client udp_client.c
```

#### **2. Run the Server**
Start the server in the first terminal:
```bash
./udp_server
```

#### **3. Run the Client**
Execute the client in a new terminal:
```bash
./udp_client
```

---

### **Sample Output**

**Terminal 1 (Server)**:
```
Server started and waiting for messages...
Message received: Hello from client
Sending response: Hello, Client!
```

**Terminal 2 (Client)**:
```
Message sent to server
Server: Hello, Client!
```

---

### **Networking Concepts**

#### **What is UDP?**
- **User Datagram Protocol (UDP)** is a connectionless protocol, meaning no handshake occurs before data transfer.
- **Key Features**:
  - Faster but less reliable than TCP.
  - Suitable for applications requiring quick delivery (e.g., video streaming).

#### **How UDP Communication Works**
1. **Client**:
   - Sends a message directly to the server without establishing a connection.
   - Waits for the server's response.
2. **Server**:
   - Listens on the specified port for incoming messages.
   - Sends a response to the client after processing the message.

---

### **Applications**
1. **Real-Time Communication**:
   - Used in video conferencing, VoIP, and gaming.
2. **DNS Resolution**:
   - Sends and receives lightweight DNS queries.
3. **Sensor Data Transmission**:
   - Transfers periodic updates in IoT systems.

Let me know if you'd like to explore more about UDP, such as handling multiple clients or implementing a more complex server logic! 😊*/
