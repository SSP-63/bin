
// 44. Write a program in which different processes will perform different operation on shared memory. Operation: create memory, delete, attach/ detach(using shmget, shmat, shmdt).
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>


#define SHM_SIZE 1024 // Size of shared memory segment


int main() {
        key_t key = ftok(".", 'A'); // Generate a unique key
        int shmid; // Shared memory ID
        char *shm_ptr; // Pointer to shared memory


        // Fork a child process to create shared memory
        pid_t pid_create = fork();
        if (pid_create == -1) {
            perror("fork");
            exit(1);
        } else if (pid_create == 0) { // Child process to create memory
            // Create a shared memory segment
            shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
            if (shmid == -1) {
                perror("shmget");
                exit(1);
            }
            printf("Shared memory segment created\n");
            exit(0);
        } else { // Parent process
            wait(NULL); // Wait for the child process to finish creating memory


            // Fork another child process to attach to shared memory
            pid_t pid_attach = fork();
            if (pid_attach == -1) {
                perror("fork");
                exit(1);
            } else if (pid_attach == 0) { // Child process to attach memory
                // Attach the shared memory segment to the process's address space
                shmid = shmget(key, SHM_SIZE, 0666); // Get existing shared memory ID
                if (shmid == -1) {
                    perror("shmget");
                    exit(1);
                }
                shm_ptr = shmat(shmid, NULL, 0);
                if (shm_ptr == (char *) -1) {
                    perror("shmat");
                    exit(1);
                }
                printf("Attached to shared memory segment\n");
                exit(0);
            } else { // Parent process
                wait(NULL); // Wait for the child process to finish attaching memory


                // Fork another child process to detach from shared memory
                pid_t pid_detach = fork();
                if (pid_detach == -1) {
                    perror("fork");
                    exit(1);
                } else if (pid_detach == 0) { // Child process to detach memory
                    // Detach the shared memory segment from the process's address space
                    shmid = shmget(key, SHM_SIZE, 0666); // Get existing shared memory ID
                    if (shmid == -1) {
                        perror("shmget");
                        exit(1);
                    }
                    shm_ptr = shmat(shmid, NULL, 0);
                    if (shm_ptr == (char *) -1) {
                        perror("shmat");
                        exit(1);
                    }
                    if (shmdt(shm_ptr) == -1) {
                        perror("shmdt");
                        exit(1);
                    }
                    printf("Detached from shared memory segment\n");
                    exit(0);
                } else { // Parent process
                    wait(NULL); // Wait for the child process to finish detaching memory


                    // Fork another child process to delete shared memory
                    pid_t pid_delete = fork();
                    if (pid_delete == -1) {
                        perror("fork");
                        exit(1);
                    } else if (pid_delete == 0) { // Child process to delete memory
                        // Remove the shared memory segment
                        shmid = shmget(key, SHM_SIZE, 0666); // Get existing shared memory ID
                        if (shmid == -1) {
                            perror("shmget");
                            exit(1);
                        }
                        if (shmctl(shmid, IPC_RMID, NULL) == -1) {
                            perror("shmctl");
                            exit(1);
                        }
                        printf("Shared memory segment deleted\n");
                        exit(0);
                    } else { // Parent process
                        wait(NULL); // Wait for the child process to finish deleting memory
                    }
                }
            }
        }


        return 0;
}
/*### 📚 **Detailed Explanation of IPC Using Shared Memory**

This program demonstrates **Interprocess Communication (IPC)** using shared memory. Multiple processes carry out different operations on shared memory: creation, attachment, detachment, and deletion. Shared memory allows efficient data sharing between processes.

---

### **Key Concepts of Shared Memory**

#### **What is Shared Memory?**
- Shared memory is a fast IPC mechanism that provides multiple processes with access to a common memory segment.
- It avoids data copying and uses direct memory access, enabling efficient communication.

#### **System Calls for Shared Memory**
1. **`ftok`**:
   - Generates a unique key for identifying shared memory segments.
2. **`shmget`**:
   - Creates a shared memory segment or retrieves an existing one using the key.
3. **`shmat`**:
   - Attaches the shared memory segment to the calling process's address space.
4. **`shmdt`**:
   - Detaches the shared memory segment from the process.
5. **`shmctl`**:
   - Performs control operations, such as deleting the shared memory segment.

---

### **Line-by-Line Code Explanation**

#### **1. Generating a Unique Key (`ftok`)**
```c
key_t key = ftok(".", 'A');
```
- **Purpose**:
  - Generates a unique key based on the file path (`"."`) and a project identifier (`'A'`).
- **Returns**:
  - A unique key used to identify the shared memory segment.

---

#### **2. Creating a Shared Memory Segment (`shmget`)**
```c
shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
```
- **Parameters**:
  - `key`: Unique key generated by `ftok`.
  - `SHM_SIZE`: Size of the shared memory segment (1024 bytes here).
  - `IPC_CREAT | 0666`: Flags to create the segment and set read/write permissions.
- **Returns**:
  - A shared memory identifier (`shmid`).

---

#### **3. Attaching Shared Memory (`shmat`)**
```c
shm_ptr = shmat(shmid, NULL, 0);
```
- **Purpose**:
  - Maps the shared memory segment into the process's address space.
- **Returns**:
  - A pointer to the attached shared memory segment.

---

#### **4. Detaching Shared Memory (`shmdt`)**
```c
shmdt(shm_ptr);
```
- **Purpose**:
  - Removes the mapping between the shared memory segment and the process.

---

#### **5. Removing Shared Memory (`shmctl`)**
```c
shmctl(shmid, IPC_RMID, NULL);
```
- **Purpose**:
  - Deletes the shared memory segment and frees its resources.

---

### **Program Workflow**

#### **Step 1: Creation of Shared Memory**
- **Child Process**:
  - Uses `shmget` with `IPC_CREAT` to create a new shared memory segment.
- **Output**: `Shared memory segment created`.

---

#### **Step 2: Attaching Shared Memory**
- **Second Child Process**:
  - Uses `shmat` to attach the created memory segment to its address space.
- **Output**: `Attached to shared memory segment`.

---

#### **Step 3: Detaching Shared Memory**
- **Third Child Process**:
  - Uses `shmdt` to detach the shared memory segment from its address space.
- **Output**: `Detached from shared memory segment`.

---

#### **Step 4: Deleting Shared Memory**
- **Fourth Child Process**:
  - Uses `shmctl` with `IPC_RMID` to remove the shared memory segment.
- **Output**: `Shared memory segment deleted`.

---

### **Theory and Advantages of Shared Memory**

#### **Advantages**
1. **High Efficiency**:
   - Shared memory avoids the overhead of copying data between processes.
   - Offers faster data sharing compared to pipes or message queues.
2. **Real-Time Communication**:
   - Shared memory enables real-time data sharing, ideal for applications like gaming or sensor data processing.

#### **Challenges**
1. **Synchronization**:
   - Proper synchronization techniques (e.g., semaphores or mutexes) must be used to avoid race conditions.
2. **Resource Management**:
   - Shared memory must be explicitly detached and removed to free resources.

---

### Example Execution

#### **Compilation**:
```bash
gcc 44.c -o 44
```

#### **Execution**:
```bash
./44
```

#### **Output**:
```
Shared memory segment created
Attached to shared memory segment
Detached from shared memory segment
Shared memory segment deleted
```

---

### **Applications**
1. **Data Sharing**:
   - Efficient sharing of large datasets between processes in scientific computations or simulations.
2. **Collaboration**:
   - Processes working on shared data structures, such as collaborative caching or matrix operations.

This code demonstrates the lifecycle of shared memory through creation, attachment, detachment, and deletion by multiple processes. Let me know if you'd like further details on synchronization techniques or expanded functionality! 😊 */
