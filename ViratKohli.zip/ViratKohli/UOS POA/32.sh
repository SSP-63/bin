

# 32. Generate frequency list of all the commands you have used, and show the top 5 commands along with their count. (Hint: history command hist will give you a list of all commands used.)


# Generate frequency list of all the commands you have used, and show the top 5
# commands along with their count. (Hint: history command hist will give you a list of
# all commands used.


# Get the list of all commands from history and count their frequencies
command_freq=$(history | awk '{print $2}' | sort | uniq -c | sort -nr)


# Display the top 5 commands along with their counts
echo "Top 5 commands:"
echo "$command_freq" | head -n 5


# eq.sh': No such file or directory
# omkar@omkar:~/Desktop/UOS POA$ chmod +x 32.sh
# omkar@omkar:~/Desktop/UOS POA$ ./32.sh
:"
### 🔍 **Line-by-Line Code Explanation**

This script analyzes the user's command history and identifies the top 5 most frequently used commands.

---

#### **1. Shebang**
```bash
#!/bin/bash
```
- Ensures the script is executed in the Bash shell.

---

#### **2. Retrieve Command History**
```bash
command_freq=$(history | awk '{print $2}' | sort | uniq -c | sort -nr)
```
- **`history`**:
  - Retrieves the user's command history.
  - Displays the list of previously executed commands, typically with a sequence number.
- **`awk '{print $2}'`**:
  - Extracts the second field (column) from each line of `history`.
  - This column contains the actual command executed (e.g., `ls`, `cd`).
- **`sort`**:
  - Arranges the commands alphabetically.
- **`uniq -c`**:
  - Counts occurrences of each unique command.
  - Output format: `[count] [command]`.
- **`sort -nr`**:
  - Re-sorts the list numerically in descending order of frequency (highest count first).
- **`command_freq`**:
  - Captures the processed output, which is a frequency list of commands.

---

#### **3. Display Top 5 Commands**
```bash
echo "Top 5 commands:"
echo "$command_freq" | head -n 5
```
- **`echo "Top 5 commands:"`**:
  - Prints a header message for clarity.
- **`head -n 5`**:
  - Filters the first 5 lines from the frequency list.
  - Shows the most-used commands along with their counts.

---

### 📚 **Theory Behind Commands**

#### **Command Breakdown**

##### **1. `history`**
- **Purpose**: Lists commands that the user has executed.
- **Default Behavior**: Displays a numbered list with each command used.

##### **2. `awk`**
- **Purpose**: Processes text and extracts specific fields.
- **Syntax**: `awk '{print column_number}'`.
  - Example: Extracts the second column (command) from the history list.
- **Applications**:
  - Used for filtering or formatting text-based data.

##### **3. `sort`**
- **Purpose**: Sorts text or numeric data.
- **Options**:
  - `-n`: Numeric sort.
  - `-r`: Reverse sort (descending order).
  - **Combination** (`-nr`): Sorts numerically in reverse order (highest to lowest).

##### **4. `uniq -c`**
- **Purpose**: Identifies unique lines and counts occurrences.
- **Example Output**:
  ```
  5 ls
  3 cd
  2 cat
  ```

##### **5. `head`**
- **Purpose**: Displays the first few lines of a file or command output.
- **Syntax**: `head -n [number_of_lines]`.
  - Example: `head -n 5` shows the top 5 lines.

#### **Applications**
- **System Diagnostics**: Understand frequently used commands for optimization.
- **Automation**: Track usage patterns for automating repetitive tasks.

---

### Example Execution

#### Input:
Run the script:
```bash
chmod +x 32.sh
./32.sh
```

#### Output:
```
Top 5 commands:
15 ls
10 cd
8 cat
6 grep
5 history
```

This script provides insight into command usage patterns efficiently. Let me know if you'd like enhancements, such as filtering commands by specific time periods or users! 😊
'
