
// 46. Write a program to ensure that function f1 should executed before executing function f2
// using semaphore. (Ex. Program should ask for username before entering password).


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>


// Define semaphore
sem_t semaphore;


void f1() {
        printf("Enter username: ");
        char username[100];
        scanf("%s", username);
        // Simulate processing username
        printf("Processing username: %s\n", username);
}


void f2() {
        printf("Enter password: ");
        char password[100];
        scanf("%s", password);
        // Simulate processing password
        printf("Processing password: %s\n", password);
}        


void *thread_function(void *arg) {
        // Wait for semaphore
        sem_wait(&semaphore);
        f1();
        // Post semaphore
        sem_post(&semaphore);
        f2();
        return NULL;
}


int main() {
        // Initialize semaphore
        sem_init(&semaphore, 0, 1);


        pthread_t thread;
        // Create a thread
        if (pthread_create(&thread, NULL, thread_function, NULL)) {
            fprintf(stderr, "Error creating thread\n");
            return 1;
        }


        // Join the thread
        if (pthread_join(thread, NULL)) {
            fprintf(stderr, "Error joining thread\n");
            return 1;
        }


        // Destroy semaphore
        sem_destroy(&semaphore);


        return 0;
}

/* ### **Program to Ensure Function Order Using Semaphore**

This program ensures that `f1()` executes before `f2()` by leveraging semaphores to control synchronization in a multi-threaded environment. Below is an in-depth breakdown of the code and associated concepts:

---

### **Key Concepts in the Program**

#### **1. What is a Semaphore?**
- A **semaphore** is a synchronization primitive used to control access to shared resources in a multi-threaded or multi-process environment.
- It acts as a counter:
  - **`sem_wait()`**: Decreases the semaphore value. If the value is `0`, it blocks until the semaphore is available.
  - **`sem_post()`**: Increases the semaphore value and unblocks waiting threads.

#### **2. Thread Synchronization**
- Threads share resources, such as functions, and synchronization is necessary to ensure that certain operations occur in a specific order.
- In this case:
  - The semaphore ensures that `f1()` (entering the username) is executed before `f2()` (entering the password).

#### **3. Program Goals**
- Thread-safe execution of `f1()` before `f2()`.
- Controlled access using semaphores.

---

### **Line-by-Line Code Explanation**

#### **1. Include Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
```
- **`<pthread.h>`**: Provides threading APIs for creating and managing threads.
- **`<semaphore.h>`**: Provides APIs for semaphore operations (`sem_init`, `sem_wait`, `sem_post`, etc.).

---

#### **2. Defining the Semaphore**
```c
sem_t semaphore;
```
- Declares a semaphore variable named `semaphore`.

---

#### **3. Function `f1`**
```c
void f1() {
    printf("Enter username: ");
    char username[100];
    scanf("%s", username);
    printf("Processing username: %s\n", username);
}
```
- **Purpose**: Reads and processes the username input.
- **Execution Order**: Always runs before `f2()`.

---

#### **4. Function `f2`**
```c
void f2() {
    printf("Enter password: ");
    char password[100];
    scanf("%s", password);
    printf("Processing password: %s\n", password);
}
```
- **Purpose**: Reads and processes the password input.
- **Execution Order**: Always runs after `f1()` due to the semaphore.

---

#### **5. Thread Function**
```c
void *thread_function(void *arg) {
    sem_wait(&semaphore); // Wait until semaphore value is > 0
    f1();                 // Execute f1() (username input)
    sem_post(&semaphore); // Release semaphore for next operation
    f2();                 // Execute f2() (password input)
    return NULL;
}
```
- **`sem_wait(&semaphore)`**:
  - Decreases the semaphore value and blocks if it's `0`, ensuring `f1()` runs before `f2()`.
- **`sem_post(&semaphore)`**:
  - Increases the semaphore value, allowing `f2()` to execute.

---

#### **6. Semaphore Initialization**
```c
sem_init(&semaphore, 0, 1);
```
- **Parameters**:
  - `&semaphore`: Pointer to the semaphore variable.
  - `0`: Semaphore is shared between threads in the same process.
  - `1`: Initial semaphore value (unlocked).

---

#### **7. Thread Creation**
```c
pthread_t thread;
if (pthread_create(&thread, NULL, thread_function, NULL)) {
    fprintf(stderr, "Error creating thread\n");
    return 1;
}
```
- Creates a thread and assigns the `thread_function` for execution.

---

#### **8. Thread Joining**
```c
if (pthread_join(thread, NULL)) {
    fprintf(stderr, "Error joining thread\n");
    return 1;
}
```
- Waits for the thread to complete before the main process continues.

---

#### **9. Destroying the Semaphore**
```c
sem_destroy(&semaphore);
```
- Releases resources allocated to the semaphore.

---

### **Program Workflow**

1. **Initialization**:
   - A semaphore is initialized with a value of `1`.

2. **Thread Execution**:
   - The thread executes `thread_function`.
   - `sem_wait` blocks the execution of `f2()` until `f1()` completes.

3. **Resource Management**:
   - The semaphore is destroyed after thread execution.

---

### **Key Advantages of Semaphores**

1. **Order Enforcement**:
   - Ensures specific functions execute in a particular sequence.

2. **Thread-Safe**:
   - Prevents race conditions when accessing shared resources.

3. **Efficiency**:
   - Lightweight synchronization mechanism with minimal overhead.

---

### **Example Execution**

#### Compile and Run:
```bash
gcc semaphore_function_order.c -o semaphore_function_order -lpthread
./semaphore_function_order
```

#### Sample Input:
```
Enter username: alice
Processing username: alice
Enter password: secret123
Processing password: secret123
```

#### Output:
```
Enter username: alice
Processing username: alice
Enter password: secret123
Processing password: secret123
```

---

### **Applications**
1. **Login Systems**:
   - Enforce a sequence where users enter their username before the password.
2. **Concurrent Systems**:
   - Manage dependencies between threads.
3. **Resource Access**:
   - Synchronize access to shared resources (e.g., files, databases).

Let me know if you'd like to explore additional synchronization techniques or expand this program! 😊*/
