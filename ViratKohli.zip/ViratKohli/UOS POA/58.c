
// 58. Write a program using FIFO, to Send file from parent to child over a pipe. (named pipe)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#define FIFO_PATH "/tmp/myfifo"
#define BUFFER_SIZE 1024


int main() {
        int fd; // File descriptor for the FIFO
        pid_t pid; // Process ID


        char buffer[BUFFER_SIZE]; // Buffer for reading from and writing to the FIFO


        // Create the FIFO
        mkfifo(FIFO_PATH, 0666);


        // Fork a child process
        pid = fork();


        if (pid < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        }


        if (pid > 0) { // Parent process
            printf("Parent: Opening file for reading...\n");
            FILE *file = fopen("input.txt", "r");
            if (file == NULL) {
                perror("fopen");
                exit(EXIT_FAILURE);
            }


            printf("Parent: Opening FIFO for writing...\n");
            // Open the FIFO for writing
            fd = open(FIFO_PATH, O_WRONLY);
            if (fd == -1) {
                perror("open");
                exit(EXIT_FAILURE);
            }


            printf("Parent: Writing file data to the FIFO...\n");
            ssize_t bytes_read;
            while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
                write(fd, buffer, bytes_read);
            }
            close(fd); // Close the FIFO
            fclose(file);
            printf("Parent: File data written to the FIFO.\n");
        } else { // Child process
            printf("Child: Opening FIFO for reading...\n");
            // Open the FIFO for reading
            fd = open(FIFO_PATH, O_RDONLY);
            if (fd == -1) {
                perror("open");
                exit(EXIT_FAILURE);
            }


            printf("Child: Creating file for writing...\n");
            FILE *output_file = fopen("output.txt", "w");
            if (output_file == NULL) {
                perror("fopen");
                exit(EXIT_FAILURE);
            }


            printf("Child: Reading data from the FIFO...\n");
            ssize_t bytes_read;
            while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
                fwrite(buffer, 1, bytes_read, output_file);
            }
            fclose(output_file);
            printf("Child: Data written to output.txt.\n");


            close(fd); // Close the FIFO
        }


        return 0;
}
/* ### **Program Explanation: Sending File Data from Parent to Child Using a Named Pipe (FIFO)**

This program demonstrates **Interprocess Communication (IPC)** using a **named pipe (FIFO)** to transfer the contents of a file (`input.txt`) from a **parent process** to a **child process**, with the child saving the data in another file (`output.txt`). Below is a comprehensive breakdown:

---

### **Concept: Named Pipes (FIFO)**

#### **What is a FIFO?**
1. **Definition**:
   - A **FIFO** is a special type of file (also called a named pipe) used for one-way communication between processes.
   - Unlike unnamed pipes, FIFOs are identified by a pathname in the filesystem.
2. **Key Features**:
   - Data flows in **first-in-first-out** order.
   - Allows **communication between unrelated processes**.
   - FIFOs persist in the filesystem until explicitly removed.

#### **Creating and Using a FIFO**
1. **Creation**:
   - `mkfifo(pathname, permissions)` creates a FIFO special file.
2. **Usage**:
   - Processes open the FIFO for reading (`O_RDONLY`) or writing (`O_WRONLY`).
   - FIFOs block:
     - The writer blocks until a reader is available.
     - The reader blocks until data is written.

---

### **Detailed Code Explanation**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
```
- **`stdio.h`**: Provides functions like `fopen`, `printf`, and `fread`.
- **`stdlib.h`**: Includes functions for memory management and process termination (`exit`).
- **`unistd.h`**: Provides pipe-related functions like `fork` and file descriptor operations (`read`, `write`).
- **`sys/stat.h`**: Used for creating FIFOs (`mkfifo`).
- **`fcntl.h`**: Defines file access modes like `O_RDONLY` and `O_WRONLY`.

---

#### **2. Define Constants**
```c
#define FIFO_PATH "/tmp/myfifo"
#define BUFFER_SIZE 1024
```
- **`FIFO_PATH`**: The pathname for the FIFO is set to `/tmp/myfifo`.
- **`BUFFER_SIZE`**: Defines the size of the buffer used for reading and writing data.

---

#### **3. Create the FIFO**
```c
mkfifo(FIFO_PATH, 0666);
```
- **`mkfifo`**:
  - Creates the FIFO file at the specified `FIFO_PATH`.
  - **Permissions**: `0666` grants read/write access to all users.
- **Persistence**:
  - The FIFO remains in the filesystem until deleted manually or programmatically.

---

#### **4. Fork the Process**
```c
pid = fork();
```
- **`fork()`**:
  - Splits the program into two processes: **parent** and **child**.
  - Returns:
    - `0` for the child process.
    - The child's PID for the parent process.
    - A negative value if the fork fails.

---

#### **5. Parent Process: Writing to FIFO**
```c
if (pid > 0) {
    FILE *file = fopen("input.txt", "r");
    fd = open(FIFO_PATH, O_WRONLY);
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        write(fd, buffer, bytes_read);
    }
    close(fd);
    fclose(file);
}
```
- **Steps**:
  1. **Open the input file**:
     - Reads the contents of `input.txt` using `fopen`.
  2. **Open FIFO for writing**:
     - The parent process opens the FIFO in `O_WRONLY` mode.
     - If no process is reading from the FIFO, `open` blocks.
  3. **Write file data to FIFO**:
     - Reads chunks of data from `input.txt` using `fread`.
     - Writes the data to the FIFO using `write`.
  4. **Close resources**:
     - Closes the FIFO and the input file.

---

#### **6. Child Process: Reading from FIFO**
```c
else if (pid == 0) {
    fd = open(FIFO_PATH, O_RDONLY);
    FILE *output_file = fopen("output.txt", "w");
    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
        fwrite(buffer, 1, bytes_read, output_file);
    }
    fclose(output_file);
    close(fd);
}
```
- **Steps**:
  1. **Open FIFO for reading**:
     - The child process opens the FIFO in `O_RDONLY` mode.
     - If no process is writing to the FIFO, `open` blocks.
  2. **Open the output file**:
     - Creates a new file `output.txt` using `fopen` in write mode.
  3. **Read data from FIFO**:
     - Reads chunks of data from the FIFO using `read`.
     - Writes the data into `output.txt` using `fwrite`.
  4. **Close resources**:
     - Closes the FIFO and the output file.

---

#### **Error Handling**
```c
if (fopen(...) == NULL || open(...) == -1) {
    perror("Error Message");
    exit(EXIT_FAILURE);
}
```
- Ensures that file operations succeed.
- Prints an error message and terminates the program if a file cannot be opened.

---

### **Execution Workflow**

1. **Parent Process**:
   - Reads data from `input.txt`.
   - Sends the data through the FIFO to the child process.

2. **Child Process**:
   - Reads data from the FIFO.
   - Writes the data into `output.txt`.

3. **Resource Cleanup**:
   - Both processes close the FIFO and their respective files.
   - The FIFO (`/tmp/myfifo`) remains in the filesystem and can be removed manually.

---

### **Compiling and Running the Program**

#### **1. Compile the Program**
```bash
gcc named_pipe_file_transfer.c -o named_pipe_file_transfer
```

#### **2. Create an Input File**
Create a file named `input.txt` and populate it with some text.

#### **3. Execute the Program**
```bash
./named_pipe_file_transfer
```

#### **4. Verify the Output**
Check the contents of `output.txt` to confirm the data transfer.

---

### **Sample Output**

**Terminal**:
```
Parent: Opening file for reading...
Parent: Opening FIFO for writing...
Parent: Writing file data to the FIFO...
Parent: File data written to the FIFO.
Child: Opening FIFO for reading...
Child: Creating file for writing...
Child: Reading data from the FIFO...
Child: Data written to output.txt.
```

**Contents of `output.txt`**:
```
(Contents of input.txt are copied into output.txt)
```

---

### **Theory Behind FIFOs**

#### **Advantages**
1. **Persistent Communication**:
   - FIFOs exist as named files and can facilitate communication between unrelated processes.
2. **Simplicity**:
   - Easy to implement using standard file operations.

#### **Limitations**
1. **Unidirectional**:
   - Data flows in only one direction. For bi-directional communication, two FIFOs are needed.
2. **Blocking Behavior**:
   - `open`, `read`, or `write` calls block until a corresponding operation is performed by another process.

---

### **Applications**
1. **File Transfer**:
   - Pass files between processes using FIFOs.
2. **Log Systems**:
   - Stream logs from one process to another in real-time.
3. **Client-Server Communication**:
   - Enable communication between servers and clients via FIFOs.

This implementation showcases a simple file transfer using FIFOs. Let me know if you'd like to enhance the program to handle larger files or add advanced IPC techniques! 😊*/
