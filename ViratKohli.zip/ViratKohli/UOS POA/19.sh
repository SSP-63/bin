# 19. Write a program to implement digital clock using shell script.
#!/bin/bash


while true; do
        clear
        date +"%H:%M:%S"
        sleep 1
done
:'
### 🔍 **Line-by-Line Explanation**
This shell script creates a simple digital clock that displays the current time, updating every second.

---

#### **1. Shebang (`#!/bin/bash`)**
- Indicates the script should be executed using the Bash shell.
- Ensures compatibility across systems with Bash.

---

#### **2. `while true` Loop**
```bash
while true; do
```
- **Infinite Loop**: Keeps the clock running indefinitely until manually stopped (e.g., via `Ctrl+C`).
- **`true`**: An always-true condition ensures the loop doesn’t exit.

---

#### **3. Clearing the Screen**
```bash
clear
```
- **`clear`**: Clears the terminal screen to refresh the display for the next update.
- Creates an illusion of the digital clock updating smoothly.

---

#### **4. Displaying Time**
```bash
date +"%H:%M:%S"
```
- **`date`**: Prints the current date and time.
- **`%H:%M:%S`**: Formatting:
  - `%H`: Hours (24-hour format).
  - `%M`: Minutes.
  - `%S`: Seconds.
- Displays time in the format `HH:MM:SS`.

---

#### **5. Adding a Delay**
```bash
sleep 1
```
- **`sleep 1`**: Pauses execution for 1 second between each iteration, creating the live clock effect.

---

#### **6. Closing the Loop**
```bash
done
```
- Marks the end of the `while` loop.

---

### 📚 **Related Theory**

#### **Shell Scripting Basics**
- **Shell Scripts**: Automate repetitive tasks by executing commands in sequence.
- **Infinite Loops**: Useful for continuously running tasks, like a digital clock.

#### **`date` Command**
- **Purpose**: Displays system date and time.
- **Formatting Options**:
  - `%H`, `%M`, `%S`: Hour, minute, second.
  - `%I`: Hours in 12-hour format.
  - `%p`: AM/PM marker.
- Example: `date +"%H:%M:%S"` outputs time in `HH:MM:SS` format.

#### **`clear` Command**
- **Purpose**: Refreshes the terminal screen by clearing the previous content.
- Ensures only the latest time is visible on the screen.

#### **`sleep` Command**
- **Purpose**: Introduces a delay in execution.
- Syntax: `sleep [seconds]`.
- Example: `sleep 1` pauses the script for 1 second.

#### **Interrupting Infinite Loops**
- Use `Ctrl+C` to terminate the script manually when desired.

#### **Applications**
- **Digital Clocks**: Live display of current time.
- **Live Updates**: Can be adapted for monitoring real-time system data.

---

This script is a simple yet effective example of real-time display programming in Bash. It highlights key scripting concepts like loops, commands, and formatting. Let me know if you'd like to discuss enhancements or explore related applications! 😊

'
