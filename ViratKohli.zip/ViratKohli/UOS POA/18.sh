
# 18. Write a program to implement shell script for calculator
#!/bin/bash


echo "Calculator"


echo "Enter first number:"
read num1


echo "Enter second number:"
read num2


echo "Choose operation:"
echo "1. Addition"
echo "2. Subtraction"
echo "3. Multiplication"
echo "4. Division"
read choice


case $choice in
        1)
            result=$(echo "$num1 + $num2" | bc)
            echo "Result: $result"
            ;;
        2)
            result=$(echo "$num1 - $num2" | bc)
            echo "Result: $result"
            ;;
        3)
            result=$(echo "$num1 * $num2" | bc)
            echo "Result: $result"
            ;;
        4)
            if [ $num2 -eq 0 ]; then
                echo "Error: Division by zero"
            else
                result=$(echo "scale=2; $num1 / $num2" | bc)
                echo "Result: $result"
            fi
            ;;
        *)
            echo "Invalid choice"
            ;;
esac

# chmod +x 18.sh
# ./18.sh

:'
### 🌟 **Line-by-Line Code Explanation**
This shell script implements a simple calculator for basic arithmetic operations (addition, subtraction, multiplication, division). Here's the detailed breakdown:

---

#### **1. User-Friendly Welcome**
```bash
echo "Calculator"
```
Prints "Calculator" to greet the user.

---

#### **2. Taking Inputs**
```bash
echo "Enter first number:"
read num1
echo "Enter second number:"
read num2
```
- **`echo`**: Prompts the user to input numbers for calculation.
- **`read`**: Reads the user input and assigns it to the variable `num1` (first number) and `num2` (second number).

---

#### **3. Displaying Operations Menu**
```bash
echo "Choose operation:"
echo "1. Addition"
echo "2. Subtraction"
echo "3. Multiplication"
echo "4. Division"
read choice
```
- **Menu Options**: Lists the operations available (Addition, Subtraction, Multiplication, Division).
- **`read choice`**: Captures the user's choice (1, 2, 3, or 4) into the variable `choice`.

---

#### **4. Handling User Choice with `case`**
```bash
case $choice in
```
- **`case`**: A conditional control structure used for branching based on `choice`.

---

#### **5. Arithmetic Operations**
Each operation is performed using the **`bc`** command-line calculator, which processes mathematical expressions.

##### Addition
```bash
result=$(echo "$num1 + $num2" | bc)
echo "Result: $result"
```
- **`echo "$num1 + $num2"`**: Forms an addition expression (e.g., `5 + 3`).
- **`| bc`**: Pipes the expression into `bc` for calculation.
- **`result`**: Stores the output of the calculation.

##### Subtraction
```bash
result=$(echo "$num1 - $num2" | bc)
echo "Result: $result"
```
Similar to addition, subtracts `num2` from `num1`.

##### Multiplication
```bash
result=$(echo "$num1 * $num2" | bc)
echo "Result: $result"
```
Multiplies `num1` by `num2`.

##### Division
```bash
if [ $num2 -eq 0 ]; then
    echo "Error: Division by zero"
else
    result=$(echo "scale=2; $num1 / $num2" | bc)
    echo "Result: $result"
fi
```
- **Division by Zero Check (`if [ $num2 -eq 0 ]`)**: Verifies that the denominator (`num2`) is not zero, as division by zero is undefined.
- **`scale=2`**: Sets precision for the division result (e.g., 2 decimal places).

---

#### **6. Invalid Choice Handling**
```bash
*)
echo "Invalid choice"
;;
```
- Handles any input that doesn't match the available choices (1 to 4).
- **`*)`**: Wildcard pattern matching for invalid input.

---

#### **7. End of `case`**
```bash
esac
```
Marks the end of the `case` statement.

---

### 📚 **Theory Related to Concepts**

#### **Shell Scripting Basics**
- **Shell**: Command-line interpreter used to execute scripts.
- **Scripts**: Automate tasks like calculations or file operations in Unix/Linux.

#### **Variables**
- **Dynamic Typing**: Shell variables don't require explicit data type definitions.
- Example: `num1` holds numeric input without requiring declaration.

#### **`read` Command**
- Reads input from standard input and assigns it to a variable.
- Example: `read num1` waits for the user to enter a number.

#### **Arithmetic in Shell**
- **`bc` (Basic Calculator)**:
  - Command-line calculator for mathematical expressions.
  - Supports floating-point arithmetic when using `scale` to set precision.

#### **Control Structures**
- **`case`**: Selects an operation based on user input, simplifying branching.
- **`if`**: Checks logical conditions (e.g., division by zero) to ensure proper execution.

#### **Error Handling**
- **Division by Zero**:
  - Critical in programming; handled gracefully in this script to prevent undefined behavior.

#### **Piping (`|`)**
- Redirects output of one command (e.g., `echo`) as input for another command (e.g., `bc`).

#### **Input Validation**
- The script uses conditionals (`case` and `if`) to validate user input and handle errors effectively.

---

This script showcases foundational scripting skills and user-interactive programming concepts. Let me know if you'd like further clarification or enhancements! 😊

'
