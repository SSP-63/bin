
// 13. Write a program to give statistics of a given file using fstat system call. (few imp field like FAP, file type)
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <unistd.h> // Include for close function


int main(int argc, char *argv[]) {
        if (argc != 2) {
            fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
            exit(EXIT_FAILURE);
        }


        struct stat fileStat;
        int fd;


        fd = open(argv[1], O_RDONLY);
        if (fd == -1) {
            perror("open");
            exit(EXIT_FAILURE);
        }


        if (fstat(fd, &fileStat) == -1) {
            perror("fstat");
            exit(EXIT_FAILURE);
        }


        printf("File: %s\n", argv[1]);
        printf("Size: %ld bytes\n", fileStat.st_size);
        printf("File Permissions: ");
        printf((S_ISDIR(fileStat.st_mode)) ? "d" : "-");
        printf((fileStat.st_mode & S_IRUSR) ? "r" : "-");
        printf((fileStat.st_mode & S_IWUSR) ? "w" : "-");
        printf((fileStat.st_mode & S_IXUSR) ? "x" : "-");
        printf((fileStat.st_mode & S_IRGRP) ? "r" : "-");
        printf((fileStat.st_mode & S_IWGRP) ? "w" : "-");
        printf((fileStat.st_mode & S_IXGRP) ? "x" : "-");
        printf((fileStat.st_mode & S_IROTH) ? "r" : "-");
        printf((fileStat.st_mode & S_IWOTH) ? "w" : "-");
        printf((fileStat.st_mode & S_IXOTH) ? "x\n" : "-\n");


        printf("File Type: ");
        switch (fileStat.st_mode & S_IFMT) {
            case S_IFREG:
                printf("Regular File\n");
                break;
            case S_IFDIR:
                printf("Directory\n");
                break;
            case S_IFLNK:
                printf("Symbolic Link\n");
                break;
            case S_IFBLK:
                printf("Block Device\n");
                break;
            case S_IFCHR:
                printf("Character Device\n");
                break;
            case S_IFIFO:
                printf("FIFO/Named Pipe\n");
                break;
            case S_IFSOCK:
                printf("Socket\n");
                break;
            default:
                printf("Unknown\n");
        }


        printf("Inode Number: %ld\n", fileStat.st_ino);
        printf("Number of Hard Links: %ld\n", fileStat.st_nlink);


        struct passwd *pwd = getpwuid(fileStat.st_uid);
        printf("Owner User ID: %d (%s)\n", fileStat.st_uid, pwd ? pwd->pw_name : "Unknown");


        struct group *grp = getgrgid(fileStat.st_gid);
        printf("Owner Group ID: %d (%s)\n", fileStat.st_gid, grp ? grp->gr_name : "Unknown");


        printf("Last Access Time: %s", ctime(&fileStat.st_atime));
        printf("Last Modification Time: %s", ctime(&fileStat.st_mtime));
        printf("Last Status Change Time: %s", ctime(&fileStat.st_ctime));


        close(fd);


        return 0;
}
//./13 filename.whatever
//./13 1.c

/*  🧠 Detailed Line-by-Line Explanation:
#include <stdio.h>

Includes the standard input/output library for functions like printf, fprintf, etc.

#include <stdlib.h>

Includes functions like exit() for exiting the program with a status code.

#include <sys/stat.h>

Provides the definition of struct stat and file mode constants used to get file metadata.

#include <fcntl.h>

Includes file control options like O_RDONLY used in open() system call.

#include <errno.h>

Provides access to the errno variable which holds error codes set by system calls.

#include <time.h>

For time-related structures and functions like ctime() to format timestamps.

#include <pwd.h>

Used for getting user information (owner username) from UID via getpwuid().

#include <grp.h>

Used for getting group information (group name) from GID via getgrgid().

#include <unistd.h>

Provides access to POSIX API including close() function.

int main(int argc, char *argv[])

Entry point of the program; argc holds the number of arguments, argv holds argument values.

if (argc != 2)

Checks if exactly one argument (filename) is provided.

fprintf(stderr, "Usage: %s <filename>\n", argv[0]); exit(EXIT_FAILURE);

Prints usage instructions to standard error and exits if incorrect arguments are given.

struct stat fileStat; int fd;

Declares a stat structure to store file info and an integer fd for the file descriptor.

fd = open(argv[1], O_RDONLY);

Opens the file provided as an argument in read-only mode.

if (fd == -1)

Checks if open() failed. If yes, prints the error and exits.

if (fstat(fd, &fileStat) == -1)

Retrieves the file status information using the file descriptor fd.

printf("File: %s\n", argv[1]);

Displays the filename.

printf("Size: %ld bytes\n", fileStat.st_size);

Displays the size of the file in bytes.

printf("File Permissions: ");

Begins displaying file permissions.

Several printf() calls with conditions (fileStat.st_mode & Permission_Macro)

Check and print each permission (rwx) for user, group, and others.

printf("File Type: ");

Begins printing the file type.

switch (fileStat.st_mode & S_IFMT)

Identifies file type (Regular, Directory, Link, etc.) based on mode bits.

printf("Inode Number: %ld\n", fileStat.st_ino);

Displays the inode number.

printf("Number of Hard Links: %ld\n", fileStat.st_nlink);

Displays how many hard links point to this file.

struct passwd *pwd = getpwuid(fileStat.st_uid);

Retrieves user account information corresponding to the file's UID.

printf("Owner User ID: %d (%s)\n", fileStat.st_uid, pwd ? pwd->pw_name : "Unknown");

Prints the file owner's user ID and username.

struct group *grp = getgrgid(fileStat.st_gid);

Retrieves group account information corresponding to the file's GID.

printf("Owner Group ID: %d (%s)\n", fileStat.st_gid, grp ? grp->gr_name : "Unknown");

Prints the file owner's group ID and group name.

printf("Last Access Time: %s", ctime(&fileStat.st_atime));

Displays last access time in human-readable format.

printf("Last Modification Time: %s", ctime(&fileStat.st_mtime));

Displays last modification time.

printf("Last Status Change Time: %s", ctime(&fileStat.st_ctime));

Displays last metadata status change time.

close(fd);

Closes the opened file descriptor to free system resources.

return 0;

Returns success status to the operating system.

📚 Full Related Theory:
open()
open(const char *pathname, int flags) is a system call that opens a file and returns a file descriptor (integer).

Common flag used: O_RDONLY (open for reading only).

On failure, it returns -1 and sets errno.

fstat()
fstat(int fd, struct stat *buf) gets file metadata using an open file descriptor instead of the file path.

Safer for already opened files.

struct stat
A structure defined in <sys/stat.h> containing file metadata:

st_mode: File type and permissions.

st_size: File size in bytes.

st_ino: Inode number.

st_nlink: Number of hard links.

st_uid, st_gid: Owner user ID and group ID.

st_atime, st_mtime, st_ctime: Timestamps.

ctime()
Converts a time_t value into a readable string representing local time.

getpwuid(), getgrgid()
Translate user ID to username, and group ID to group name respectively.

close()
Closes an open file descriptor, releasing system resources.

Important to avoid "file descriptor leak" issues. */
