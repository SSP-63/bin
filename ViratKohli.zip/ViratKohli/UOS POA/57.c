
// 57. Write a program using PIPE, to Send file from parent to child over a pipe.
// (unnamed pipe )
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#define BUFFER_SIZE 1024


int main() {
        int pipefd[2]; // File descriptors for the pipe
        pid_t pid; // Process ID


        char buffer[BUFFER_SIZE]; // Buffer for reading from and writing to the pipe


        // Create the pipe
        if (pipe(pipefd) == -1) {
            perror("pipe");
            exit(EXIT_FAILURE);
        }


        // Fork a child process
        pid = fork();


        if (pid < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        }


        if (pid > 0) { // Parent process
            close(pipefd[0]); // Close the reading end of the pipe in the parent


            printf("Parent: Reading file...\n");
            FILE *file = fopen("sample.txt", "r");
            if (file == NULL) {
                perror("fopen");
                exit(EXIT_FAILURE);
            }


            printf("Parent: Writing file data to the pipe...\n");
            ssize_t bytes_read;
            while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
                write(pipefd[1], buffer, bytes_read);
            }
            close(pipefd[1]); // Close the writing end of the pipe in the parent
            fclose(file);
            printf("Parent: File data written to the pipe.\n");
        } else { // Child process
            close(pipefd[1]); // Close the writing end of the pipe in the child


            printf("Child: Reading data from the pipe...\n");
            FILE *output_file = fopen("output.txt", "w");
            if (output_file == NULL) {
                perror("fopen");
                exit(EXIT_FAILURE);
            }


            ssize_t bytes_read;
            while ((bytes_read = read(pipefd[0], buffer, sizeof(buffer))) > 0) {
                fwrite(buffer, 1, bytes_read, output_file);
            }
            fclose(output_file);
            printf("Child: Data written to output.txt.\n");


            close(pipefd[0]); // Close the reading end of the pipe in the child
        }


        return 0;
}

/* ### **Program Explanation: Sending File Data from Parent to Child Using Unnamed Pipes**

This program demonstrates **Interprocess Communication (IPC)** using unnamed pipes to transfer file data from a **parent process** to a **child process**. Below is a comprehensive explanation of the code:

---

### **What Are Pipes?**
Pipes are a unidirectional communication mechanism that connects two processes (typically parent and child). Unnamed pipes are temporary and exist only during the lifetime of the processes using them.

---

### **Code Breakdown**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
```
- **`stdio.h`**: Provides file operations (`fopen`, `printf`, etc.).
- **`stdlib.h`**: Includes functions like `exit`.
- **`unistd.h`**: Provides pipe (`pipe`), process (`fork`), and file descriptor operations.

---

#### **2. Define Buffer Size**
```c
#define BUFFER_SIZE 1024
```
- Sets the size of the buffer used for reading and writing file data.

---

#### **3. Declare Pipe and Process Variables**
```c
int pipefd[2];
pid_t pid;
char buffer[BUFFER_SIZE];
```
- **`pipefd[2]`**:
  - Array for file descriptors:
    - `pipefd[0]`: Reading end of the pipe.
    - `pipefd[1]`: Writing end of the pipe.
- **`pid`**:
  - Stores the process ID after `fork`.
- **`buffer`**:
  - Temporarily stores chunks of data read from the file.

---

#### **4. Create the Pipe**
```c
if (pipe(pipefd) == -1) {
    perror("pipe");
    exit(EXIT_FAILURE);
}
```
- **`pipe(pipefd)`**:
  - Initializes a unidirectional communication channel.
  - Returns `0` on success and `-1` on failure.
- **Error Handling**:
  - Prints an error and exits if pipe creation fails.

---

#### **5. Fork the Process**
```c
pid = fork();
```
- **`fork()`**:
  - Creates a new child process.
  - Returns:
    - `0` for the child process.
    - Positive value (child's PID) for the parent process.
    - `-1` on failure.
- **Error Handling**:
  - Prints an error and exits if fork fails.

---

#### **6. Parent Process Logic**
```c
if (pid > 0) {
    close(pipefd[0]);
    FILE *file = fopen("sample.txt", "r");
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        write(pipefd[1], buffer, bytes_read);
    }
    close(pipefd[1]);
    fclose(file);
}
```
- **Steps**:
  1. **Close the reading end**:
     - The parent only writes, so the reading end (`pipefd[0]`) is closed.
  2. **Open the file**:
     - Opens `sample.txt` in read mode.
  3. **Write data**:
     - Reads data from the file into `buffer` using `fread`.
     - Sends the data through the pipe using `write`.
  4. **Close resources**:
     - Closes the writing end of the pipe and the file.

---

#### **7. Child Process Logic**
```c
else if (pid == 0) {
    close(pipefd[1]);
    FILE *output_file = fopen("output.txt", "w");
    while ((bytes_read = read(pipefd[0], buffer, sizeof(buffer))) > 0) {
        fwrite(buffer, 1, bytes_read, output_file);
    }
    fclose(output_file);
    close(pipefd[0]);
}
```
- **Steps**:
  1. **Close the writing end**:
     - The child only reads, so the writing end (`pipefd[1]`) is closed.
  2. **Open the output file**:
     - Opens `output.txt` in write mode.
  3. **Read data**:
     - Retrieves data sent by the parent from the pipe using `read`.
     - Writes the received data to `output.txt` using `fwrite`.
  4. **Close resources**:
     - Closes the reading end of the pipe and the output file.

---

#### **Error Handling**
```c
if (fopen(...) == NULL) {
    perror("fopen");
    exit(EXIT_FAILURE);
}
```
- Ensures that file operations succeed. If file opening fails, prints an error message and exits.

---

### **Workflow**

1. **Parent Process**:
   - Opens `sample.txt`.
   - Reads its content and writes it to the pipe.
   - Closes the pipe and the file.

2. **Child Process**:
   - Reads data from the pipe.
   - Writes the data into `output.txt`.
   - Closes the pipe and the file.

---

### **Compiling and Running the Program**

#### **1. Compilation**
```bash
gcc unnamed_pipe_file_transfer.c -o unnamed_pipe_file_transfer
```

#### **2. Execution**
```bash
./unnamed_pipe_file_transfer
```

---

### **Sample Output**
**Terminal Output**:
```
Parent: Reading file...
Parent: Writing file data to the pipe...
Parent: File data written to the pipe.
Child: Reading data from the pipe...
Child: Data written to output.txt.
```

**Contents of `output.txt`**:
```
(Contents of sample.txt are copied into output.txt)
```

---

### **Theory Behind Unnamed Pipes**

#### **Pipe Characteristics**
1. **Unidirectional**:
   - Data flows in one direction: parent writes, and child reads.
2. **Temporary**:
   - Exists only while the processes are active.

#### **Data Transfer**
- **`write`**:
  - Parent writes data to the pipe.
- **`read`**:
  - Child reads data from the pipe.

---

#### **Advantages**
1. **Efficient IPC**:
   - Uses direct memory access for fast data sharing.
2. **Simple Implementation**:
   - Suitable for communication between parent and child processes.

#### **Limitations**
1. **Unidirectional**:
   - For bi-directional communication, two pipes are required.
2. **Parent-Child Relationship**:
   - Only related processes can use unnamed pipes.

---

### **Applications**
1. **File Sharing**:
   - Transfer file data between processes.
2. **Data Streaming**:
   - Send real-time data from one process to another.
3. **Logging Systems**:
   - Transfer logs or output data for storage.

Let me know if you'd like additional enhancements, such as handling larger files or debugging techniques! 😊*/
