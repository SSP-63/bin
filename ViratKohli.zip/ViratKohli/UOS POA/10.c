
// 10. Write a program to use alarm and signal sytem call(check i/p from user within time)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>


// Global variable to track whether the alarm has gone off
volatile sig_atomic_t alarm_triggered = 0;


// Signal handler function for SIGALRM
void alarm_handler(int signum) {
        alarm_triggered = 1;
}


int main() {
        char input[100];


        // Set up signal handler for SIGALRM
        if (signal(SIGALRM, alarm_handler) == SIG_ERR) {
            perror("signal");
            exit(EXIT_FAILURE);
        }


        printf("Enter something within 5 seconds: ");


        // Set an alarm for 5 seconds
        alarm(5);


        // Read user input
        fgets(input, sizeof(input), stdin);


        // Check if the alarm has been triggered
        if (alarm_triggered) {
            printf("Time's up! You didn't enter anything within 5 seconds.\n");
        } else {
            printf("You entered: %s", input);
        }


        return 0;
}
// #include <stdio.h>        // Standard input-output functions like printf(), fgets()
// #include <stdlib.h>       // Standard library functions like exit()
// #include <unistd.h>       // Unix standard functions like alarm()
// #include <signal.h>       // Functions for signal handling like signal(), alarm()

// volatile sig_atomic_t alarm_triggered = 0;
// Global variable to track whether the alarm has gone off.
// 'volatile' ensures the variable is always fetched from memory, avoiding optimization by the compiler.

// void alarm_handler(int signum) {
//     // Signal handler function for SIGALRM
//     alarm_triggered = 1;   // Set the alarm_triggered flag when the alarm goes off
// }

// int main() {
//     char input[100];       // Array to store user input

//     // Set up signal handler for SIGALRM (signal for alarm)
    
//     if (signal(SIGALRM, alarm_handler) == SIG_ERR) {  // Register the signal handler for SIGALRM
//         perror("signal");   // Print error if signal setup fails
//         exit(EXIT_FAILURE); // Exit the program with failure status
//     }

//     printf("Enter something within 5 seconds: ");

//     // Set an alarm for 5 seconds. SIGALRM will be sent after 5 seconds.
    
//     alarm(5);  // Trigger the SIGALRM signal after 5 seconds

//     // Read user input. fgets() will block until input is provided or time runs out.
    
//     fgets(input, sizeof(input), stdin);  // Get user input from stdin

//     // Check if the alarm has been triggered after input
//     if (alarm_triggered) {  // If the alarm went off before input was received
//         printf("Time's up! You didn't enter anything within 5 seconds.\n");
//     } else {  // If the user entered input within the 5-second window
//         printf("You entered: %s", input);
//     }

//     return 0;  // End the program
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// signal():
// - signal() is used to associate a signal (SIGALRM in this case) with a signal handler function.
// - When the signal is received, the signal handler (alarm_handler) is executed.
// - It allows the program to react to asynchronous events like timers or interrupts.

// alarm():
// - alarm() is used to send a SIGALRM signal to the process after a specified number of seconds.
// - In this case, an alarm is set for 5 seconds. If the user doesn't enter input within 5 seconds, the alarm handler will be triggered.

// volatile sig_atomic_t:
// - The volatile keyword tells the compiler not to optimize the variable, ensuring the program always reads the value from memory.
// - sig_atomic_t is used for variables that are modified in signal handlers to ensure proper atomic updates.
// - This ensures that the variable 'alarm_triggered' can be safely accessed by the signal handler and the main program.


