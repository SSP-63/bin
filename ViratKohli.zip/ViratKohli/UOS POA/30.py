
# 30. Write a program to display the following pyramid. The number of lines in the
# pyramid should not be hard-coded. It should be obtained from the user. The
# pyramid should appear as close to the center of the screen as possible.
# (Hint: Basics n loop)
import shutil


def display_pyramid(num_lines):
        max_width = num_lines * 2 - 1


        # Get the width of the terminal window
        terminal_width = shutil.get_terminal_size().columns


        for i in range(1, num_lines + 1):
            stars = '*' * (i * 2 - 1)
            print(stars.center(max_width).center(terminal_width))


# Get the number of lines for the pyramid from the user
num_lines = int(input("Enter the number of lines for the pyramid: "))


# Display the pyramid
display_pyramid(num_lines)


"""
### 🔍 **Code Explanation**

This Python program generates a pyramid with a user-defined number of lines, aligning it to the center of the terminal window.

---

### **1. Importing Required Module**
```python
import shutil
```
- **Purpose**: Provides access to terminal properties (like its width) through `shutil.get_terminal_size()`.
- Essential for centering the pyramid on the screen.

---

### **2. Defining the Pyramid Display Function**
```python
def display_pyramid(num_lines):
    max_width = num_lines * 2 - 1
```
- **`num_lines`**: The total number of lines in the pyramid, obtained from the user.
- **`max_width`**: Calculates the maximum width of the pyramid, which occurs at the bottom line:
  - Formula: `2 * num_lines - 1`.
  - Example: For a pyramid with 5 lines, the maximum width is `9` (line widths: 1, 3, 5, 7, 9).

```python
    terminal_width = shutil.get_terminal_size().columns
```
- Retrieves the width of the terminal window.
- Ensures the pyramid is aligned to the center regardless of screen size.

```python
    for i in range(1, num_lines + 1):
        stars = '*' * (i * 2 - 1)
        print(stars.center(max_width).center(terminal_width))
```
- **Loop**: Iterates over each line in the pyramid.
  - **Line Width**: `i * 2 - 1` calculates the number of stars for the current line.
- **Centering**:
  - **First Layer**: Aligns the stars to the center of the pyramid width using `stars.center(max_width)`.
  - **Second Layer**: Further centers the pyramid to the terminal using `.center(terminal_width)`.

---

### **3. User Input**
```python
num_lines = int(input("Enter the number of lines for the pyramid: "))
```
- **Input**: Asks the user for the number of lines in the pyramid.
- **Validation**: Assumes the user enters a valid integer.

---

### **4. Display the Pyramid**
```python
display_pyramid(num_lines)
```
- Calls the `display_pyramid` function with the user-specified number of lines.

---

### 📚 **Theory Behind Concepts**

#### **Centering Strings**
- **`str.center(width)`**: Aligns the string in the center of a specified width.
  - Pads spaces equally on both sides of the string.

#### **Loops**
- **`for i in range(1, num_lines + 1)`**:
  - Iterates from `1` to `num_lines`.
  - Dynamically calculates the number of stars for each line.

#### **Terminal Properties**
- **`shutil.get_terminal_size()`**:
  - Retrieves the width and height of the terminal window.
  - Useful for adjusting output layout.

---

### Example Execution

#### Input:
```
Enter the number of lines for the pyramid: 5
```

#### Output:
```
        *        
       ***       
      *****      
     *******     
    *********    
```
Aligned and centered based on terminal width.

---

This program blends basic loops, string manipulation, and dynamic terminal adjustments for a visually appealing pyramid. Let me know if you'd like enhancements like color effects or pyramid alignment customization! 😊
"""
