

// 5. Write a program to demonstrate the wait use with fork sysem call.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>


int main() {
        pid_t pid;
        int status;


        printf("Parent: Before forking\n");


        pid = fork(); // Creating a child process using fork


        if (pid == -1) {
            perror("fork failed");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            // Child process
            printf("Child: I am the child process (PID: %d)\n", getpid());
            printf("Child: Sleeping for 3 seconds...\n");
            sleep(3);
            printf("Child: Exiting\n");
            exit(EXIT_SUCCESS);
        } else {
            // Parent process
            printf("Parent: I am the parent process (PID: %d)\n", getpid());
            printf("Parent: Waiting for child to finish...\n");
            wait(&status); // Parent waits for the child process to finish
            printf("Parent: Child process finished\n");
        }


        return 0;
}
// #include <stdio.h>          // Standard input-output functions like printf(), perror()
// #include <stdlib.h>         // Standard library functions like exit(), EXIT_SUCCESS, EXIT_FAILURE
// #include <unistd.h>         // Unix standard functions like fork(), sleep()
// #include <sys/wait.h>       // Functions for process control like wait()

// int main() {
//         pid_t pid;           // Variable to store the process ID returned by fork()
//         int status;          // Variable to store the exit status of the child process

//         printf("Parent: Before forking\n");
//         // Indicating that the parent is about to create a child process

//         pid = fork();        // fork() creates a new child process
//         // fork() returns:
//         //   - 0 to the child process
//         //   - Child's PID to the parent
//         //   - -1 on failure

//         if (pid == -1) {
//             perror("fork failed");
//             // Print error message if fork() fails
//             exit(EXIT_FAILURE); // Exit program due to fork failure
//         } else if (pid == 0) {
//             // This block is executed by the child process

//             printf("Child: I am the child process (PID: %d)\n", getpid());
//             // Display child process ID

//             printf("Child: Sleeping for 3 seconds...\n");
//             // Child sleeps for 3 seconds to simulate some work
//             sleep(3);

//             printf("Child: Exiting\n");
//             // Child process completes and exits
//             exit(EXIT_SUCCESS);
//         } else {
//             // This block is executed by the parent process

//             printf("Parent: I am the parent process (PID: %d)\n", getpid());
//             // Display parent process ID

//             printf("Parent: Waiting for child to finish...\n");
//             // Parent waits for the child process to terminate

//             wait(&status);
//             // wait() suspends parent execution until child process terminates
//             // Child’s exit status is stored in the 'status' variable

//             printf("Parent: Child process finished\n");
//             // Notify that child has finished
//         }

//         return 0; // Program ends successfully
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// fork():
// - fork() is used to create a new child process.
// - After fork, both parent and child continue executing independently.

// sleep():
// - sleep(seconds) suspends execution for a given number of seconds.
// - Here, child process sleeps for 3 seconds.

// wait():
// - wait(&status) causes the parent process to wait until any child process terminates.
// - Useful for process synchronization (ensuring child finishes before parent continues).

// getpid():
// - getpid() returns the process ID of the calling process (child or parent).
// - Helps to distinguish between parent and child during execution.

