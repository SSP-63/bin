
// 4. Write a program to open any application using vfork sysem call.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


int main() {
        pid_t pid;


        pid = vfork(); // Creating a child process using vfork


        if (pid == -1) {
            perror("vfork failed");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            // Child process
            printf("Child: Opening application...\n");
            // Use execl to replace the child process with the desired application
            execl("/usr/bin/gedit", "gedit", NULL);
            // If execl returns, it means there was an error
            perror("execl failed");
            _exit(EXIT_FAILURE);
        } else {
            // Parent process
            printf("Parent: Child process ID: %d\n", pid);
            printf("Parent: Application opened.\n");
        }


        return 0;
}

// #include <stdio.h>          // Standard input-output functions like printf(), perror()
// #include <stdlib.h>         // Standard library functions like exit(), EXIT_SUCCESS, EXIT_FAILURE
// #include <unistd.h>         // Unix standard functions like vfork(), execl(), _exit()

// int main() {
//         pid_t pid;           // Variable to store the process ID returned by vfork()

//         pid = vfork();       // vfork() creates a child process that shares the address space with the parent
//         // vfork() is used when the child immediately calls exec() or _exit()
//         // Parent process is suspended until child calls exec/_exit

//         if (pid == -1) {
//             perror("vfork failed");
//             // If vfork() fails, print error and terminate the program
//             exit(EXIT_FAILURE);
//         } else if (pid == 0) {
//             // This block is executed by the child process

//             printf("Child: Opening application...\n");
//             // Inform that child will attempt to open an application (gedit in this case)

//             execl("/usr/bin/gedit", "gedit", NULL);
//             // execl() replaces the child process with the gedit text editor
//             // Arguments:
//             //   - Full path to the executable
//             //   - argv[0]: traditionally program name
//             //   - NULL to terminate argument list

//             perror("execl failed");
//             // If execl returns, an error occurred (because execl should never return if successful)

//             _exit(EXIT_FAILURE);
//             // Use _exit() instead of exit() after vfork to immediately terminate the child
//             // _exit() avoids flushing parent's I/O buffers which might cause corruption
//         } else {
//             // This block is executed by the parent process

//             printf("Parent: Child process ID: %d\n", pid);
//             // Print the PID of the child process

//             printf("Parent: Application opened.\n");
//             // Inform that application has been opened by the child process
//         }

//         return 0; // Program ends successfully
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// vfork():
// - vfork() is similar to fork() but designed for performance.
// - Child shares the parent's address space until it calls exec() or _exit().
// - Parent is suspended and must not touch any memory before child exits or execs.

// execl():
// - execl() replaces the current process image with a new program (gedit here).
// - Successful execl does not return; if it returns, there was an error.

// _exit():
// - _exit() immediately terminates the current process without calling cleanup handlers.
// - Needed after vfork() to prevent corrupting the parent’s memory or file descriptors.

// Process Synchronization:
// - After vfork, child must quickly call exec() or _exit().
// - Parent waits passively until child does one of those actions.

