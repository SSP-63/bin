
// 38. Write program to implement producer consumer problem using semaphore.h in C/JAVA
// C code:
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>



#define BUFFER_SIZE 5
#define NUM_PRODUCERS 2
#define NUM_CONSUMERS 2


int buffer[BUFFER_SIZE];
int in = 0, out = 0;


sem_t mutex, full, empty;


void *producer(void *arg) {
        int item;
        for (int i = 0; i < 10; i++) {
            item = rand() % 100; // Generate a random item
            sem_wait(&empty);
            sem_wait(&mutex);
            buffer[in] = item;
            printf("Producer %d produced item: %d\n", *(int *)arg, item);
            in = (in + 1) % BUFFER_SIZE;
            sem_post(&mutex);
            sem_post(&full);
        }
        pthread_exit(NULL);
}


void *consumer(void *arg) {
        int item;
        for (int i = 0; i < 10; i++) {
            sem_wait(&full);
            sem_wait(&mutex);
            item = buffer[out];
            printf("Consumer %d consumed item: %d\n", *(int *)arg, item);
            out = (out + 1) % BUFFER_SIZE;
            sem_post(&mutex);
            sem_post(&empty);
        }
        pthread_exit(NULL);
}


int main() {
        pthread_t producers[NUM_PRODUCERS], consumers[NUM_CONSUMERS];
        int producer_ids[NUM_PRODUCERS], consumer_ids[NUM_CONSUMERS];


        sem_init(&mutex, 0, 1);
        sem_init(&full, 0, 0);
        sem_init(&empty, 0, BUFFER_SIZE);


        for (int i = 0; i < NUM_PRODUCERS; i++) {
            producer_ids[i] = i;
            pthread_create(&producers[i], NULL, producer, &producer_ids[i]);
        }


        for (int i = 0; i < NUM_CONSUMERS; i++) {
            consumer_ids[i] = i;
            pthread_create(&consumers[i], NULL, consumer, &consumer_ids[i]);
        }


        for (int i = 0; i < NUM_PRODUCERS; i++) {
            pthread_join(producers[i], NULL);
        }


        for (int i = 0; i < NUM_CONSUMERS; i++) {
            pthread_join(consumers[i], NULL);
        }


        sem_destroy(&mutex);
        sem_destroy(&full);
        sem_destroy(&empty);


        return 0;
}
// Java Code:
// import java.util.concurrent.Semaphore;


// public class Main {
//         static final int BUFFER_SIZE = 5;
//         static final int NUM_PRODUCERS = 2;
//         static final int NUM_CONSUMERS = 2;


//         static int[] buffer = new int[BUFFER_SIZE];
//         static int in = 0, out = 0;


//         static Semaphore mutex = new Semaphore(1);
//         static Semaphore full = new Semaphore(0);
//         static Semaphore empty = new Semaphore(BUFFER_SIZE);


//         static class Producer implements Runnable {
//             private int id;


//             Producer(int id) {
//                 this.id = id;
//             }


//             public void run() {
//                 try {
//                     for (int i = 0; i < 10; i++) {
//                         int item = (int) (Math.random() * 100); // Generate a random item
//                         empty.acquire();
//                         mutex.acquire();
//                         buffer[in] = item;
//                         System.out.println("Producer " + id + " produced item: " + item);
//                         in = (in + 1) % BUFFER_SIZE;
//                         mutex.release();
//                         full.release();
//                     }
//                 } catch (InterruptedException e) {
//                     e.printStackTrace();
//                 }
//             }
//         }


//         static class Consumer implements Runnable {
//             private int id;


//             Consumer(int id) {
//                 this.id = id;
//             }


//             public void run() {
//                 try {
//                     for (int i = 0; i < 10; i++) {
//                         full.acquire();
//                         mutex.acquire();
//                         int item = buffer[out];
//                         System.out.println("Consumer " + id + " consumed item: " + item);
//                         out = (out + 1) % BUFFER_SIZE;
//                         mutex.release();
//                         empty.release();
//                     }
//                 } catch (InterruptedException e) {
//                     e.printStackTrace();
//                 }
//             }
//         }


//         public static void main(String[] args) {
//             Thread[] producers = new Thread[NUM_PRODUCERS];
//             Thread[] consumers = new Thread[NUM_CONSUMERS];


//             for (int i = 0; i < NUM_PRODUCERS; i++) {
//                 producers[i] = new Thread(new Producer(i));
//                 producers[i].start();
//             }


//             for (int i = 0; i < NUM_CONSUMERS; i++) {
//                 consumers[i] = new Thread(new Consumer(i));
//                 consumers[i].start();
//             }
//         }
// }
/*

### **Producer-Consumer Problem Explanation**

The producer-consumer problem is a classic example of a multithreading problem that deals with synchronizing multiple threads. It involves two types of threads:
1. **Producers**: Add data (items) to a shared buffer.
2. **Consumers**: Remove and process the data from the shared buffer.

The goal is to ensure:
- Producers do not add data to a full buffer.
- Consumers do not remove data from an empty buffer.
- Data access (both addition and removal) is synchronized to prevent data corruption.

---

### **C Code Explanation**

#### **Key Components**
1. **Buffer**:
   - A shared array of size `BUFFER_SIZE` for storing produced items.
   - Uses two indices:
     - `in`: Index where the next item will be inserted.
     - `out`: Index where the next item will be removed.

2. **Semaphores**:
   - **`empty`**: Tracks the number of empty slots in the buffer.
   - **`full`**: Tracks the number of filled slots in the buffer.
   - **`mutex`**: Ensures mutual exclusion for accessing the buffer.

3. **Threads**:
   - `pthread_t` is used to create producer and consumer threads.

#### **Workflow**
- **Producer**:
  - Waits for an empty slot (`sem_wait(&empty)`).
  - Acquires the mutex to add an item to the buffer.
  - Increments `in` and releases `mutex` and `full`.

- **Consumer**:
  - Waits for a filled slot (`sem_wait(&full)`).
  - Acquires the mutex to remove an item from the buffer.
  - Increments `out` and releases `mutex` and `empty`.

#### **Implementation Details**
1. **Semaphores Initialization**:
   ```c
   sem_init(&mutex, 0, 1);
   sem_init(&full, 0, 0);
   sem_init(&empty, 0, BUFFER_SIZE);
   ```
   - `mutex`: Binary semaphore initialized to `1` (lock-free).
   - `empty`: Initially, all buffer slots are empty (`BUFFER_SIZE`).
   - `full`: No buffer slots are filled at the start (`0`).

2. **Threads Creation**:
   - `pthread_create()` is used for producer and consumer threads.

3. **Joining Threads**:
   - `pthread_join()` ensures the main thread waits for all producer and consumer threads to complete.

4. **Destroying Semaphores**:
   - `sem_destroy()` releases resources allocated for semaphores.

---

### **Java Code Explanation**

#### **Key Components**
1. **Shared Buffer**:
   - A circular array (`buffer`) is used to store items.
   - Similar to the C implementation, it uses `in` and `out` indices.

2. **Semaphores**:
   - **`empty`**: Tracks empty buffer slots.
   - **`full`**: Tracks filled buffer slots.
   - **`mutex`**: Ensures synchronized access to the buffer.

3. **Threads**:
   - Created for producers and consumers using the `Thread` class.

#### **Workflow**
- **Producer**:
  - Acquires `empty` semaphore to ensure a buffer slot is available.
  - Acquires `mutex` to access the buffer safely.
  - Produces an item and increments `in`.
  - Releases `mutex` and `full`.

- **Consumer**:
  - Acquires `full` semaphore to ensure a filled buffer slot.
  - Acquires `mutex` to access the buffer safely.
  - Consumes an item and increments `out`.
  - Releases `mutex` and `empty`.

---

### **Theory Behind Semaphores**

#### **What are Semaphores?**
- Synchronization primitives used to control access to shared resources in a concurrent environment.
- Two types:
  1. **Binary Semaphore**: Acts like a mutex (value is either `0` or `1`).
  2. **Counting Semaphore**: Tracks multiple resources (e.g., buffer slots).

#### **Semaphores in C (`semaphore.h`)**
- **Functions**:
  - `sem_init()`: Initializes the semaphore.
  - `sem_wait()`: Decrements the semaphore value; blocks if value is `0`.
  - `sem_post()`: Increments the semaphore value; unblocks waiting threads.
  - `sem_destroy()`: Frees resources associated with the semaphore.

#### **Semaphores in Java**
- Provided by the `java.util.concurrent` package.
- **Methods**:
  - `acquire()`: Decrements the semaphore; blocks if value is `0`.
  - `release()`: Increments the semaphore, unblocking threads if necessary.

---

### Example Execution (C Code)

#### Compile and Run:
```bash
gcc -pthread producer_consumer.c -o producer_consumer
./producer_consumer
```

#### Output:
```
Producer 0 produced item: 42
Consumer 0 consumed item: 42
Producer 1 produced item: 15
Consumer 1 consumed item: 15
...
```

---

### Example Execution (Java Code)

#### Compile and Run:
```bash
javac Main.java
java Main
```

#### Output:
```
Producer 0 produced item: 23
Consumer 0 consumed item: 23
Producer 1 produced item: 74
Consumer 1 consumed item: 74
...
```

---

### 📚 **Applications**
- **Operating Systems**: Synchronize processes that share resources like CPU and memory.
- **Concurrent Programming**: Implement thread-safe queues or stacks.
- **Networking**: Buffer incoming and outgoing network packets.

Both implementations demonstrate efficient synchronization for solving the producer-consumer problem. Let me know if you'd like a variation with bounded buffers, priority scheduling, or enhanced logging! 😊
*/
