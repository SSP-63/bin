

// 60. Write a program to illustrate the semaphore concept. Use fork so that 2 process running simultaneously and communicate via semaphore. (give diff between sem.h/semaphore.h)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <fcntl.h>


int main() {
        // Create a semaphore and initialize it to 1
        sem_t *sem = sem_open("/my_semaphore", O_CREAT, 0644, 1);
        if (sem == SEM_FAILED) {
            perror("sem_open");
            exit(EXIT_FAILURE);
        }


        // Fork a child process
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pid == 0) { // Child process
            printf("Child process trying to lock the semaphore...\n");
            sem_wait(sem); // Lock the semaphore
            printf("Child process locked the semaphore.\n");
            sleep(2); // Simulate some work
            sem_post(sem); // Unlock the semaphore
            printf("Child process released the semaphore.\n");
        } else { // Parent process
            printf("Parent process trying to lock the semaphore...\n");
            sem_wait(sem); // Lock the semaphore
            printf("Parent process locked the semaphore.\n");
            sleep(2); // Simulate some work
            sem_post(sem); // Unlock the semaphore
            printf("Parent process released the semaphore.\n");
        }


        // Close and unlink the semaphore
        sem_close(sem);
        sem_unlink("/my_semaphore");


        return 0;
}


// The difference between sem.h and semaphore.h lies in their functionality, portability, and underlying implementations. Here's a comparison between the two:
// sem.h (System V Semaphores):
// 1. Functionality:
//    * Provides functions like semget, semop, and semctl for semaphore creation, operation, and control.
//    * Allows for the creation of System V semaphores, which are managed using unique semaphore identifiers (semid).
// 2. Portability:
//    * sem.h is part of the System V IPC (Inter-Process Communication) mechanisms.
//    * It may not be available on all systems, especially those that follow POSIX standards exclusively.
// 3. Usage:
//    * Commonly used in older UNIX systems and legacy codebases.
//    * Not as widely supported across different platforms compared to POSIX semaphores.
// semaphore.h (POSIX Semaphores):
// 1. Functionality:
//    * Provides functions like sem_init, sem_wait, sem_post, and sem_destroy for semaphore management.
//    * Allows for the creation of POSIX semaphores, which are managed using pointers to sem_t structures.
// 2. Portability:
//    * semaphore.h is part of the POSIX standard (POSIX.1-2001 and later revisions).
//    * It is more widely supported across different UNIX-like systems and modern operating systems.
// 3. Usage:
//    * Preferred choice for new projects and modern codebases due to its standardization and portability.
//    * Offers a more consistent and intuitive interface compared to System V semaphores.
// Summary:
// * sem.h is associated with S
// * ystem V semaphores and provides functions for semaphore management specific to System V IPC mechanisms. It is less portable and not as widely used in modern applications.
// * semaphore.h is part of the POSIX standard and provides a more modern and portable interface for semaphore management. It is the preferred choice for new projects and is widely supported across different platforms
// 6
/* ### **Program Explanation: Semaphore Concept Using Fork**

This program demonstrates the use of **POSIX semaphores** (from `semaphore.h`) for synchronization between two processes, created using the `fork` system call. Semaphores help ensure that critical sections of the code are executed by only one process at a time.

---

### **Code Breakdown**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <fcntl.h>
```
- **`stdio.h`**: Provides functions like `printf` and `perror`.
- **`stdlib.h`**: Includes `exit` for error handling.
- **`unistd.h`**: Contains functions like `fork`.
- **`semaphore.h`**: Provides POSIX semaphore operations (`sem_open`, `sem_wait`, `sem_post`, etc.).
- **`fcntl.h`**: Allows flags like `O_CREAT` and file permissions (`0644`).

---

#### **2. Creating the Semaphore**
```c
sem_t *sem = sem_open("/my_semaphore", O_CREAT, 0644, 1);
```
- **`sem_open`**:
  - Creates or opens a named semaphore.
  - Parameters:
    - **`"/my_semaphore"`**: Name of the semaphore.
    - **`O_CREAT`**: Creates the semaphore if it does not already exist.
    - **`0644`**: Sets read/write permissions for the semaphore.
    - **`1`**: Initial semaphore value (unlocked).
- **Error Handling**:
  - If the semaphore cannot be created, prints an error message (`perror`) and exits.

---

#### **3. Fork the Process**
```c
pid_t pid = fork();
```
- **`fork()`**:
  - Creates a child process.
  - Returns:
    - `0` for the child process.
    - Positive value (child's PID) for the parent process.
    - `-1` on failure.
- **Error Handling**:
  - Prints an error message and terminates the program if `fork` fails.

---

#### **4. Child Process Logic**
```c
else if (pid == 0) {
    sem_wait(sem); // Lock semaphore
    sleep(2);      // Simulate work
    sem_post(sem); // Unlock semaphore
}
```
- **Steps**:
  1. **Lock the semaphore**:
     - Ensures exclusive access to the critical section using `sem_wait`.
  2. **Perform simulated work**:
     - Sleeps for 2 seconds to mimic task execution.
  3. **Release the semaphore**:
     - Unlocks the semaphore using `sem_post` to allow other processes to proceed.

---

#### **5. Parent Process Logic**
```c
else { // Parent process
    sem_wait(sem); // Lock semaphore
    sleep(2);      // Simulate work
    sem_post(sem); // Unlock semaphore
}
```
- **Steps**:
  1. **Lock the semaphore**:
     - Ensures exclusive access to the critical section using `sem_wait`.
  2. **Perform simulated work**:
     - Sleeps for 2 seconds to mimic task execution.
  3. **Release the semaphore**:
     - Unlocks the semaphore using `sem_post` to allow other processes to proceed.

---

#### **6. Clean Up**
```c
sem_close(sem);
sem_unlink("/my_semaphore");
```
- **`sem_close`**:
  - Closes the semaphore in the process.
- **`sem_unlink`**:
  - Removes the named semaphore from the system.

---

### **Execution Workflow**

1. **Semaphore Initialization**:
   - Creates a named semaphore with an initial value of `1`.

2. **Forking**:
   - Splits the program into a parent and child process.

3. **Critical Section**:
   - Both processes attempt to lock the semaphore before entering the critical section.
   - The semaphore ensures mutual exclusion.

4. **Resource Cleanup**:
   - Closes and removes the semaphore from the system.

---

### **Compiling and Running the Program**

#### **1. Compile**
```bash
gcc semaphore_fork.c -o semaphore_fork -lpthread
```

#### **2. Run**
```bash
./semaphore_fork
```

---

### **Sample Output**
```
Parent process trying to lock the semaphore...
Parent process locked the semaphore.
Child process trying to lock the semaphore...
Child process locked the semaphore.
Parent process released the semaphore.
Child process released the semaphore.
```
The order of execution may vary due to concurrency.

---

### **Theory Behind Semaphores**

#### **What Is a Semaphore?**
- A semaphore is a synchronization primitive used to control access to shared resources in a concurrent environment.
- **Two Types**:
  1. **Binary Semaphore**:
     - Acts like a mutex; values are `0` (locked) or `1` (unlocked).
  2. **Counting Semaphore**:
     - Tracks multiple resources, allowing up to `n` processes to access them simultaneously.

#### **Key Semaphore Functions**
1. **`sem_wait`**:
   - Decreases the semaphore value. Blocks if the value is `0`.
2. **`sem_post`**:
   - Increases the semaphore value. Unblocks waiting processes if necessary.
3. **`sem_open`**:
   - Creates or opens a named semaphore.
4. **`sem_close`**:
   - Closes the semaphore.
5. **`sem_unlink`**:
   - Removes the named semaphore from the system.

---

#### **Difference Between `sem.h` and `semaphore.h`**

| **Aspect**       | **System V Semaphores (`sem.h`)**  | **POSIX Semaphores (`semaphore.h`)**    |
|-------------------|-----------------------------------|-----------------------------------------|
| **Functionality** | Legacy system calls like `semget`, `semop`, and `semctl`. | Modern APIs like `sem_open`, `sem_wait`, and `sem_post`. |
| **Usage**         | Requires key-based identification (`semid`). | Uses named semaphores or `sem_t` pointers. |
| **Portability**   | Limited to UNIX systems with System V IPC. | Widely supported in modern UNIX-like systems. |
| **Preferred For** | Legacy applications.              | New projects requiring portability.    |

---

### **Applications of Semaphores**
1. **Concurrency Control**:
   - Avoid data corruption by managing access to shared resources.
2. **Multithreading**:
   - Synchronize threads in parallel programs.
3. **Producer-Consumer Problem**:
   - Ensure balanced access to a shared buffer.

This program effectively illustrates semaphore usage in a multi-process environment. Let me know if you'd like to explore semaphore usage in threads or other IPC mechanisms! 😊*/
