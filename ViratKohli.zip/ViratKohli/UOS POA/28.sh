# 28. Write a shell script to display the users on the system . (Using finger or who command).
#!/bin/bash


echo "Users currently logged in to the system:"
who
:'
### 🔍 **Line-by-Line Code Explanation**

This script displays a list of users currently logged into the system using the `who` command.

---

#### **1. Shebang**
```bash
#!/bin/bash
```
- Specifies that the script will be executed in the Bash shell.

---

#### **2. Display Header Message**
```bash
echo "Users currently logged in to the system:"
```
- **Purpose**: Prints a message to inform the user about the output that will follow.

---

#### **3. Executing the `who` Command**
```bash
who
```
- **Purpose**: Retrieves a list of users currently logged in to the system along with their login details.
- **Output**:
  - Typically includes:
    - Username.
    - Terminal.
    - Login time.
    - Hostname/IP (if logged in remotely).

---

### 📚 **Related Theory**

#### **`who` Command**
- **Purpose**: Displays information about logged-in users.
- **Usage**: `who`.
- **Typical Output**:
  - Example:
    ```
    user1    tty1         Apr 28 10:05
    user2    pts/0        Apr 28 10:45 (192.168.1.10)
    ```
  - Columns:
    - Username: Name of the logged-in user.
    - Terminal: Terminal session or remote session identifier.
    - Login time: Timestamp of the login.
    - Hostname/IP: Remote machine details (if applicable).

---

### Alternative: `finger` Command
- **Purpose**: Provides detailed user information, including:
  - User's name.
  - Login directory.
  - Shell type.
- **Usage**: `finger`.

#### Example Script Using `finger`:
```bash
#!/bin/bash

echo "Detailed user information:"
finger
```

---

### Applications
- **System Administration**: Monitor logged-in users for security and resource management.
- **Diagnostics**: Check user activity in case of issues.

Let me know if you’d like enhancements or a deeper dive into related commands! 😊

'
