

// 56. Write a program using FIFO, to Send data from parent to child over a pipe. (named pipe)


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#define FIFO_PATH "/tmp/myfifo"
#define BUFFER_SIZE 25


int main() {
        int fd; // File descriptor for the FIFO
        pid_t pid; // Process ID


        char buffer[BUFFER_SIZE]; // Buffer for reading from and writing to the FIFO


        // Create the FIFO
        mkfifo(FIFO_PATH, 0666);


        // Fork a child process
        pid = fork();


        if (pid < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        }


        if (pid > 0) { // Parent process
            printf("Parent: Opening FIFO for writing...\n");
            // Open the FIFO for writing
            fd = open(FIFO_PATH, O_WRONLY);


            printf("Parent: Writing data to the FIFO...\n");
            // Write data to the FIFO
            write(fd, "Hello, child!", 14);


            close(fd); // Close the FIFO
            printf("Parent: Data written to the FIFO.\n");
        } else { // Child process
            printf("Child: Opening FIFO for reading...\n");
            // Open the FIFO for reading
            fd = open(FIFO_PATH, O_RDONLY);


            printf("Child: Reading data from the FIFO...\n");
            // Read data from the FIFO
            read(fd, buffer, BUFFER_SIZE);
            printf("Child: Received message: %s\n", buffer);


            close(fd); // Close the FIFO
        }


        return 0;
}
/* This program demonstrates **Interprocess Communication (IPC)** using a **named pipe (FIFO)** to send data from a parent process to a child process. Below is a detailed explanation of the code and its concepts:

---

### **Key Concepts: Named Pipes (FIFO)**

#### **What is a FIFO?**
1. A **FIFO (First In First Out)** is a special type of file used for communication between processes.
2. Unlike unnamed pipes:
   - FIFOs are persistent and are identified by a path in the filesystem.
   - They allow unrelated processes (not parent/child) to communicate.
3. **Characteristics**:
   - **Unidirectional**: Data flows in one direction (unless both ends are opened for reading and writing).
   - **Blocking Behavior**: A process attempting to read from an empty FIFO will block until data is available.

---

### **Code Breakdown**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
```
- **`unistd.h`**: Provides `mkfifo`, `fork`, and `pipe` functions.
- **`sys/stat.h`**: Required for setting file permissions when creating a FIFO.
- **`fcntl.h`**: Enables file opening modes (`O_RDONLY`, `O_WRONLY`).

---

#### **2. Define Constants**
```c
#define FIFO_PATH "/tmp/myfifo"
#define BUFFER_SIZE 25
```
- **`FIFO_PATH`**: Specifies the path for the named pipe in the `/tmp` directory. This location ensures temporary files are appropriately stored.
- **`BUFFER_SIZE`**: Sets the maximum size of the buffer to read/write data.

---

#### **3. Create a Named Pipe**
```c
mkfifo(FIFO_PATH, 0666);
```
- **`mkfifo`**:
  - Creates a FIFO special file at the specified path.
  - **Permissions**: `0666` allows read/write access to all users.
- **Error Handling**:
  - If the file already exists, `mkfifo` will not overwrite it.

---

#### **4. Fork the Process**
```c
pid = fork();
```
- **`fork()`**:
  - Splits the program into a parent process and a child process.
  - Returns:
    - `0` for the child process.
    - The child's PID for the parent process.
    - A negative value if the fork fails.

---

#### **5. Parent Process Logic**
```c
if (pid > 0) {
    fd = open(FIFO_PATH, O_WRONLY);
    write(fd, "Hello, child!", 14);
    close(fd);
}
```
- **Opening the FIFO**:
  - Uses `O_WRONLY` mode to open the FIFO for writing.
  - If no process is reading from the FIFO, the `open` call will block until the child process opens it.
- **Writing to the FIFO**:
  - Sends the message `"Hello, child!"` using `write(fd, data, length)`.
- **Closing the FIFO**:
  - Closes the file descriptor after writing.

---

#### **6. Child Process Logic**
```c
else if (pid == 0) {
    fd = open(FIFO_PATH, O_RDONLY);
    read(fd, buffer, BUFFER_SIZE);
    printf("Child: Received message: %s\n", buffer);
    close(fd);
}
```
- **Opening the FIFO**:
  - Uses `O_RDONLY` mode to open the FIFO for reading.
  - If no process is writing to the FIFO, the `open` call will block until the parent process writes data.
- **Reading from the FIFO**:
  - Reads the message from the parent process into `buffer`.
- **Displaying the Message**:
  - Prints the received message.
- **Closing the FIFO**:
  - Closes the file descriptor after reading.

---

#### **7. Error Handling for `fork()`**
```c
if (pid < 0) {
    perror("fork");
    exit(EXIT_FAILURE);
}
```
- **`perror`**:
  - Prints a descriptive error message if `fork()` fails.
- **`exit`**:
  - Terminates the program.

---

### **Execution Workflow**

1. **Parent Process**:
   - Creates the named pipe using `mkfifo`.
   - Forks a child process.
   - Opens the FIFO for writing, writes a message, and closes it.

2. **Child Process**:
   - Opens the FIFO for reading.
   - Reads the message written by the parent process and displays it.

3. **Resource Cleanup**:
   - The named pipe persists after the program exits unless manually deleted (`rm /tmp/myfifo`).

---

### **Compiling and Running the Program**

#### **1. Compile**
```bash
gcc named_pipe.c -o named_pipe
```

#### **2. Run the Program**
```bash
./named_pipe
```

---

### **Sample Output**
```
Parent: Opening FIFO for writing...
Parent: Writing data to the FIFO...
Parent: Data written to the FIFO.
Child: Opening FIFO for reading...
Child: Reading data from the FIFO...
Child: Received message: Hello, child!
```

---

### **Theory Behind Named Pipes**

#### **How FIFOs Work**
1. **FIFO vs Unnamed Pipes**:
   - Unnamed pipes (`pipe`) exist only while the processes are running and can only be used by related processes (parent and child).
   - FIFOs persist as files in the filesystem, allowing unrelated processes to communicate.

2. **Data Flow**:
   - A FIFO acts as a buffer:
     - Data is written to one end and read from the other in a **first-in, first-out** order.
   - If a process attempts to read from an empty FIFO, it blocks until data is written.

#### **Advantages of FIFOs**
1. **Unrelated Process Communication**:
   - Allow communication between processes that do not share a parent-child relationship.
2. **Simple to Use**:
   - Create, read, and write using standard file operations.

#### **Limitations of FIFOs**
1. **Unidirectional**:
   - Data flows in one direction. For bi-directional communication, two FIFOs are needed.
2. **Blocking Behavior**:
   - `open`, `read`, or `write` calls may block until the corresponding operation (read/write) is performed.

---

### **Applications**
1. **Producer-Consumer Systems**:
   - FIFOs can implement producer-consumer systems where one process produces data, and another consumes it.
2. **Log Systems**:
   - Transfer logs from one process to another for real-time analysis.
3. **Client-Server Communication**:
   - Facilitate communication between a server and multiple clients.

Let me know if you'd like to extend this program to demonstrate bi-directional communication or implement additional IPC mechanisms! 😊*/
