

// 54. Implement echo server using UDP in iterative/concurrent logic
// Client
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>  // Add this line for the close() function

#define PORT 9999
#define BUFFER_SIZE 4096

int main() {
    struct sockaddr_in server_addr;
    int sockfd;
    char buffer[BUFFER_SIZE];
    socklen_t server_len;

    // Create a UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize server address structure
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    while (1) {
        printf("Enter message to send (type 'exit' to quit): ");
        fgets(buffer, BUFFER_SIZE, stdin);

        // Remove newline character from the input
        buffer[strcspn(buffer, "\n")] = 0;

        if (strcmp(buffer, "exit") == 0) {
            break;
        }

        // Send message to the server
        server_len = sizeof(server_addr);
        if (sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr*)&server_addr, server_len) < 0) {
            perror("sendto failed");
            exit(EXIT_FAILURE);
        }

        // Receive response from server
        if (recvfrom(sockfd, buffer, BUFFER_SIZE, 0, NULL, NULL) < 0) {
            perror("recvfrom failed");
            exit(EXIT_FAILURE);
        }

        printf("Received response: %s\n", buffer);
    }

    // Close the socket
    close(sockfd);

    return 0;
}

/* This program implements a **UDP client** for an echo server that supports **iterative/concurrent logic**, which allows the client to send messages to the server and receive an exact copy of the message in response. Below is a detailed explanation of how the client works:

---

### **Step-by-Step Explanation of the Client Code**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>  // Add this line for the close() function
```
- **`stdio.h`**: Provides input/output functions like `printf` and `fgets`.
- **`stdlib.h`**: Includes utility functions like `exit` for error handling.
- **`string.h`**: Used for string manipulation (e.g., `memset`, `strcmp`).
- **`arpa/inet.h`**: Contains networking-specific functions and structures, such as `sockaddr_in` and `inet_addr`.
- **`unistd.h`**: Provides system calls like `close`.

---

#### **2. Define Constants**
```c
#define PORT 9999
#define BUFFER_SIZE 4096
```
- **`PORT`**:
  - Specifies the port number the server is listening on (`9999` in this case).
- **`BUFFER_SIZE`**:
  - Defines the maximum size of the buffer for message exchange.

---

#### **3. Create the UDP Socket**
```c
if ((sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
    perror("socket creation failed");
    exit(EXIT_FAILURE);
}
```
- **`socket`**:
  - Creates a UDP socket.
  - **Parameters**:
    - `AF_INET`: Specifies IPv4 address family.
    - `SOCK_DGRAM`: Indicates UDP protocol (datagram-based).
    - `IPPROTO_UDP`: Explicitly specifies the UDP protocol.
- **Error Handling**:
  - Prints an error using `perror` if socket creation fails and exits.

---

#### **4. Initialize the Server Address**
```c
memset(&server_addr, 0, sizeof(server_addr));
server_addr.sin_family = AF_INET;
server_addr.sin_addr.s_addr = INADDR_ANY;
server_addr.sin_port = htons(PORT);
```
- **`memset`**:
  - Initializes the `server_addr` structure with zeros.
- **Fields**:
  - **`sin_family`**: Specifies the address family (IPv4 in this case).
  - **`sin_addr.s_addr`**: Uses the wildcard address (`INADDR_ANY`) to indicate the server will accept messages from any client.
  - **`sin_port`**: Sets the port number using `htons` to ensure proper byte order.

---

#### **5. Send Message to Server**
```c
fgets(buffer, BUFFER_SIZE, stdin);
buffer[strcspn(buffer, "\n")] = 0;
sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr*)&server_addr, server_len);
```
- **`fgets`**:
  - Reads the user input (message to send).
- **`strcspn(buffer, "\n")`**:
  - Removes the newline character (`\n`) from the input.
- **`sendto`**:
  - Sends the message to the server via the socket (`sockfd`).
  - **Parameters**:
    - `buffer`: Message data.
    - `strlen(buffer)`: Length of the message.
    - `server_addr`: The server's address information.
    - `server_len`: Size of the `server_addr` structure.

---

#### **6. Receive Echoed Response**
```c
recvfrom(sockfd, buffer, BUFFER_SIZE, 0, NULL, NULL);
printf("Received response: %s\n", buffer);
```
- **`recvfrom`**:
  - Receives the message echoed back by the server.
  - **Parameters**:
    - `sockfd`: The socket to receive data from.
    - `buffer`: Stores the received message.
    - `BUFFER_SIZE`: Maximum size of the buffer.
- **Response Output**:
  - Prints the echoed message received from the server.

---

#### **7. Close the Socket**
```c
close(sockfd);
```
- **`close`**:
  - Releases resources associated with the socket after communication is complete.

---

### **Execution Workflow**

#### **1. Compile Both Client and Server**
Compile the client and server programs separately:
```bash
gcc -o udp_server udp_server.c
gcc -o udp_client udp_client.c
```

#### **2. Run the Server**
Start the server in the first terminal:
```bash
./udp_server
```

#### **3. Run the Client**
Execute the client in a second terminal:
```bash
./udp_client
```

---

### **Sample Interaction**

**Terminal 1 (Server)**:
```
Server started and waiting for messages...
Received message: Hello from client
Sent response: Hello from client
Received message: Goodbye
Sent response: Goodbye
```

**Terminal 2 (Client)**:
```
Enter message to send (type 'exit' to quit): Hello from client
Message sent to server
Received response: Hello from client
Enter message to send (type 'exit' to quit): Goodbye
Message sent to server
Received response: Goodbye
Enter message to send (type 'exit' to quit): exit
```

---

### **Networking Concepts**

#### **UDP vs TCP**
- **UDP (User Datagram Protocol)**:
  - Connectionless: No handshake before data transfer.
  - Faster but less reliable than TCP.
  - Ideal for real-time applications like gaming, VoIP, and live streaming.

- **TCP (Transmission Control Protocol)**:
  - Connection-oriented: Establishes a connection before data transfer.
  - Guarantees delivery and ensures data integrity.
  - Used in web servers, email clients, and file transfer.

---

### **Applications**
1. **Echo Servers**:
   - Useful for debugging and testing network connectivity.
2. **Real-Time Communication**:
   - Handles real-time data exchange efficiently.
3. **Lightweight Protocols**:
   - Suitable for IoT devices or systems with limited resources.

This client program interacts seamlessly with the server to demonstrate UDP-based echo server functionality. Let me know if you'd like further insights into concurrent or iterative server logic! 😊*/
