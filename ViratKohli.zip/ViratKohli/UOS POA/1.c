// 1. Write a program to use fork system call to create 5 child processes and assign      5 operations to childs.

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>


void child_operation(int index) {
        switch (index) {
            case 1:
                printf("Child %d: I am performing addition.\n", getpid());
                // Perform addition operation
                break;
            case 2:
                printf("Child %d: I am performing subtraction.\n", getpid());
                // Perform subtraction operation
                break;
            case 3:
                printf("Child %d: I am performing multiplication.\n", getpid());
                // Perform multiplication operation
                break;
            case 4:
                printf("Child %d: I am performing division.\n", getpid());
                // Perform division operation
                break;
            case 5:
                printf("Child %d: I am performing modulus.\n", getpid());
                // Perform modulus operation
                break;
            default:
                printf("Invalid index.\n");
                exit(EXIT_FAILURE);
        }
        exit(EXIT_SUCCESS);
}


int main() {
        int num_processes = 5;
    
        for (int i = 1; i <= num_processes; i++) {
            pid_t pid = fork();
            if (pid == -1) {
                perror("fork failed");
                exit(EXIT_FAILURE);
            } else if (pid == 0) {
                // This is the child process
                child_operation(i);
            }
        }
    
        // Parent process waits for all child processes to finish
        for (int i = 0; i < num_processes; i++) {
            wait(NULL);
        }
    
        return 0;

}
// #include <stdio.h>          // Standard input-output functions like printf(), perror()
// #include <stdlib.h>         // Standard library functions like exit(), EXIT_SUCCESS, EXIT_FAILURE
// #include <unistd.h>         // Unix standard functions like fork(), getpid()
// #include <sys/wait.h>       // wait() function to wait for child processes to terminate

// void child_operation(int index) {  
//         switch (index) {    // Choose operation based on child index
//             case 1:
//                 printf("Child %d: I am performing addition.\n", getpid());
//                 // getpid() gets the process ID of the calling process (child)
//                 break;
//             case 2:
//                 printf("Child %d: I am performing subtraction.\n", getpid());
//                 // Child announces subtraction operation
//                 break;
//             case 3:
//                 printf("Child %d: I am performing multiplication.\n", getpid());
//                 // Child announces multiplication operation
//                 break;
//             case 4:
//                 printf("Child %d: I am performing division.\n", getpid());
//                 // Child announces division operation
//                 break;
//             case 5:
//                 printf("Child %d: I am performing modulus.\n", getpid());
//                 // Child announces modulus operation
//                 break;
//             default:
//                 printf("Invalid index.\n");
//                 // If index not between 1-5, print error
//                 exit(EXIT_FAILURE); // Exit with failure status
//         }
//         exit(EXIT_SUCCESS); // Child exits successfully after operation
// }

// int main() {
//         int num_processes = 5;  // We want to create 5 child processes

//         for (int i = 1; i <= num_processes; i++) {   // Loop to fork 5 children
//             pid_t pid = fork(); // fork() creates a new process
//             // fork() returns:
//             //  - 0 to the child process
//             //  - child's PID to the parent
//             //  - -1 on error

//             if (pid == -1) {
//                 perror("fork failed");
//                 // perror prints a system error message if fork fails
//                 exit(EXIT_FAILURE); // Exit program due to fork failure
//             } else if (pid == 0) {
//                 // In child process
//                 child_operation(i); // Perform child-specific task
//             }
//             // Parent continues the loop to create more children
//         }

//         for (int i = 0; i < num_processes; i++) {
//             wait(NULL);
//             // wait() makes the parent wait until each child terminates
//             // NULL means we are not interested in exit status
//         }

//         return 0; // Program completed successfully
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// fork():
// - fork() is used to create a child process in Unix systems.
// - After fork(), parent and child continue execution separately.
// - Important: They have separate memory spaces.

// getpid():
// - getpid() returns the Process ID (PID) of the running process.
// - Helpful to identify processes in multi-process programs.

// wait():
// - wait() makes the parent process pause execution until any one child finishes.
// - Important to prevent creation of zombie processes.

// Process Concept:
// - In Unix, a process is an instance of a program in execution.
// - Every process has a unique PID, parent process ID (PPID), and state (running, sleeping, zombie, etc.).

