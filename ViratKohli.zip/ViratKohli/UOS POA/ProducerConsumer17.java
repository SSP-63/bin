// 17. Write a multithreaded program for producer-consumer problem in JAVA.
import java.util.LinkedList;


public class ProducerConsumer17 {
        public static void main(String[] args) {
            Buffer buffer = new Buffer(5); // Buffer size is 5
            Producer producer = new Producer(buffer);
            Consumer consumer = new Consumer(buffer);


            Thread producerThread = new Thread(producer);
            Thread consumerThread = new Thread(consumer);


            producerThread.start();
            consumerThread.start();
        }
}


class Buffer {
        private LinkedList<Integer> buffer;
        private int capacity;


        public Buffer(int capacity) {
            this.buffer = new LinkedList<>();
            this.capacity = capacity;
        }


        public synchronized void produce(int item) throws InterruptedException {
            while (buffer.size() == capacity) {
                wait(); // Wait if buffer is full
            }
            buffer.add(item);
            System.out.println("Produced: " + item);
            notify(); // Notify consumer thread that a new item is produced
        }


        public synchronized int consume() throws InterruptedException {
            while (buffer.isEmpty()) {
                wait(); // Wait if buffer is empty
            }
            int item = buffer.remove();
            System.out.println("Consumed: " + item);
            notify(); // Notify producer thread that an item is consumed
            return item;
        }
}


class Producer implements Runnable {
        private Buffer buffer;


        public Producer(Buffer buffer) {
            this.buffer = buffer;
        }


        public void run() {
            for (int i = 1; i <= 10; i++) {
                try {
                    buffer.produce(i);
                    Thread.sleep(1000); // Simulate some time taken to produce an item
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
}


class Consumer implements Runnable {
        private Buffer buffer;


        public Consumer(Buffer buffer) {
            this.buffer = buffer;
        }


        public void run() {
            for (int i = 1; i <= 10; i++) {
                try {
                    int item = buffer.consume();
                    Thread.sleep(2000); // Simulate some time taken to consume an item
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
}
/* This program implements the **Producer-Consumer Problem** in Java using **multithreading** and synchronization. Below is a detailed breakdown of the concepts, logic, and execution.

---

### **Theory of Producer-Consumer Problem**

#### **What is the Producer-Consumer Problem?**
1. **Definition**:
   - A classic synchronization problem in which two processes, the **Producer** and **Consumer**, share a **buffer** (queue).
   - The **Producer** generates items and adds them to the buffer.
   - The **Consumer** removes items from the buffer for processing.

2. **Constraints**:
   - The **Producer** must wait if the buffer is full.
   - The **Consumer** must wait if the buffer is empty.

3. **Goals**:
   - Ensure smooth communication between the two threads without **deadlocks** or **race conditions**.

4. **Real-Life Example**:
   - A printing system where documents (items) are added to the printer queue by users (producers), and the printer processes and prints them (consumer).

---

### **Concepts in the Code**

#### **Multithreading**
1. **Why Multithreading?**
   - Allows both the Producer and Consumer to execute concurrently while sharing a common buffer.
   - Simulates real-time behavior efficiently.

2. **Key Elements**:
   - `Runnable` interface for defining thread behavior.
   - `Thread` class to execute the `Runnable` objects.

---

#### **Synchronization**
1. **Purpose**:
   - Prevent **race conditions** by ensuring the buffer is accessed by only one thread at a time.

2. **Mechanisms Used**:
   - **`synchronized`**:
     - Ensures mutual exclusion (only one thread can execute the method at a time).
   - **`wait()`**:
     - Makes the current thread pause execution until notified.
   - **`notify()`**:
     - Wakes up a paused thread waiting on the monitor.

---

### **Code Breakdown**

#### **1. Main Class: `ProducerConsumer17`**
```java
public static void main(String[] args) {
    Buffer buffer = new Buffer(5); // Buffer size is 5
    Producer producer = new Producer(buffer);
    Consumer consumer = new Consumer(buffer);

    Thread producerThread = new Thread(producer);
    Thread consumerThread = new Thread(consumer);

    producerThread.start();
    consumerThread.start();
}
```
- **Purpose**:
  - Creates the shared buffer and initializes both Producer and Consumer threads.
- **Buffer Size**:
  - The buffer can hold a maximum of 5 items, simulating limited storage capacity.

---

#### **2. Shared Resource: `Buffer`**
```java
private LinkedList<Integer> buffer;
private int capacity;
```
- **`LinkedList<Integer>`**:
  - Acts as the buffer storing the items produced.
- **Capacity**:
  - Limits the number of items the buffer can store.

---

##### **`produce(int item)`**
```java
public synchronized void produce(int item) throws InterruptedException {
    while (buffer.size() == capacity) {
        wait(); // Wait if buffer is full
    }
    buffer.add(item);
    System.out.println("Produced: " + item);
    notify(); // Notify consumer thread
}
```
- **Logic**:
  - Waits if the buffer is full (`wait()`).
  - Adds the new item to the buffer once space is available.
  - Notifies waiting consumer threads (`notify()`).

---

##### **`consume()`**
```java
public synchronized int consume() throws InterruptedException {
    while (buffer.isEmpty()) {
        wait(); // Wait if buffer is empty
    }
    int item = buffer.remove();
    System.out.println("Consumed: " + item);
    notify(); // Notify producer thread
    return item;
}
```
- **Logic**:
  - Waits if the buffer is empty (`wait()`).
  - Removes and returns the item from the buffer once available.
  - Notifies waiting producer threads (`notify()`).

---

#### **3. Producer Class**
```java
for (int i = 1; i <= 10; i++) {
    buffer.produce(i);
    Thread.sleep(1000);
}
```
- **Logic**:
  - Produces items numbered `1` to `10`.
  - Simulates production delay using `Thread.sleep(1000)`.

---

#### **4. Consumer Class**
```java
for (int i = 1; i <= 10; i++) {
    buffer.consume();
    Thread.sleep(2000);
}
```
- **Logic**:
  - Consumes the items produced by the producer.
  - Simulates consumption delay using `Thread.sleep(2000)`.

---

### **Execution Workflow**

1. **Initialization**:
   - The producer thread starts producing items, adding them to the buffer.
   - The consumer thread starts consuming items from the buffer.

2. **Synchronization**:
   - If the buffer is full, the producer waits for the consumer to remove items.
   - If the buffer is empty, the consumer waits for the producer to add items.

3. **Termination**:
   - Both threads terminate after producing and consuming 10 items.

---

### **Sample Output**

```
Produced: 1
Produced: 2
Consumed: 1
Produced: 3
Produced: 4
Consumed: 2
Produced: 5
Produced: 6
Consumed: 3
Produced: 7
Produced: 8
Consumed: 4
Produced: 9
Produced: 10
Consumed: 5
Consumed: 6
Consumed: 7
Consumed: 8
Consumed: 9
Consumed: 10
```

**Note**: Due to multithreading, the order of output may vary.

---

### **Key Concepts and Theory**

#### **Producer-Consumer Synchronization**
1. **Problem**:
   - Both threads need access to the buffer concurrently.
   - Without synchronization, race conditions occur, leading to corrupted data.
   
2. **Solution**:
   - Use `synchronized`, `wait()`, and `notify()` to ensure mutual exclusion and proper coordination.

---

#### **Challenges in Producer-Consumer Problem**
1. **Deadlock**:
   - Occurs if threads indefinitely wait for each other.
   - Prevented by ensuring proper signaling with `notify()`.

2. **Starvation**:
   - Happens if a thread is unable to execute because other threads monopolize resources.
   - Prevented by fair scheduling in multithreading.

---

### **Real-Life Applications**
1. **Multithreaded Queues**:
   - Used in messaging systems where producers send data to consumers.
2. **Data Pipelines**:
   - Handles real-time data transfer between producer services and consumers (e.g., analytics).
3. **Web Servers**:
   - Concurrently handle multiple client requests using producer-consumer mechanisms.

This implementation efficiently demonstrates multithreading concepts and synchronization. Let me know if you'd like enhancements like additional producers/consumers or dynamic buffer sizes! 😊*/
