
// 15. Write a program to create 3 threads, first thread printing even no, second thread printing odd no. and third thread printing prime no
public class NumberThreads15 {
        public static void main(String[] args) {
            Thread evenThread = new Thread(new EvenRunnable());
            Thread oddThread = new Thread(new OddRunnable());
            Thread primeThread = new Thread(new PrimeRunnable());


            evenThread.start();
            oddThread.start();
            primeThread.start();
        }
}


class EvenRunnable implements Runnable {
        public void run() {
            for (int i = 0; i <= 10; i += 2) {
                System.out.println("Even: " + i);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
}


class OddRunnable implements Runnable {
        public void run() {
            for (int i = 1; i <= 10; i += 2) {
                System.out.println("Odd: " + i);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
}


class PrimeRunnable implements Runnable {
        public void run() {
            for (int i = 2; i <= 10; i++) {
                if (isPrime(i)) {
                    System.out.println("Prime: " + i);
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }


        private boolean isPrime(int n) {
            if (n <= 1) {
                return false;
            }
            for (int i = 2; i <= Math.sqrt(n); i++) {
                if (n % i == 0) {
                    return false;
                }
            }
            return true;
        }
}
/* This program demonstrates the use of **multithreading in Java** by creating three separate threads, each tasked with printing specific sets of numbers: even numbers, odd numbers, and prime numbers.

---

### **Concepts in Play**

#### **Multithreading in Java**
1. **What is Multithreading?**
   - Multithreading allows multiple threads of execution to run concurrently within a program.
   - Each thread operates independently, sharing the same memory space.

2. **Benefits of Multithreading**:
   - Efficient use of CPU resources.
   - Parallel processing for tasks such as computing, I/O operations, or user interaction.

3. **Thread Creation Techniques**:
   - Extend the `Thread` class.
   - Implement the `Runnable` interface (used in this program).

4. **Synchronization**:
   - Although threads in this example work independently, thread synchronization may be required to coordinate shared resources.

---

### **Detailed Code Explanation**

#### **1. Main Class: `NumberThreads15`**
```java
public class NumberThreads15 {
    public static void main(String[] args) {
        Thread evenThread = new Thread(new EvenRunnable());
        Thread oddThread = new Thread(new OddRunnable());
        Thread primeThread = new Thread(new PrimeRunnable());

        evenThread.start();
        oddThread.start();
        primeThread.start();
    }
}
```
- **Purpose**:
  - Creates three threads to print even, odd, and prime numbers.
- **Key Points**:
  - Each thread is instantiated with a `Runnable` object: `EvenRunnable`, `OddRunnable`, or `PrimeRunnable`.
  - The `start()` method begins the execution of the thread, invoking its `run()` method.

---

#### **2. Thread to Print Even Numbers: `EvenRunnable`**
```java
class EvenRunnable implements Runnable {
    public void run() {
        for (int i = 0; i <= 10; i += 2) {
            System.out.println("Even: " + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
```
- **Purpose**:
  - Prints even numbers from `0` to `10`.
- **Key Points**:
  - The `for` loop increments by 2, ensuring only even numbers are printed.
  - **`Thread.sleep(1000)`**:
    - Pauses the thread execution for 1 second to simulate a delay between number prints.
  - Handles `InterruptedException` gracefully.

---

#### **3. Thread to Print Odd Numbers: `OddRunnable`**
```java
class OddRunnable implements Runnable {
    public void run() {
        for (int i = 1; i <= 10; i += 2) {
            System.out.println("Odd: " + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
```
- **Purpose**:
  - Prints odd numbers from `1` to `10`.
- **Key Points**:
  - Similar to `EvenRunnable`, but starts at `1` and increments by `2`.

---

#### **4. Thread to Print Prime Numbers: `PrimeRunnable`**
```java
class PrimeRunnable implements Runnable {
    public void run() {
        for (int i = 2; i <= 10; i++) {
            if (isPrime(i)) {
                System.out.println("Prime: " + i);
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
```
- **Purpose**:
  - Prints all prime numbers between `2` and `10`.
- **Key Points**:
  - **Prime Check Algorithm**:
    - A prime number is a number greater than `1` that is divisible only by `1` and itself.
    - Loops from `2` to the square root of the number to check divisors.
  - **Thread.sleep(1000)**:
    - Introduces a delay between prints.

---

### **Output**

When the program runs, all three threads execute simultaneously. The output might appear **interleaved** due to concurrency, as shown below:

```
Even: 0
Odd: 1
Prime: 2
Even: 2
Odd: 3
Prime: 3
Even: 4
Odd: 5
Prime: 5
Even: 6
Odd: 7
Prime: 7
Even: 8
Odd: 9
Even: 10
```

**Note**: The exact order may vary since threads run concurrently.

---

### **Key Concepts and Theory**

#### **Thread Life Cycle**
1. **New State**:
   - A thread is created but not started (`new Thread()`).
2. **Runnable State**:
   - After calling `start()`, the thread is eligible to run.
3. **Running State**:
   - The thread’s `run()` method is actively executing.
4. **Blocked/Waiting State**:
   - Occurs during `Thread.sleep()`, waiting for locks, etc.
5. **Terminated State**:
   - After the `run()` method completes.

---

#### **Thread Scheduling**
- **Multithreading in Java** is preemptive:
  - Threads are scheduled by the JVM and OS.
  - The exact execution order is unpredictable and depends on system load.

---

### **Advantages of Multithreading**
1. **Concurrent Execution**:
   - Performs multiple tasks simultaneously, maximizing CPU usage.
2. **Improved Performance**:
   - Reduces waiting times for I/O or computationally intensive tasks.
3. **Scalable Applications**:
   - Essential for real-time systems, GUI applications, and server-side programs.

---

### **Real-Life Applications**
1. **Gaming**:
   - Separate threads for game logic, rendering, and user input.
2. **Web Servers**:
   - Handle multiple client requests concurrently.
3. **Real-Time Systems**:
   - Applications requiring simultaneous handling of tasks, such as robotics or process control.

---

This program elegantly demonstrates how multithreading can execute tasks concurrently, and it can be extended for more complex number-processing tasks or real-time applications! Let me know if you'd like to expand it further. 😊*/
