
// Server
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>


#define PORT 9999
#define BUFFER_SIZE 4096


int main() {
        struct sockaddr_in server_addr, client_addr;
        int sockfd, client_len, recv_len;
        char buffer[BUFFER_SIZE];


        // Create a UDP socket
        if ((sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
            perror("socket creation failed");
            exit(EXIT_FAILURE);
        }


        // Initialize server address structure
        memset(&server_addr, 0, sizeof(server_addr));
        server_addr.sin_family = AF_INET;
        server_addr.sin_addr.s_addr = INADDR_ANY;
        server_addr.sin_port = htons(PORT);


        // Bind the socket
        if (bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
            perror("bind failed");
            exit(EXIT_FAILURE);
        }


        printf("Server is running on port %d\n", PORT);


        while (1) {
            printf("\nWaiting to receive message...\n");


            // Receive message from client
            client_len = sizeof(client_addr);
            if ((recv_len = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&client_addr, &client_len)) < 0) {
                perror("recvfrom failed");
                exit(EXIT_FAILURE);
            }


            printf("Received %d bytes from %s:%d\n", recv_len, inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
            printf("Data received: %s\n", buffer);


            // Echo back the received data
            if (sendto(sockfd, buffer, recv_len, 0, (struct sockaddr*)&client_addr, client_len) < 0) {
                perror("sendto failed");
                exit(EXIT_FAILURE);
            }
        }


        return 0;
}
/* ### **Explanation of the UDP Server Code**

This program implements a **UDP echo server** that receives a message from a client, displays it, and sends it back as an acknowledgment.

---

### **Step-by-Step Code Breakdown**

#### **1. Include Required Libraries**
```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
```
- **`stdio.h`**: Provides standard input/output functions like `printf` and `perror`.
- **`stdlib.h`**: Includes `exit` for error handling and program termination.
- **`string.h`**: Provides string manipulation functions like `memset`.
- **`arpa/inet.h`**:
  - Includes networking-specific structures and functions (e.g., `sockaddr_in` for IP addressing and `inet_ntoa` for IP-to-text conversion).
- **`sys/socket.h`**: Contains socket definitions and functions.

---

#### **2. Define Constants**
```c
#define PORT 9999
#define BUFFER_SIZE 4096
```
- **`PORT`**: Specifies the port the server will listen on (9999 in this case).
- **`BUFFER_SIZE`**: Sets the maximum size of the buffer for receiving messages.

---

#### **3. Declare Structures and Variables**
```c
struct sockaddr_in server_addr, client_addr;
int sockfd, client_len, recv_len;
char buffer[BUFFER_SIZE];
```
- **`sockaddr_in`**:
  - Specifies address information for the server (`server_addr`) and client (`client_addr`).
- **`sockfd`**:
  - File descriptor for the UDP socket.
- **`client_len`**:
  - Size of the client address structure, used during message exchange.
- **`recv_len`**:
  - Stores the length of the received message.
- **`buffer`**:
  - Temporary storage for the received message.

---

#### **4. Create a UDP Socket**
```c
if ((sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
    perror("socket creation failed");
    exit(EXIT_FAILURE);
}
```
- **`socket`**:
  - Creates a UDP socket.
- **Parameters**:
  - `AF_INET`: Indicates IPv4 address family.
  - `SOCK_DGRAM`: Specifies UDP (datagram protocol).
  - `IPPROTO_UDP`: Indicates the UDP protocol.
- **Error Handling**:
  - Prints an error using `perror` if socket creation fails and exits the program.

---

#### **5. Initialize the Server Address**
```c
memset(&server_addr, 0, sizeof(server_addr));
server_addr.sin_family = AF_INET;
server_addr.sin_addr.s_addr = INADDR_ANY;
server_addr.sin_port = htons(PORT);
```
- **`memset`**:
  - Clears the `server_addr` structure by setting all bytes to 0.
- **Fields**:
  - **`sin_family`**: Sets the address family (IPv4).
  - **`sin_addr.s_addr`**: Specifies the server's IP address (`INADDR_ANY` binds to all network interfaces).
  - **`sin_port`**: Converts the port number (`9999`) to network byte order using `htons`.

---

#### **6. Bind the Socket**
```c
if (bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
    perror("bind failed");
    exit(EXIT_FAILURE);
}
```
- **`bind`**:
  - Associates the socket with the server's address and port.
- **Error Handling**:
  - If the binding process fails, prints `"bind failed"` and terminates the program.

---

#### **7. Display Server Status**
```c
printf("Server is running on port %d\n", PORT);
```
- Confirms that the server is ready to receive messages.

---

#### **8. Enter an Infinite Loop**
```c
while (1) { ... }
```
- Keeps the server running indefinitely to handle multiple messages.

---

#### **9. Receive Messages from Client**
```c
client_len = sizeof(client_addr);
if ((recv_len = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&client_addr, &client_len)) < 0) {
    perror("recvfrom failed");
    exit(EXIT_FAILURE);
}
```
- **`recvfrom`**:
  - Blocks until a message is received from a client.
- **Parameters**:
  - `sockfd`: The UDP socket.
  - `buffer`: Temporary storage for the incoming message.
  - `BUFFER_SIZE`: Maximum size of the buffer.
  - `0`: No special flags.
  - `client_addr`: Stores the address and port of the client.
  - `client_len`: Contains the size of the `client_addr` structure.
- **Error Handling**:
  - Prints an error message if the `recvfrom` function fails.

---

#### **10. Display Client Information**
```c
printf("Received %d bytes from %s:%d\n", recv_len, inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
printf("Data received: %s\n", buffer);
```
- **`inet_ntoa`**:
  - Converts the client's IP address from binary to string form.
- **`ntohs`**:
  - Converts the client's port number from network byte order to host byte order.

---

#### **11. Echo the Message Back to the Client**
```c
if (sendto(sockfd, buffer, recv_len, 0, (struct sockaddr*)&client_addr, client_len) < 0) {
    perror("sendto failed");
    exit(EXIT_FAILURE);
}
```
- **`sendto`**:
  - Sends the received message back to the client.
- **Parameters**:
  - `sockfd`: The UDP socket.
  - `buffer`: Contains the message to send.
  - `recv_len`: Size of the message.
  - `0`: No special flags.
  - `client_addr`: Specifies the client address and port.
  - `client_len`: Size of the `client_addr` structure.

---

### **Compiling and Running the Program**

#### **Step 1: Compile**
```bash
gcc -o udp_server udp_server.c
```

#### **Step 2: Run the Server**
```bash
./udp_server
```

---

### **Expected Output**

**Server Output**:
```
Server is running on port 9999

Waiting to receive message...
Received 13 bytes from 127.0.0.1:port_number
Data received: Hello, Server!
```

---

### **How UDP Communication Works**

#### **User Datagram Protocol (UDP)**
- **Connectionless**:
  - No handshake required between the client and server before data transmission.
- **Fast and Lightweight**:
  - Messages (datagrams) are sent directly without acknowledgment, resulting in faster communication.
- **Unreliable**:
  - No guarantee of delivery, as lost packets are not retransmitted.

#### **Typical Use Cases**
1. Real-time communication (e.g., video conferencing, online gaming).
2. Lightweight data transfer (e.g., DNS lookups).
3. Broadcasting messages across a network.

---

This implementation provides a foundational understanding of UDP servers. Let me know if you need the corresponding client-side implementation or additional enhancements! 😊*/
