// 42. Write a program to demonstrate IPC using shared memory (shmget, shmat,
// shmdt). In this, one process will send from file A to Z/1 to 100 as input from user
// and another process will receive it in file. (use same directory and different name
// files)

// gcc 42.c -o 42
// omkar@omkar:~/Desktop/UOS POA$ ./42
// Enter characters from A to Z or numbers from 1 to 100 (separated by spaces):
// A 1 B C 4
// Data has been written to output.txt
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>


#define SHM_SIZE 1024 // Size of shared memory segment


int main() {
        key_t key = ftok(".", 'A'); // Generate a unique key
        int shmid; // Shared memory ID
        char *shm_ptr; // Pointer to shared memory
        char input[100]; // Input buffer
        int i;


        // Create a shared memory segment
        shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
        if (shmid == -1) {
            perror("shmget");
            exit(1);
        }


        // Attach the shared memory segment to the process's address space
        shm_ptr = shmat(shmid, NULL, 0);
        if (shm_ptr == (char *) -1) {
            perror("shmat");
            exit(1);
        }


        printf("Enter characters from A to Z or numbers from 1 to 100 (separated by spaces):\n");
        fgets(input, sizeof(input), stdin); // Read input from user


        // Write input data to shared memory
        for (i = 0; input[i] != '\0'; i++) {
            shm_ptr[i] = input[i];
        }
        shm_ptr[i] = '\0'; // Null-terminate the data


        // Detach the shared memory segment
        if (shmdt(shm_ptr) == -1) {
            perror("shmdt");
            exit(1);
        }


        // Fork a child process to read from shared memory and write to file
        pid_t pid = fork();
        if (pid == -1) {
            perror("fork");
            exit(1);
        } else if (pid == 0) { // Child process
            FILE *file = fopen("output.txt", "w"); // Open file for writing
            if (file == NULL) {
                perror("fopen");
                exit(1);
            }


            // Attach the shared memory segment to the child process's address space
            shm_ptr = shmat(shmid, NULL, 0);
            if (shm_ptr == (char *) -1) {
                perror("shmat");
                exit(1);
            }


            // Write data from shared memory to file
            fprintf(file, "%s", shm_ptr);


            // Detach the shared memory segment from the child process
            if (shmdt(shm_ptr) == -1) {
                perror("shmdt");
                exit(1);
            }


            fclose(file); // Close the file
            exit(0);
        } else { // Parent process
            wait(NULL); // Wait for the child process to finish


            printf("Data has been written to output.txt\n");


            // Remove the shared memory segment
            if (shmctl(shmid, IPC_RMID, NULL) == -1) {
                perror("shmctl");
                exit(1);
            }
        }


        return 0;
}

/* ### **Interprocess Communication (IPC) Using Shared Memory**

This program demonstrates how two processes can communicate using shared memory for IPC. One process writes user input (characters or numbers) into shared memory, and the other process reads the data and writes it to a file. Below is an in-depth explanation of the code and the underlying concepts.

---

### 📚 **Key Concepts in IPC Using Shared Memory**

#### **Shared Memory in IPC**
- Shared memory is the fastest IPC method as multiple processes directly access a shared memory segment.
- It requires proper synchronization when used by multiple processes to avoid race conditions or data corruption.
- Functions used:
  1. **`shmget`**: Creates or retrieves a shared memory segment.
  2. **`shmat`**: Attaches the shared memory segment to the process's address space.
  3. **`shmdt`**: Detaches the shared memory segment.
  4. **`shmctl`**: Manages or removes the shared memory segment.

---

### **Code Explanation**

#### **1. Key and Shared Memory Initialization**
```c
key_t key = ftok(".", 'A');
shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
```
- **`ftok`**: Generates a unique key based on the file path (`.` for the current directory) and an identifier (`'A'`).
- **`shmget`**:
  - Creates a shared memory segment of size `SHM_SIZE` (1024 bytes).
  - Permissions are set to `0666` (read/write for all users).

#### Error Handling:
```c
if (key == -1 || shmid == -1) {
    perror("ftok/shmget");
    exit(1);
}
```
- Ensures key generation and shared memory allocation succeed.

---

#### **2. Attaching Shared Memory**
```c
shm_ptr = shmat(shmid, NULL, 0);
```
- **`shmat`** attaches the shared memory segment to the process's virtual address space.
- **Error Check**:
  ```c
  if (shm_ptr == (char *) -1) {
      perror("shmat");
      exit(1);
  }
  ```

---

#### **3. Writing to Shared Memory**
```c
fgets(input, sizeof(input), stdin); // Get user input
for (i = 0; input[i] != '\0'; i++) {
    shm_ptr[i] = input[i];
}
shm_ptr[i] = '\0'; // Null-terminate the shared memory data
```
- The parent process reads user input and writes it to shared memory character by character.
- Ensures proper null-termination of the data.

---

#### **4. Detaching Shared Memory**
```c
if (shmdt(shm_ptr) == -1) {
    perror("shmdt");
    exit(1);
}
```
- **Purpose**: Detaches the shared memory from the process's virtual address space.

---

#### **5. Forking a Process**
```c
pid_t pid = fork();
```
- **Parent Process**:
  - Writes input into shared memory.
  - Waits for the child process to complete.
- **Child Process**:
  - Reads data from shared memory and writes it to a file.

---

#### **6. Reading and Writing to File (Child Process)**
```c
FILE *file = fopen("output.txt", "w");
if (file == NULL) {
    perror("fopen");
    exit(1);
}

// Write data from shared memory to file
fprintf(file, "%s", shm_ptr);

// Close file and detach shared memory
fclose(file);
if (shmdt(shm_ptr) == -1) {
    perror("shmdt");
    exit(1);
}
```
- Opens `output.txt` in the same directory for writing.
- Reads data from the shared memory and writes it to the file.
- Detaches the shared memory segment after completion.

---

#### **7. Cleaning Up Shared Memory**
```c
if (shmctl(shmid, IPC_RMID, NULL) == -1) {
    perror("shmctl");
    exit(1);
}
```
- The parent process removes the shared memory segment after confirming that the child process has finished execution.

---

### **Workflow of the Program**

1. **Parent Process**:
   - Allocates and attaches shared memory.
   - Reads user input and writes it to shared memory.
   - Detaches the shared memory segment.

2. **Child Process**:
   - Attaches the shared memory segment.
   - Reads the data from shared memory and writes it to `output.txt`.
   - Detaches the shared memory segment.

3. **Parent Process**:
   - Waits for the child process using `wait(NULL)`.
   - Cleans up by removing the shared memory segment.

---

### **Theory Behind IPC Using Shared Memory**

#### **Advantages**
1. **Speed**:
   - Data transfer happens via direct memory access, making it faster than pipes or message queues.
2. **Shared State**:
   - Multiple processes can access and modify data in real-time.

#### **Challenges**
1. **Synchronization**:
   - Synchronization mechanisms (e.g., semaphores or mutexes) must be used to avoid race conditions.
2. **Resource Management**:
   - Explicit cleanup (e.g., `shmdt`, `shmctl`) is necessary to release memory resources.

#### **Use Cases**
- **Real-Time Applications**:
  - Sensor data processing, gaming, or video streaming.
- **Multi-Process Communication**:
  - Shared memory is useful in scenarios where processes need frequent and fast communication.

---

### Example Execution

#### **Compilation**:
```bash
gcc 42.c -o 42
```

#### **Execution**:
```bash
./42
```

#### **Sample Interaction**:
Input:
```
Enter characters from A to Z or numbers from 1 to 100 (separated by spaces):
A B C 1 2 3
```
Output:
```
Data has been written to output.txt
```

#### **Content of `output.txt`**:
```
A B C 1 2 3
```

---

### **Applications**
1. **File Transfer Simulations**:
   - This program simulates transferring content between files via shared memory.
2. **Real-Time Systems**:
   - Shared memory can be used for fast communication between processes in high-performance systems.

Feel free to share more requirements or ask for additional theoretical insights! 😊 */
