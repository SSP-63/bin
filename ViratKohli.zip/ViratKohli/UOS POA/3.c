// // 3. Write a program to open any application using fork sysem call.
// #include <stdio.h>
// #include <stdlib.h>
// #include <unistd.h>


// int main() {
//         pid_t pid;


//         pid = fork(); // Creating a child process using fork


//         if (pid == -1) {
//             perror("fork failed");
//             exit(EXIT_FAILURE);
//         } else if (pid == 0) {
//             // Child process
//             printf("Child: Opening application...\n");
//             // Use execl to replace the child process with the desired application
//             execl("/usr/bin/gedit", "gedit", NULL);
//             // If execl returns, it means there was an error
//             perror("execl failed");
//             exit(EXIT_FAILURE);
//         } else {
//             // Parent process
//             printf("Parent: Child process ID: %d\n", pid);
//             printf("Parent: Application opened.\n");
//         }


//         return 0;
// }

// 3. Write a program to open any application using fork system call (opens Firefox now)

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    pid_t pid;

    pid = fork(); // Creating a child process using fork

    if (pid == -1) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        // Child process
        printf("Child: Opening Firefox...\n");
        // Use execl to open Firefox browser
        execl("/usr/bin/firefox", "firefox", NULL);
        // If execl returns, it means there was an error
        perror("execl failed");
        exit(EXIT_FAILURE);
    } else {
        // Parent process
        printf("Parent: Child process ID: %d\n", pid);
        printf("Parent: Firefox should be opening...\n");
    }

    return 0;
}


// #include <stdio.h>          // Standard input-output functions like printf(), perror()
// #include <stdlib.h>         // Standard library functions like exit(), EXIT_SUCCESS, EXIT_FAILURE
// #include <unistd.h>         // Unix standard functions like fork(), execl()

// int main() {
//     pid_t pid;              // Variable to store the process ID returned by fork()

//     pid = fork();           // fork() creates a new child process
//     // fork() returns:
//     //   - 0 to the child process
//     //   - Child's PID to the parent
//     //   - -1 on failure

//     if (pid == -1) {
//         perror("fork failed");
//         // Print error message if fork() fails
//         exit(EXIT_FAILURE); // Exit program due to fork failure
//     } else if (pid == 0) {
//         // This block is executed by the child process

//         printf("Child: Opening Firefox...\n");
//         // Inform that child will attempt to open Firefox browser

//         execl("/usr/bin/firefox", "firefox", NULL);
//         // execl() replaces the current process image with a new program (Firefox in this case)
//         // Arguments: 
//         //   - Path to the executable
//         //   - The first argument (argv[0]) traditionally is the program name
//         //   - NULL marks the end of arguments

//         perror("execl failed");
//         // If execl() returns, it means execution failed, so print error
//         exit(EXIT_FAILURE); // Child exits with failure
//     } else {
//         // This block is executed by the parent process

//         printf("Parent: Child process ID: %d\n", pid);
//         // Print the PID of the child process

//         printf("Parent: Firefox should be opening...\n");
//         // Inform that Firefox should be launching by now
//     }

//     return 0; // Program ends successfully
// }

// ----------------------------------------------------
// Additional Unix Concepts Used:
// ----------------------------------------------------

// fork():
// - fork() is used to create a new child process.
// - Child is a copy of the parent but with a different PID.
// - Essential for process management in Unix-like systems.

// execl():
// - execl() replaces the current process image with a new program (Firefox here).
// - If successful, execl never returns; if it fails, it returns -1.
// - execl requires specifying the full path of the executable.

// Process Control:
// - After fork(), both parent and child execute separately.
// - If child executes execl() successfully, it becomes the Firefox process.
// - Parent continues its own flow without waiting in this code.

// getpid() (implicitly used via pid):
// - Parent prints the child's process ID (pid), which is helpful for monitoring or managing processes.

