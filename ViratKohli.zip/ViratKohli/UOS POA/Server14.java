import java.io.*;
import java.net.*;
import java.util.*;

public class Server14 {
    private static final int PORT = 12345;
    private static Set<String> usernames = new HashSet<>();
    private static List<ClientHandler> clients = new ArrayList<>();

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Chat server is running on port " + PORT);
            
            while (true) {
                Socket clientSocket = serverSocket.accept(); // Wait for new client connections
                System.out.println("New client connected: " + clientSocket);
                
                ClientHandler clientHandler = new ClientHandler(clientSocket);
                clients.add(clientHandler); // Add new client to the list
                clientHandler.start(); // Start the new client handler thread
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket clientSocket;
        private PrintWriter out;
        private BufferedReader in;
        private String username;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        public void run() {
            try {
                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                // Ask client to provide a username
                out.println("Welcome to the chat server! Please enter your username:");
                username = in.readLine();

                // Ensure the username is unique
                synchronized (usernames) {
                    while (usernames.contains(username)) {
                        out.println("Username already taken. Please choose another one:");
                        username = in.readLine();
                    }
                    usernames.add(username);
                }

                out.println("Welcome, " + username + "!");
                broadcast(username + " has joined the chat.");

                String input;
                while ((input = in.readLine()) != null) {
                    if (input.equalsIgnoreCase("/quit")) {
                        break; // Client wants to exit the chat
                    }
                    broadcast(username + ": " + input); // Broadcast the message to all clients
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (username != null) {
                        synchronized (usernames) {
                            usernames.remove(username); // Remove client from the list of usernames
                        }
                        System.out.println(username + " has left the chat.");
                        broadcast(username + " has left the chat."); // Notify all clients that user left
                    }
                    if (clientSocket != null) {
                        clientSocket.close(); // Close the client socket
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void broadcast(String message) {
            synchronized (clients) {
                for (ClientHandler client : clients) {
                    client.out.println(message); // Send the message to all connected clients
                    client.out.flush(); // Ensure the message is immediately sent
                }
            }
        }
    }
}
